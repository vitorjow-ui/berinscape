"""Regenerate the local-file-compatible model script from the source GLB."""
import base64
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'art/source/characters/berin/v2/Berin_LOD0.glb'
TARGET = ROOT / 'assets/characters/berin/berin-model.js'

if __name__ == '__main__':
    data = SOURCE.read_bytes()
    if data[:4] != b'glTF':
        raise ValueError('A origem não é um GLB válido.')
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    TARGET.write_text('window.BERIN_GLB_BASE64="' + base64.b64encode(data).decode('ascii') + '";', encoding='utf-8')
    print('Modelo do navegador atualizado a partir de Berin_LOD0.glb.')
