"""Acquire public CC0 field recordings and CC-BY music; dialogue is never uploaded."""
import json,re,urllib.request,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'art/source/audio/premium-intro';OUT.mkdir(parents=True,exist_ok=True)
def get(url,referer=''):
    headers={'User-Agent':'Mozilla/5.0','Accept':'audio/mpeg,*/*'}
    if referer:headers['Referer']=referer
    with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=45) as response:return response.read()
for name,page in {'night':'https://freesound.org/people/timothyd4y/sounds/587907/','wind':'https://freesound.org/people/NomadApe/sounds/444921/','laugh':'https://freesound.org/people/balloonhead/sounds/362330/'}.items():
    source=OUT/(name+'-source.html');target=OUT/(name+'-source.mp3')
    if target.exists():continue
    html=get(page).decode('utf-8');source.write_text(html,encoding='utf-8')
    urls=re.findall(r'https://[^\s"<>]+hq\.mp3',html);url=next(u for u in urls if 'freesound' in u)
    target.write_bytes(get(url,page))
music=ROOT/'assets/audio/music/juggernaut-scott-buckley.mp3'
if not music.exists():music.write_bytes(get('https://www.scottbuckley.com.au/library/wp-content/uploads/2022/07/Juggernaut.mp3','https://www.scottbuckley.com.au/library/juggernaut/'))
subprocess.run([sys.executable,str(ROOT/'tools/fetch_kenney_mirrors.py')],check=True)
print('Fontes públicas de áudio disponíveis; vozes são preparadas offline por prepare_intro_voices.py.')
