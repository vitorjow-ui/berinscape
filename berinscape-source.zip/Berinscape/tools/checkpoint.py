"""Save the complete project with a content manifest and verified ZIP archive."""
import hashlib
import json
import zipfile
from datetime import datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
WORKSPACE=ROOT.parent

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

if __name__=='__main__':
    stamp=datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    destination=WORKSPACE/'backups'/f'Berinscape_{stamp}'
    destination.mkdir(parents=True,exist_ok=False)
    files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    readme=WORKSPACE/'README.md'
    if readme.is_file():files.append(readme)
    entries=[{'path':p.relative_to(WORKSPACE).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)} for p in files]
    manifest={'created':datetime.now().astimezone().isoformat(),'scope':'Complete project, including original art, runtime assets, code, documentation and tools','files':entries}
    manifest_path=destination/'manifest.json'
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    archive=destination/'Berinscape.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as bundle:
        for entry in entries:bundle.write(WORKSPACE/entry['path'],entry['path'])
        bundle.write(manifest_path,'checkpoint-manifest.json')
    # Verify the archived data against source hashes, not just ZIP headers.
    with zipfile.ZipFile(archive) as bundle:
        for entry in entries:
            h=hashlib.sha256()
            with bundle.open(entry['path']) as stream:
                for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
            assert h.hexdigest()==entry['sha256'],entry['path']
    (destination/'RESTORE.txt').write_text('Extraia Berinscape.zip em uma pasta vazia. Abra Berinscape/index.html ou execute python Berinscape/tools/serve.py. O manifesto permite verificar os arquivos. A biblioteca Three.js ainda exige internet nesta versão.\n',encoding='utf-8')
    result={'archive':str(archive),'manifest':str(manifest_path),'files':len(entries),'bytes':archive.stat().st_size,'sha256':digest(archive),'verified':True}
    (destination/'checkpoint.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))
