// Deterministic checks for recorded playback, cancellation, mix buses and pause offsets.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
class Param{constructor(){this.value=0}setValueAtTime(v){this.value=v}linearRampToValueAtTime(v){this.value=v}setTargetAtTime(v){this.value=v}cancelScheduledValues(){}}
class Node{constructor(){this.gain=new Param();this.pan=new Param();for(const p of ['threshold','knee','ratio','attack','release','playbackRate'])this[p]=new Param()}connect(node){return node}disconnect(){}}
class Context{
 constructor(){this.currentTime=0;this.sampleRate=100;this.state='running';this.destination=new Node();this.sources=[]}
 createGain(){return new Node()}createStereoPanner(){return new Node()}createDynamicsCompressor(){return new Node()}createConvolver(){return new Node()}createMediaElementSource(){return new Node()}
 createBuffer(channels,size){return {getChannelData:()=>new Float32Array(size)}}
 createBufferSource(){const n=new Node();n.start=(when,offset)=>{n.offset=offset};n.stop=()=>{n.stopped=true;n.onended?.()};this.sources.push(n);return n}
 decodeAudioData(){return Promise.resolve({duration:5})}resume(){return Promise.resolve()}
}
class Media{constructor(){this.paused=true;this.volume=0}addEventListener(){}play(){this.paused=false;return Promise.resolve()}pause(){this.paused=true}}
const root=path.resolve(__dirname,'..'),manifest={};
vm.runInNewContext(fs.readFileSync(path.join(root,'assets/audio/premium/manifest.js'),'utf8'),{window:manifest});
const indicator={dataset:{}},sandbox={window:{AudioContext:Context,BERIN_AUDIO_MANIFEST:manifest.BERIN_AUDIO_MANIFEST,dispatchEvent(){}},document:{getElementById:()=>indicator},location:{protocol:'http:'},Audio:Media,CustomEvent:class{},fetch:async()=>({ok:true,arrayBuffer:async()=>new ArrayBuffer(8)}),setInterval:()=>0,setTimeout:()=>0};
const {RecordedClip,BerinscapeMusic}=vm.runInNewContext(fs.readFileSync(path.join(root,'src/audio/audio-manager.js'),'utf8')+';({RecordedClip,BerinscapeMusic})',sandbox);
const mixer=new BerinscapeMusic();
mixer.update({master:.5,music:.4,ambience:.3,interface:.6,voices:.8,enabledVoices:true,stage:'menu',paused:false});
assert.equal(mixer.master.gain.value,.45);assert.equal(mixer.buses.music.gain.value,.4);assert.equal(mixer.buses.interface.gain.value,.6);
let finished=0;const clip=new RecordedClip(mixer,'test',{duration:5},mixer.buses.voices,{onended:()=>finished++});
mixer.context.currentTime=1.25;mixer.update({paused:true,stage:'menu'});assert.equal(clip.offset,1.25);assert.equal(finished,0);assert.equal(mixer.buses.voices.gain.value,0);assert.equal(mixer.buses.interface.gain.value,.6);
mixer.context.currentTime=10;mixer.update({paused:false,stage:'menu'});assert.equal(clip.source.offset,1.25);assert.equal(mixer.buses.voices.gain.value,.8);clip.source.onended();assert.equal(finished,1);
mixer.update({enabledVoices:false,stage:'menu'});assert.equal(mixer.buses.voices.gain.value,0);assert.equal(mixer.buses.interface.gain.value,.6);
async function voiceSequence(){
  for(const protocol of ['http:','file:']){
    sandbox.location.protocol=protocol;
    const sceneMixer=new BerinscapeMusic();sceneMixer.update({stage:'tavern'});sceneMixer.fade();
    const opening=sceneMixer.music.menu;opening.audio.currentTime=35;
    assert.equal(opening.audio.paused,false);
    sceneMixer.update({stage:'forest'});
    assert.equal(opening.audio.paused,true,'Opening must stop at the scene cut');
    assert.equal(opening.audio.currentTime,0);assert.equal(opening.mix,0);assert.equal(opening.gain.gain.value,0);
    if(protocol==='file:')assert.equal(opening.audio.volume,0);
    sceneMixer.fade();await new Promise(setImmediate);
    assert.equal(opening.audio.paused,true,'Late play completion must not restart the opening');
    assert.equal(sceneMixer.music.forest.audio.paused,false);
    sceneMixer.update({stage:'menu'});assert.equal(sceneMixer.music.forest.audio.paused,true);
  }
  sandbox.location.protocol='http:';
  mixer.update({enabledVoices:true,paused:false,stage:'menu'});await mixer.prepareDialogue();mixer.say(['berin-answer-a','berin-laugh','berin-answer-b']);await new Promise(setImmediate);
  assert.equal(mixer.voiceHandle.key,'berin-answer-a');mixer.voiceHandle.source.onended();await new Promise(setImmediate);assert.equal(mixer.voiceHandle.key,'berin-laugh');
  const generation=mixer.voiceGeneration;mixer.stopVoice();assert.ok(mixer.voiceGeneration>generation);assert.equal(mixer.queue,null);
  mixer.muted=true;mixer.update({stage:'menu'});assert.equal(mixer.buses.music.gain.value,0);assert.equal(mixer.buses.ambience.gain.value,.3);
  console.log('OK: troca menu/fase em HTTP e arquivo local, volumes separados, pausa/retomada, cancelamento e voz/risada.');
}
module.exports=voiceSequence();
