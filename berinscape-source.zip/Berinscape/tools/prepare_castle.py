"""Prepare the supplied castle, preserving its original and limiting texture memory."""
import bpy, json, math
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/environments/medieval-castle'
PREVIEW=ROOT/'art/previews/medieval-castle'
OUT.mkdir(parents=True,exist_ok=True);PREVIEW.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(ROOT/'art/source/environments/castle/ugur-yksk/medieval-castle.glb'))
objects=[o for o in bpy.context.scene.objects if o.type=='MESH']
corners=[o.matrix_world@Vector(v) for o in objects for v in o.bound_box]
lo=Vector(tuple(min(v[i] for v in corners) for i in range(3)))
hi=Vector(tuple(max(v[i] for v in corners) for i in range(3)))
images=[]
for im in bpy.data.images:
    if im.type != 'IMAGE':continue
    old=list(im.size);factor=min(1,1024/max(old))
    if factor<1:im.scale(max(1,round(old[0]*factor)),max(1,round(old[1]*factor)))
    images.append({'name':im.name,'original':old,'runtime':list(im.size)})
bpy.ops.export_scene.gltf(filepath=str(OUT/'medieval-castle.glb'),export_format='GLB',export_animations=False)
report={'bounds_blender':[list(lo),list(hi)],'meshes':len(objects),'images':images,
        'landmarks':{o.name:[[min((o.matrix_world@Vector(v))[i] for v in o.bound_box) for i in range(3)],
                             [max((o.matrix_world@Vector(v))[i] for v in o.bound_box) for i in range(3)]]
                     for o in objects if any(k in o.name for k in ['FrontDoor','Ground','FrontWood'])}}
(OUT/'preparation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('CASTLE',json.dumps(report))
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=8
scene.render.resolution_x=700;scene.render.resolution_y=700;scene.render.resolution_percentage=100
scene.world.color=(.3,.3,.3)
center=(lo+hi)/2;size=max(hi-lo)
bpy.ops.object.light_add(type='AREA',location=center+Vector((0,-size,size*1.5)))
bpy.context.object.data.energy=1800*size*size;bpy.context.object.data.size=size
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=size*1.25;cam.data.clip_end=size*20
for i,(x,y) in enumerate([(1,-1),(-1,1)]):
    cam.location=center+Vector((x*size,y*size,size*.8))
    cam.rotation_euler=(center-cam.location).to_track_quat('-Z','Y').to_euler()
    scene.render.filepath=str(PREVIEW/f'view-{i}.png');bpy.ops.render.render(write_still=True)
