"""Prepare the browser game for static hosting, without production sources."""
import re
import shutil
import hashlib
import json
import tempfile
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT.parent / 'dist'


def build():
    # Browser uploads store large resources in verified, portable archive parts.
    manifest = ROOT.parent / 'assets-pack.json'
    if not (ROOT / 'assets').exists() and manifest.exists():
        with tempfile.TemporaryFile(dir=ROOT.parent) as archive:
            for part in json.loads(manifest.read_text(encoding='utf-8'))['parts']:
                name = part['name']
                if Path(name).name != name:
                    raise ValueError('Invalid resource part name')
                data = (ROOT.parent / name).read_bytes()
                if hashlib.sha256(data).hexdigest() != part['sha256']:
                    raise ValueError(f'Corrupt resource part: {name}')
                archive.write(data)
            archive.seek(0)
            with tarfile.open(fileobj=archive, mode='r:gz') as packed:
                packed.extractall(ROOT, filter='data')
    # Only replace known output files; do not recursively delete user directories.
    DEST.mkdir(exist_ok=True)
    shutil.copy2(ROOT / 'index.html', DEST / 'index.html')
    for folder in ('src', 'styles', 'assets'):
        shutil.copytree(ROOT / folder, DEST / folder, dirs_exist_ok=True)
    shutil.copytree(ROOT / 'docs/licenses', DEST / 'docs/licenses', dirs_exist_ok=True)
    (DEST / '.nojekyll').touch()
    for origin in [DEST / 'index.html', *(DEST / 'styles').glob('*.css')]:
        text = origin.read_text(encoding='utf-8')
        pattern = r'(?:src|href)="([^"]+)"' if origin.suffix == '.html' else r'url\([\'"]?([^\)\'"\s]+)'
        for reference in re.findall(pattern, text):
            if reference.startswith(('https:', 'http:', 'data:', '#')):
                continue
            target = (origin.parent / reference.split('?')[0]).resolve()
            if not target.is_relative_to(DEST.resolve()) or not target.is_file():
                raise ValueError(f'Missing public file: {origin.name} -> {reference}')
    size = sum(p.stat().st_size for p in DEST.rglob('*') if p.is_file())
    print(f'Public site ready: {DEST} ({size / 1024**2:.1f} MiB)')


if __name__ == '__main__':
    build()
