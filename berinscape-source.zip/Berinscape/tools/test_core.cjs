// Run with Node.js. These checks exercise save invariants and recovery, not rendering.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const progression=fs.readFileSync(path.join(root,'src/systems/journey.js'),'utf8');
const {JourneyProgress,IntroSave}=vm.runInNewContext(progression+';({JourneyProgress,IntroSave})');
let data=null;
const storage={getItem:()=>data,setItem:(k,v)=>{data=v},removeItem:()=>{data=null}};
const progress=new JourneyProgress(),saves=new IntroSave(storage),rewards=[];
for(let id=0;id<120;id++)if(progress.collect(id).extraLives)rewards.push(id+1);
assert.equal(progress.coins,120);assert.equal(progress.lives,5);assert.deepEqual(rewards,[50,100]);
const state={version:2,coins:[...progress.collected],world:{area:'hall',x:0,z:30,yaw:0,zoom:9,destination:null},story:{state:'dialogue',kind:'throne',line:1}};
assert.equal(saves.write(state),true);progress.restore(saves.read().coins);assert.equal(progress.collect(1).added,false);assert.equal(progress.lives,5);
assert.equal(saves.validate({...state,coins:[1,1]}),null);
assert.equal(saves.validate({...state,world:{...state.world,z:999}}),null);
assert.equal(saves.validate({...state,story:{state:'dialogue',kind:'throne',line:3}}),null);
data='broken';assert.equal(saves.read(),null);
const unavailable=new IntroSave({getItem(){throw Error('denied')},setItem(){throw Error('quota')},removeItem(){}});
assert.equal(unavailable.read(),null);assert.equal(unavailable.write(state),false);
progress.reset();assert.equal(progress.coins,0);assert.equal(progress.lives,3);

async function loading(){
  let fail=true;const updates=[];
  const fetch=async()=>{if(fail){fail=false;throw Error('connection lost')}const chunks=[new Uint8Array([103,108,84,70]),new Uint8Array(4)];return{ok:true,headers:{get:()=>null},body:{getReader:()=>({read:async()=>chunks.length?{done:false,value:chunks.shift()}:{done:true}})}}};
  const context={window:{BERIN_ASSET_MANIFEST:{demo:{path:'demo.glb',bytes:8,label:'Demo'}}},location:{protocol:'http:'},setTimeout,clearTimeout,AbortController,Uint8Array,fetch};
  vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(root,'src/systems/asset-loader.js'),'utf8'),context);
  const loader=context.window.BerinAssets;loader.watch(['demo'],p=>updates.push(p.percent));
  await assert.rejects(loader.load('demo',{parseAsync:async b=>b.byteLength}),/connection lost/);
  assert.equal(loader.cache.size,0);assert.equal(await loader.load('demo',{parseAsync:async b=>b.byteLength}),8);
  assert.ok(updates.includes(50));assert.equal(updates.at(-1),100);
}
module.exports=loading().then(()=>console.log('OK: progressão, retomada, corrupção, armazenamento indisponível e recuperação de carregamento.'));
