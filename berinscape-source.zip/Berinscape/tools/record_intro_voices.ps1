param([Parameter(Mandatory=$true)][string]$RequestPath)
$ErrorActionPreference = 'Stop'
$requests = Get-Content -LiteralPath $RequestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$voice = New-Object -ComObject SAPI.SpVoice
$token = New-Object -ComObject SAPI.SpObjectToken
$token.SetId('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech_OneCore\Voices\Tokens\MSTTS_V110_ptBR_DanielM', '', $false)
$voice.Voice = $token
foreach ($request in $requests) {
    $path = Join-Path (Split-Path -Parent $RequestPath) ($request.key + '.wav')
    $stream = New-Object -ComObject SAPI.SpFileStream
    $stream.Open($path, 3, $false)
    $voice.AudioOutputStream = $stream
    $voice.Rate = $(if ($request.speaker -eq 'Berin') { -1 } else { 0 })
    $escaped = [System.Security.SecurityElement]::Escape($request.spoken)
    $xml = '<sapi><pitch middle="' + $request.pitch + '">' + $escaped + '</pitch></sapi>'
    $null = $voice.Speak($xml, 8)
    $stream.Close()
    Write-Output ($request.key + ': ' + (Get-Item -LiteralPath $path).Length + ' bytes')
}
