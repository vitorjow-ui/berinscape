"""Deterministic compressed transport copies; source GLBs and local fallbacks stay intact."""
import gzip,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'assets/manifest.js').read_text(encoding='utf-8').split('=',1)[1].rstrip(';'))
report={}
for key,asset in manifest.items():
    path=ROOT/asset['path'];data=path.read_bytes();packed=gzip.compress(data,compresslevel=5,mtime=0)
    path.with_suffix(path.suffix+'.gz').write_bytes(packed)
    report[key]={'binary_bytes':len(data),'transport_bytes':len(packed)}
(ROOT/'assets/transport.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(report)
