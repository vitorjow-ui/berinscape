"""Pack the prepared GLB for the existing direct-file browser entry point."""
import base64
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'assets/environments/forest-road-night/forest-road-night.glb'
TARGET=SOURCE.with_name('forest-model.js')

if __name__=='__main__':
    data=SOURCE.read_bytes()
    if data[:4]!=b'glTF':
        raise ValueError('Arquivo de origem não é GLB.')
    TARGET.write_text('window.FOREST_ROAD_GLB_BASE64="'+base64.b64encode(data).decode('ascii')+'";',encoding='utf-8')
    print('Floresta incorporada para abertura direta do index.html.')
