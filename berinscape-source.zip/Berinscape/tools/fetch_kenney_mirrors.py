"""Fetch selected CC0 Kenney recordings from a documented public mirror."""
import concurrent.futures,json,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'art/source/audio/premium-intro/kenney';OUT.mkdir(parents=True,exist_ok=True)
if (OUT/'sources.json').exists():
    previous=json.loads((OUT/'sources.json').read_text(encoding='utf-8'))
    if all((OUT/entry['name']).is_file() for entry in previous):
        print('Efeitos Kenney já preservados localmente.')
        raise SystemExit(0)
def get(url):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Berinscape-Asset-Preparation'}),timeout=40) as response:return response.read()
all_entries=[]
for repo in ['assets-sfx-ui','assets-sfx-combat']:
    tree=json.loads(get(f'https://api.github.com/repos/GeorgeQLe/{repo}/git/trees/main?recursive=1'))['tree']
    wanted=['click_002.ogg','select_001.ogg','confirmation_001.ogg','bong_001.ogg','impactMetal_heavy_000.ogg','impactPlate_heavy_000.ogg','impactPlank_medium_000.ogg','impactWood_medium_000.ogg','footstep_grass_000.ogg','footstep_grass_001.ogg','footstep_wood_000.ogg','footstep_wood_001.ogg','footstep_concrete_000.ogg','footstep_concrete_001.ogg','cloth1.ogg','cloth2.ogg','creak1.ogg','creak2.ogg','doorOpen_1.ogg','doorClose_1.ogg','handleSmallLeather1.ogg','handleSmallLeather2.ogg']
    for item in tree:
        path=item['path']
        if Path(path).name not in wanted and not (path.startswith('LICENSES/') and path.endswith('.txt')):continue
        if 'stable-audio' in path:continue
        all_entries.append(dict(repo=repo,path=path,url=f'https://raw.githubusercontent.com/GeorgeQLe/{repo}/main/'+path,name=Path(path).name))
def download(entry):
    target=OUT/entry['name']
    if not target.exists():target.write_bytes(get(entry['url']))
    return entry
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:entries=list(pool.map(download,all_entries))
(OUT/'sources.json').write_text(json.dumps(entries,indent=2),encoding='utf-8')
print([entry['name'] for entry in entries])
