"""Blender: create a reception rig/animations from the preserved static LOD1.

Run with Blender --background --factory-startup --python tools/rig_berinbinha.py.
Original source is never modified. This is a focused reception rig, not a combat rig.
"""
import bpy
import math
from pathlib import Path
from mathutils import Vector, Quaternion

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets/characters/berinbinha'
OUT.mkdir(parents=True, exist_ok=True)
AUTHORING = ROOT / 'art/source/characters/berinbinha/reception-v1'
AUTHORING.mkdir(parents=True, exist_ok=True)
bpy.context.preferences.filepaths.save_version = 0
PREVIEWS = ROOT / 'art/previews/berinbinha-reception'
PREVIEWS.mkdir(parents=True, exist_ok=True)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(ROOT / 'art/source/characters/berinbinha/v1/Berinbinha_LOD1.glb'))
meshes = [o for o in bpy.context.scene.objects if o.type == 'MESH']
for obj in meshes:
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

armature = bpy.data.armatures.new('Berinbinha_ReceptionRig')
rig = bpy.data.objects.new('Berinbinha_Reception', armature)
bpy.context.collection.objects.link(rig)
bpy.context.view_layer.objects.active = rig
bpy.ops.object.select_all(action='DESELECT')
rig.select_set(True)
bpy.ops.object.mode_set(mode='EDIT')

def bone(name, head, tail, parent=None):
    b = armature.edit_bones.new(name)
    b.head, b.tail = head, tail
    if parent:
        b.parent = armature.edit_bones[parent]
    return b

bone('Root', (0, 0, 0), (0, 0, .25))
bone('Body', (0, 0, .25), (0, 0, .65), 'Root')
bone('Head', (0, 0, .65), (0, 0, .95), 'Body')
for sign, side in [(1, 'L'), (-1, 'R')]:
    bone('UpperArm.'+side, (sign*.215, -.06, .665), (sign*.315, -.10, .53), 'Body')
    bone('Forearm.'+side, (sign*.315, -.10, .53), (sign*.395, -.15, .445), 'UpperArm.'+side)
    bone('Hand.'+side, (sign*.395, -.15, .445), (sign*.435, -.17, .42), 'Forearm.'+side)
bpy.ops.object.mode_set(mode='OBJECT')

def smooth(a, b, value):
    t = max(0., min(1., (value-a)/(b-a)))
    return t*t*(3-2*t)

for obj in meshes:
    groups = {b.name: obj.vertex_groups.new(name=b.name) for b in armature.bones}
    for vertex in obj.data.vertices:
        x, y, z = vertex.co
        ax, front = abs(x), -y
        # Keep rear cape and belly anchored; blend shoulder seam into the upper arm.
        def segment_distance(a,b):
            pa=Vector(a);pb=Vector(b);p=Vector((ax,front,z));d=pb-pa
            t=max(0.,min(1.,(p-pa).dot(d)/d.length_squared))
            return (p-(pa+d*t)).length
        distance=min(segment_distance((.215,.06,.665),(.315,.10,.53)),
                     segment_distance((.315,.10,.53),(.435,.17,.42)))
        upper=smooth(.22,.29,ax)*smooth(.53,.59,z)*(1-smooth(.13,.18,front))
        arm=max(smooth(.285,.315,ax),upper)*smooth(.0,.04,front)*smooth(.34,.39,z)*(1-smooth(.66,.72,z))
        side = 'L' if x > 0 else 'R'
        fore = smooth(.285, .365, ax)
        hand = smooth(.375, .425, ax)
        weights = {'Body': 1-arm,
                   'UpperArm.'+side: arm*(1-fore),
                   'Forearm.'+side: arm*fore*(1-hand),
                   'Hand.'+side: arm*fore*hand}
        for name, weight in weights.items():
            if weight > .00001:
                groups[name].add([vertex.index], weight, 'REPLACE')
    mod = obj.modifiers.new('Reception deformation', 'ARMATURE')
    mod.object = rig
    obj.parent = rig

scene = bpy.context.scene
scene.render.fps = 30
rig.animation_data_create()

def pose_arm(side, angle, elbow=0.):
    sign = 1 if side == 'L' else -1
    for prefix, amount in [('UpperArm.', angle), ('Forearm.', elbow)]:
        pb = rig.pose.bones[prefix+side]
        axis = pb.bone.matrix_local.to_3x3().inverted() @ Vector((0, 1, 0))
        pb.rotation_mode = 'QUATERNION'
        pb.rotation_quaternion = Quaternion(axis.normalized(), -sign*amount)

def key(frame):
    for pb in rig.pose.bones:
        pb.keyframe_insert('rotation_quaternion', frame=frame, group=pb.name)

idle = bpy.data.actions.new('Idle')
rig.animation_data.action = idle
for f in [1, 61]:
    pose_arm('L', 0); pose_arm('R', 0); key(f)
idle.use_fake_user = True

cheer = bpy.data.actions.new('Cheer')
rig.animation_data.action = cheer
for frame, left, right, elbow in [(1,0,0,0),(17,1.7,1.9,.12),(29,2.05,1.72,.3),
                                  (41,1.72,2.05,.14),(53,2.05,1.72,.3),
                                  (65,1.72,2.05,.14),(77,1.85,1.85,.2),(97,0,0,0)]:
    pose_arm('L', left, elbow); pose_arm('R', right, elbow); key(frame)
cheer.use_fake_user = True
for action in [idle, cheer]:
    rig.animation_data.action = action
    track = rig.animation_data.nla_tracks.new()
    track.name = action.name
    track.strips.new(action.name, 1, action)
    track.mute = True
rig.animation_data.action = None
for pb in rig.pose.bones:
    pb.rotation_mode = 'QUATERNION'
    pb.rotation_quaternion = (1, 0, 0, 0)

bpy.ops.wm.save_as_mainfile(filepath=str(AUTHORING / 'Berinbinha_Reception.blend'))
bpy.ops.object.select_all(action='DESELECT')
rig.select_set(True)
for obj in meshes:
    obj.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(OUT / 'Berinbinha_Reception.glb'), export_format='GLB',
                         use_selection=True, export_animations=True, export_animation_mode='ACTIONS',
                         export_skins=True, export_yup=True)

# Diagnostic renders: actual supplied mesh with generated skinning.
scene.render.engine = 'CYCLES'
scene.cycles.samples = 12
scene.cycles.device = 'CPU'
scene.render.resolution_x = 600
scene.render.resolution_y = 650
scene.render.resolution_percentage = 100
scene.world.color = (.14, .14, .14)
bpy.ops.object.camera_add(location=(1.8, -3.5, 1.35))
camera = bpy.context.object
camera.rotation_euler = (Vector((0, 0, .6))-camera.location).to_track_quat('-Z', 'Y').to_euler()
camera.data.type = 'ORTHO'
camera.data.ortho_scale = 1.7
scene.camera = camera
for location, energy, size in [((2,-3,4),350,4),((-2,-1,2),180,3),((0,2,3),250,3)]:
    bpy.ops.object.light_add(type='AREA', location=location)
    light=bpy.context.object
    light.data.energy=energy;light.data.shape='DISK';light.data.size=size
    light.rotation_euler=(Vector((0,0,.5))-light.location).to_track_quat('-Z','Y').to_euler()
for frame,name in [(1,'rest'),(29,'cheer')]:
    rig.animation_data.action=cheer
    scene.frame_set(frame)
    scene.render.filepath=str(PREVIEWS / (name+'.png'))
    bpy.ops.render.render(write_still=True)
print('RECEPTION RIG EXPORTED', OUT / 'Berinbinha_Reception.glb')
