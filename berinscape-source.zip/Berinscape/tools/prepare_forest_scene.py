"""Blender: preserve the supplied forest, remove its asset display, batch meshes.

Source is kept untouched. Output includes diagnostic overhead/perspective renders.
"""
import bpy
import json
import math
from pathlib import Path
from mathutils import Vector, Matrix

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/environments/forest-road-night'
PREVIEW=ROOT/'art/previews/forest-road-night'
OUT.mkdir(parents=True,exist_ok=True)
PREVIEW.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(ROOT/'art/source/environments/forest/dasy444/forest-road-night.glb'))
objects=[o for o in bpy.context.scene.objects if o.type=='MESH']
original_count=len(objects)
groups={}
terrain=None
for o in objects:
    corners=[o.matrix_world@Vector(v) for v in o.bound_box]
    center=sum(corners,Vector())/8
    if center.x < -5.2:
        bpy.data.objects.remove(o,do_unlink=True)
        continue
    # Clear a small arrival court so branches cannot grow through the new gate.
    is_ground=any(m and m.name.startswith('Material.003') for m in o.data.materials)
    if not is_ground and ((center.x-1.9)**2+(center.y-3.9)**2)**.5 < 1.4:
        bpy.data.objects.remove(o,do_unlink=True)
        continue
    # Leave a narrow landing in front of the tavern at the start of the road.
    if not is_ground and -.35 < center.x < 1.35 and center.y < -4.12:
        bpy.data.objects.remove(o,do_unlink=True)
        continue
    world=o.matrix_world.copy()
    o.parent=None
    o.matrix_world=Matrix.Identity(4)
    o.data.transform(world)
    if any(m and m.name.startswith('Material.003') for m in o.data.materials):
        terrain=o
        o.name='ForestGround'
        continue
    cell=(int((center.x+5)//2.5),int((center.y+5)//2.5))
    key=(cell,tuple(m.name for m in o.data.materials if m))
    groups.setdefault(key,[]).append(o)
for index,group in enumerate(groups.values()):
    bpy.ops.object.select_all(action='DESELECT')
    for o in group:o.select_set(True)
    bpy.context.view_layer.objects.active=group[0]
    bpy.ops.object.join()
    bpy.context.object.name=f'ForestVegetation_{index:02d}'
objects=[o for o in bpy.context.scene.objects if o.type=='MESH']
bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=terrain
bpy.ops.export_scene.gltf(filepath=str(OUT/'forest-road-night.glb'),export_format='GLB',use_selection=True,export_animations=False)
report={'source_meshes':original_count,'render_meshes':len(objects),'batches':len(groups),'terrain':terrain.name,
        'bounds':[[min((o.matrix_world@Vector(v))[axis] for o in objects for v in o.bound_box),
                   max((o.matrix_world@Vector(v))[axis] for o in objects for v in o.bound_box)] for axis in range(3)]}
(OUT/'preparation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.samples=12;scene.cycles.device='CPU'
scene.render.resolution_x=900;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.world.color=(.22,.22,.22)
bpy.ops.object.light_add(type='AREA',location=(0,-2,8));bpy.context.object.data.energy=1300;bpy.context.object.data.size=10
bpy.ops.object.camera_add(location=(0,0,14));cam=bpy.context.object;cam.data.type='ORTHO';cam.data.ortho_scale=12;scene.camera=cam
cam.rotation_euler=(Vector((0,0,0))-cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.filepath=str(PREVIEW/'overhead.png');bpy.ops.render.render(write_still=True)
cam.location=(8,-10,6);cam.rotation_euler=(Vector((0,0,.3))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=14
scene.render.filepath=str(PREVIEW/'perspective.png');bpy.ops.render.render(write_still=True)
print('FOREST PREPARED',report)
