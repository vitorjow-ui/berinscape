"""Serve only the game directory on this computer. Run with Python 3."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]

class GameHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control','no-cache')
        super().end_headers()

    def do_GET(self):
        source=Path(self.translate_path(self.path))
        packed=source.with_suffix(source.suffix+'.gz')
        if source.suffix=='.glb' and source.is_file() and packed.is_file() and 'gzip' in self.headers.get('Accept-Encoding',''):
            self.send_response(200)
            self.send_header('Content-Type','model/gltf-binary')
            self.send_header('Content-Encoding','gzip')
            self.send_header('Content-Length',str(packed.stat().st_size))
            self.send_header('X-Asset-Bytes',str(source.stat().st_size))
            self.send_header('Vary','Accept-Encoding')
            self.end_headers()
            with packed.open('rb') as stream:shutil.copyfileobj(stream,self.wfile)
            return
        super().do_GET()

if __name__ == '__main__':
    handler = partial(GameHandler, directory=str(ROOT))
    server = ThreadingHTTPServer(('127.0.0.1', 8765), handler)
    print('Berinscape: http://127.0.0.1:8765 — Ctrl+C para encerrar')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
