"""Generate byte budgets for binary loading and lazy direct-file fallbacks."""
import json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
berin=ROOT/'assets/characters/berin/Berin_LOD0.glb'
shutil.copyfile(ROOT/'art/source/characters/berin/v2/Berin_LOD0.glb',berin)
assets={
 'berin':('Berin','assets/characters/berin/Berin_LOD0.glb','assets/characters/berin/berin-model.js','BERIN_GLB_BASE64'),
 'forest':('Floresta Negra','assets/environments/forest-road-night/forest-road-night.glb','assets/environments/forest-road-night/forest-model.js','FOREST_ROAD_GLB_BASE64'),
 'wolf':('Lobos da floresta','assets/animals/wolf-puppy/wolf-puppy.glb','assets/animals/wolf-puppy/wolf-model.js','WOLF_PUPPY_GLB_BASE64'),
 'castle':('Castelo de Berin','assets/environments/medieval-castle/medieval-castle.glb','assets/environments/medieval-castle/castle-model.js','MEDIEVAL_CASTLE_GLB_BASE64'),
 'minion':('Berinbinhas e salão','assets/characters/berinbinha/Berinbinha_Reception.glb','assets/characters/berinbinha/berinbinha-model.js','BERINBINHA_GLB_BASE64')}
result={k:dict(label=v[0],path=v[1],fallback=v[2],global_=v[3],bytes=(ROOT/v[1]).stat().st_size) for k,v in assets.items()}
for value in result.values():value['global']=value.pop('global_')
(ROOT/'assets/manifest.js').write_text('window.BERIN_ASSET_MANIFEST='+json.dumps(result,ensure_ascii=False,separators=(',',':'))+';',encoding='utf-8')
print({k:v['bytes'] for k,v in result.items()})
