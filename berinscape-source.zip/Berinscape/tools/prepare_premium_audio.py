"""Edit recorded foley, local speech and licensed field recordings for the intro."""
import base64,json,os,re,subprocess,sys,wave
from pathlib import Path
sys.path.insert(0,str(Path(os.environ['TEMP'])/'berinscape-media-tools'))
sys.path.insert(0,str(Path.home()/'AppData/Local/Temp/berinscape-media-tools'))
import imageio_ffmpeg,numpy as np
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'art/source/audio/premium-intro';OUT=ROOT/'assets/audio/premium';OUT.mkdir(parents=True,exist_ok=True)
FFMPEG=imageio_ffmpeg.get_ffmpeg_exe();RATE=22050;bank={};metadata={}
def decode(path,rate=RATE):
    run=subprocess.run([FFMPEG,'-v','error','-i',str(path),'-ac','1','-ar',str(rate),'-f','f32le','pipe:1'],capture_output=True,check=True)
    return np.frombuffer(run.stdout,dtype='<f4').copy()
def normalize(x,peak=.72):
    x=np.nan_to_num(x);x=x-np.mean(x)
    return x*(peak/max(.0001,float(np.max(np.abs(x)))))
def mix(*layers):
    size=max(len(x)+round(delay*RATE) for x,gain,delay in layers);out=np.zeros(size,dtype=np.float32)
    for x,gain,delay in layers:
        start=round(delay*RATE);out[start:start+len(x)]+=x*gain
    return out
def fade(x,seconds=.02):
    x=x.copy();n=min(round(seconds*RATE),len(x)//2);x[:n]*=np.linspace(0,1,n);x[-n:]*=np.linspace(1,0,n);return x
def loop(x,seconds=1.5):
    n=min(round(seconds*RATE),len(x)//4);theta=np.linspace(0,np.pi/2,n)
    return np.concatenate([x[n:-n],x[-n:]*np.cos(theta)+x[:n]*np.sin(theta)]).astype(np.float32)
def shifted(x,ratio):return np.interp(np.arange(0,len(x),ratio),np.arange(len(x)),x).astype(np.float32)
def save(key,x,mp3=False,peak=.72):
    transient=key.startswith(('ui-','step-')) or key in ('coin','extra-life')
    x=normalize(fade(x,.001 if transient else .012),peak);path=OUT/(key+('.mp3' if mp3 else '.wav'))
    if mp3:subprocess.run([FFMPEG,'-v','error','-y','-f','f32le','-ar',str(RATE),'-ac','1','-i','pipe:0','-c:a','libmp3lame','-b:a','96k',str(path)],input=x.astype('<f4').tobytes(),check=True)
    else:
        with wave.open(str(path),'wb') as stream:stream.setnchannels(1);stream.setsampwidth(2);stream.setframerate(RATE);stream.writeframes((np.clip(x,-1,1)*32767).astype('<i2').tobytes())
    actual=decode(path);peak_value=float(np.max(np.abs(actual)))
    if peak_value>.98:raise ValueError('Clipping: '+key)
    metadata[key]={'path':'assets/audio/premium/'+path.name,'bytes':path.stat().st_size,'duration':len(actual)/RATE,'peak':round(peak_value,4)}
    bank[key]=base64.b64encode(path.read_bytes()).decode('ascii')

k=SRC/'kenney';raw={p.stem:decode(p) for p in k.glob('*.ogg')}
wood=raw['impactWood_medium_000'];metal=raw['impactPlate_heavy_000'];cloth=raw['cloth2'];leather=raw['handleSmallLeather2']
save('ui-hover',leather[:round(.18*RATE)],peak=.45)
save('ui-click',mix((wood,.7,0),(cloth,.25,.015),(metal,.2,.025)),peak=.78)
save('ui-begin',mix((shifted(wood,.78),.7,0),(shifted(metal,.72),.8,.04),(leather,.25,.01)),peak=.84)
save('transition',mix((shifted(cloth,.55),.6,0),(shifted(raw['creak1'],.85),.16,.16)),peak=.65)
save('coin',shifted(raw['bong_001'],1.7)[:round(.26*RATE)],peak=.55)
save('extra-life',mix((raw['confirmation_001'],.75,0),(shifted(raw['bong_001'],1.2),.3,.18)),peak=.75)
save('chair',mix((shifted(raw['creak1'],.8),.65,0),(cloth,.25,.02)),peak=.65)
save('door-open',mix((raw['doorOpen_1'],.7,0),(shifted(raw['creak2'],.8),.55,.08)),peak=.75)
save('gate',mix((shifted(raw['creak2'],.55),.7,0),(shifted(raw['impactMetal_heavy_000'],.72),.6,.1),(shifted(metal,.67),.5,.8),(shifted(raw['impactPlank_medium_000'],.7),.5,1.55)),peak=.8)
save('twig',shifted(raw['creak1'],1.15),peak=.45)
for surface in ['grass','wood','concrete']:
    for index in [0,1]:save('step-'+surface+'-'+str(index),raw[f'footstep_{surface}_00{index}'],peak=.55)
for entry in json.loads((SRC/'voices/requests.json').read_text(encoding='utf-8')):
    key=entry['key'];x=decode(SRC/'voices'/(key+'.wav'))
    if key=='crowd':
        previous=decode(ROOT/'assets/audio/voices/berin-crowd.wav');x=mix((x,.8,0),(shifted(x,.96),.35,.12),(shifted(x,1.05),.3,.23),(previous,.2,.05));save('crowd',loop(x,.3),mp3=True,peak=.7)
    else:save(key,x,mp3=True,peak=.7)
laugh=decode(SRC/'laugh-source.mp3');save('berin-laugh',mix((laugh,1,0),(shifted(laugh,.97),.13,.04)),mp3=True,peak=.72)
save('minion-laugh',shifted(laugh[:round(1.4*RATE)],1.23),mp3=True,peak=.65)
for key,seconds in [('night',46),('wind',32)]:
    x=decode(SRC/(key+'-source.mp3'))[:round(seconds*RATE)];save('forest-'+key,loop(x,1.8),mp3=True,peak=.6)

music=ROOT/'assets/audio/music/juggernaut-scott-buckley.mp3'
for name,start,duration in [('reveal',46,42),('hall',7,48),('throne',105,52)]:
    target=ROOT/'assets/audio/music'/('juggernaut-'+name+'.mp3')
    subprocess.run([FFMPEG,'-v','error','-y','-ss',str(start),'-i',str(music),'-t',str(duration),'-af',f'loudnorm=I=-20:TP=-4:LRA=7,afade=t=in:d=1,afade=t=out:st={duration-2}:d=2','-ar','44100','-ac','2','-b:a','160k',str(target)],check=True)

(OUT/'manifest.js').write_text('window.BERIN_AUDIO_MANIFEST='+json.dumps(metadata,separators=(',',':'))+';',encoding='utf-8')
(OUT/'audio-bank.js').write_text('window.BERIN_PREMIUM_AUDIO='+json.dumps(bank,separators=(',',':'))+';',encoding='utf-8')
(OUT/'analysis.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
provenance=[]
for key,author,sound in [('night','timothyd4y','587907'),('wind','NomadApe','444921'),('laugh','balloonhead','362330')]:
    html=(SRC/(key+'-source.html')).read_text(encoding='utf-8');url=next(u for u in re.findall(r'https://[^\s"<>]+hq\.mp3',html) if 'freesound' in u)
    provenance.append(dict(name=key,author=author,page=f'https://freesound.org/people/{author}/sounds/{sound}/',url=url,license='CC0',source='public preview'))
provenance.append(dict(name='Juggernaut',author='Scott Buckley',license='CC BY 4.0',page='https://www.scottbuckley.com.au/library/juggernaut/',url='https://www.scottbuckley.com.au/library/wp-content/uploads/2022/07/Juggernaut.mp3'))
(SRC/'sources.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
print(json.dumps({'clips':len(metadata),'bytes':sum(m['bytes'] for m in metadata.values()),'maximum_peak':max(m['peak'] for m in metadata.values())}))
