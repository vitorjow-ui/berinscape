"""Render fixed dialogue with the installed Windows voice, entirely offline."""
import json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'art/source/audio/premium-intro/voices';OUT.mkdir(parents=True,exist_ok=True)
text=(ROOT/'src/story/intro.js').read_text(encoding='utf-8')
lines=re.findall(r"speaker:'([^']+)'.*?text:'([^']+)'",text)
report=[]
for index,(speaker,line) in enumerate(lines):
    slug=['crowd','reception-order','advisor-warning','berin-answer','advisor-reply'][index]
    spoken=line.replace('irá !!','ira!').replace('venham o campeão','venha o campeão')
    parts=re.split(r'hahaha',spoken,flags=re.I) if slug=='berin-answer' else [re.sub(r'hahaha','',spoken,flags=re.I)]
    for number,part in enumerate(parts):
        report.append(dict(key=slug+('-a' if number==0 else '-b') if slug=='berin-answer' else slug,speaker=speaker,text=line,spoken=part.strip(),pitch=-4 if speaker=='Berin' else 5))
(OUT/'requests.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
subprocess.run(['powershell','-NoProfile','-File',str(ROOT/'tools/record_intro_voices.ps1'),'-RequestPath',str(OUT/'requests.json')],check=True)
