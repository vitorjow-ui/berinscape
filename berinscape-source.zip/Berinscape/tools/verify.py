"""Check game entry references and that the browser model matches its source."""
import base64
import re
import xml.etree.ElementTree as ET
import gzip
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def check_reference(origin, reference):
    if reference.startswith(('https:', 'http:', '#', 'data:')):
        return
    resolved = (origin.parent / reference.split('?')[0]).resolve()
    if not resolved.is_relative_to(ROOT) or not resolved.is_file():
        raise ValueError(f'Referência inválida: {origin.name} -> {reference}')


if __name__ == '__main__':
    html = ROOT / 'index.html'
    text = html.read_text(encoding='utf-8')
    for reference in re.findall(r'(?:src|href)="([^"]+)"', text):
        check_reference(html, reference)
    for css in (ROOT / 'styles').glob('*.css'):
        for reference in re.findall(r'url\([\'"]?([^\)\'"\s]+)', css.read_text(encoding='utf-8')):
            check_reference(css, reference)
    for js in (ROOT / 'src').rglob('*.js'):
        for reference in re.findall(r"(?:new Audio\(|const barGif=)'([^']+)'", js.read_text(encoding='utf-8')):
            check_reference(html, reference)
    app = (ROOT / 'src/game.js').read_text(encoding='utf-8')
    ids = re.findall(r'id="([^"]+)"', text)
    refs = re.findall(r"\$\('([^']+)'\)", app)
    assert len(ids) == len(set(ids)), 'IDs duplicados'
    assert set(refs) <= set(ids), 'Elemento de interface ausente'
    packed = (ROOT / 'assets/characters/berin/berin-model.js').read_text(encoding='utf-8')
    encoded = re.fullmatch(r'window\.BERIN_GLB_BASE64="([A-Za-z0-9+/=]+)";', packed).group(1)
    assert base64.b64decode(encoded, validate=True) == (ROOT / 'art/source/characters/berin/v2/Berin_LOD0.glb').read_bytes(), 'Modelo diverge da origem'
    minion = (ROOT / 'assets/characters/berinbinha/berinbinha-model.js').read_text(encoding='utf-8')
    minion_encoded = re.fullmatch(r'window\.BERINBINHA_GLB_BASE64="([A-Za-z0-9+/=]+)";', minion).group(1)
    assert base64.b64decode(minion_encoded, validate=True) == (ROOT / 'assets/characters/berinbinha/Berinbinha_Reception.glb').read_bytes(), 'Berinbinha diverge do modelo animado'
    forest = (ROOT / 'assets/environments/forest-road-night/forest-model.js').read_text(encoding='utf-8')
    forest_encoded = re.fullmatch(r'window\.FOREST_ROAD_GLB_BASE64="([A-Za-z0-9+/=]+)";', forest).group(1)
    assert base64.b64decode(forest_encoded, validate=True) == (ROOT / 'assets/environments/forest-road-night/forest-road-night.glb').read_bytes(), 'Floresta incorporada diverge do GLB'
    wolf = (ROOT / 'assets/animals/wolf-puppy/wolf-model.js').read_text(encoding='utf-8')
    wolf_encoded = re.fullmatch(r'window\.WOLF_PUPPY_GLB_BASE64="([A-Za-z0-9+/=]+)";', wolf).group(1)
    assert base64.b64decode(wolf_encoded, validate=True) == (ROOT / 'assets/animals/wolf-puppy/wolf-puppy.glb').read_bytes(), 'Lobo incorporado diverge do GLB'
    castle = (ROOT / 'assets/environments/medieval-castle/castle-model.js').read_text(encoding='utf-8')
    castle_encoded = re.fullmatch(r'window\.MEDIEVAL_CASTLE_GLB_BASE64="([A-Za-z0-9+/=]+)";', castle).group(1)
    assert base64.b64decode(castle_encoded, validate=True) == (ROOT / 'assets/environments/medieval-castle/medieval-castle.glb').read_bytes(), 'Castelo incorporado diverge do GLB'
    assert '2964776c3847493ba908fd192e071ca3' in text, 'Crédito do castelo ausente'
    manifest=json.loads((ROOT/'assets/manifest.js').read_text(encoding='utf-8').split('=',1)[1].rstrip(';'))
    for name,asset in manifest.items():
        binary=(ROOT/asset['path']).read_bytes()
        assert len(binary)==asset['bytes'] and binary[:4]==b'glTF', f'Manifesto inválido: {name}'
        assert gzip.decompress((ROOT/(asset['path']+'.gz')).read_bytes())==binary, f'Transporte inválido: {name}'
        assert (ROOT/asset['fallback']).is_file(), f'Fallback local ausente: {name}'
    assert not re.search(r'<script src="assets/(?:characters|environments|animals)/',text), 'Modelos carregando antecipadamente no menu'
    ET.parse(ROOT / 'assets/ui/branding/berin-logo.svg')
    assert (ROOT / 'assets/audio/music/fate-and-fortune-scott-buckley.mp3').stat().st_size > 100000
    assert 'Scott Buckley' in text and 'creativecommons.org/licenses/by/4.0/' in text
    audio_dir=ROOT/'assets/audio/premium'
    audio=json.loads((audio_dir/'manifest.js').read_text(encoding='utf-8').split('=',1)[1].rstrip(';'))
    bank=json.loads((audio_dir/'audio-bank.js').read_text(encoding='utf-8').split('=',1)[1].rstrip(';'))
    assert set(audio)==set(bank) and len(audio)==26, 'Banco de áudio incompleto'
    for key,entry in audio.items():
        binary=(ROOT/entry['path']).read_bytes()
        assert len(binary)==entry['bytes'] and entry['duration']>0, key
        assert 0<entry['peak']<=.85, f'Pico de áudio inválido: {key}'
        assert base64.b64decode(bank[key],validate=True)==binary, f'Fallback de áudio diverge: {key}'
    runtime='\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'src').rglob('*.js'))
    assert 'speechSynthesis' not in runtime, 'Voz ainda depende do navegador'
    assert "animation.src='assets/ui/menu/berin-tavern.gif?play='" in app, 'Cena original da taverna ausente'
    assert (ROOT/'assets/ui/menu/berin-tavern.gif').read_bytes()[:6] in (b'GIF87a',b'GIF89a')
    for slider in ['volume','music-volume','ambience-volume','effects-volume','voice-volume']:
        assert slider in ids, f'Controle de volume ausente: {slider}'
    for cue in ['reveal','hall','throne']:
        assert (ROOT/f'assets/audio/music/juggernaut-{cue}.mp3').stat().st_size>100000
    print('OK: referências, interface, logo, áudio, créditos e modelo incorporado.')
