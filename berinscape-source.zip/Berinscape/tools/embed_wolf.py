"""Pack the prepared wolf for opening index.html directly from disk."""
import base64
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'assets/animals/wolf-puppy/wolf-puppy.glb'
TARGET=SOURCE.with_name('wolf-model.js')

if __name__=='__main__':
    data=SOURCE.read_bytes()
    if data[:4]!=b'glTF':
        raise ValueError('Origem não é um GLB válido.')
    TARGET.write_text('window.WOLF_PUPPY_GLB_BASE64="'+base64.b64encode(data).decode('ascii')+'";',encoding='utf-8')
    print('Lobo incorporado para o navegador.')
