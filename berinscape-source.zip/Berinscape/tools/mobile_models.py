"""Build touchscreen models with smaller embedded textures and unchanged geometry."""
import io
import json
import struct
from pathlib import Path
from PIL import Image


def mobile_model(source, destination):
    raw = source.read_bytes()
    json_size = struct.unpack_from('<I', raw, 12)[0]
    model = json.loads(raw[20:20 + json_size])
    binary = raw[28 + json_size:]
    views = model['bufferViews']
    images = {image['bufferView']: image for image in model['images']}
    output = bytearray()
    cursor = 0
    for index, view in sorted(enumerate(views), key=lambda entry: entry[1].get('byteOffset', 0)):
        start = view.get('byteOffset', 0)
        end = start + view['byteLength']
        if start < cursor:
            raise ValueError('Overlapping buffer views in ' + source.name)
        output.extend(binary[cursor:start])
        output.extend(bytes(-len(output) % 4))
        payload = binary[start:end]
        if index in images:
            with Image.open(io.BytesIO(payload)) as texture:
                if max(texture.size) > 512:
                    texture.thumbnail((512, 512), Image.Resampling.LANCZOS)
                    stream = io.BytesIO()
                    texture.save(stream, format=texture.format)
                    payload = stream.getvalue()
        view.update(byteOffset=len(output), byteLength=len(payload))
        output.extend(payload)
        cursor = end
    output.extend(binary[cursor:])
    output.extend(bytes(-len(output) % 4))
    model['buffers'][0]['byteLength'] = len(output)
    encoded = json.dumps(model, separators=(',', ':')).encode()
    encoded += b' ' * (-len(encoded) % 4)
    destination.write_bytes(struct.pack('<4sIIII', b'glTF', 2, 28 + len(encoded) + len(output), len(encoded), 0x4E4F534A) + encoded + struct.pack('<II', len(output), 0x004E4942) + output)


def prepare_mobile(site):
    manifest = site / 'assets/manifest.js'
    entries = json.loads(manifest.read_text().split('=', 1)[1].strip().rstrip(';'))
    for asset in entries.values():
        source = site / asset['path']
        destination = source.with_suffix('.mobile.glb')
        mobile_model(source, destination)
        asset.update(path=destination.relative_to(site).as_posix(), bytes=destination.stat().st_size)
    with manifest.open('a') as script:
        script.write('\nif(location.protocol !== "file:" && matchMedia("(pointer: coarse)").matches) window.BERIN_ASSET_MANIFEST=' + json.dumps(entries) + ';\n')
