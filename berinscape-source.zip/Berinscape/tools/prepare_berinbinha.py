"""Create the local-file-compatible Berinbinha script from the animated reception model."""
import base64
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'assets/characters/berinbinha/Berinbinha_Reception.glb'
TARGET = ROOT / 'assets/characters/berinbinha/berinbinha-model.js'

if __name__ == '__main__':
    data = SOURCE.read_bytes()
    if data[:4] != b'glTF':
        raise ValueError('A origem não é um GLB válido.')
    TARGET.parent.mkdir(parents=True, exist_ok=True)
    TARGET.write_text('window.BERINBINHA_GLB_BASE64="' + base64.b64encode(data).decode('ascii') + '";', encoding='utf-8')
    print('Berinbinha do navegador atualizado a partir de Berinbinha_Reception.glb.')
