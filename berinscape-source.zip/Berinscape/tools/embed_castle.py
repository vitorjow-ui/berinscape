"""Embed the prepared castle for the direct-file entry point."""
import base64
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'assets/environments/medieval-castle/medieval-castle.glb'
data=source.read_bytes()
assert data[:4]==b'glTF'
source.with_name('castle-model.js').write_text('window.MEDIEVAL_CASTLE_GLB_BASE64="'+base64.b64encode(data).decode('ascii')+'";',encoding='utf-8')
