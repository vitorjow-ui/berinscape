"""Blender: normalize the supplied static wolf and create a simple walking rig."""
import bpy
import math
import json
from mathutils import Vector,Matrix,Quaternion
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'assets/animals/wolf-puppy'
PREVIEW=ROOT/'art/previews/wolf-puppy'
OUT.mkdir(parents=True,exist_ok=True);PREVIEW.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(ROOT/'art/source/animals/cod-ghosts-wolf-puppy/original.glb'))
meshes=[]
rotation=Matrix.Rotation(-math.pi/2,4,'Z')
for o in list(bpy.context.scene.objects):
    if o.type!='MESH':continue
    if 'Cube' in o.name:
        bpy.data.objects.remove(o,do_unlink=True);continue
    world=o.matrix_world.copy()
    bounds=[world@Vector(v) for v in o.bound_box]
    largest=max(max(v[i] for v in bounds)-min(v[i] for v in bounds) for i in range(3))
    if largest>5:
        world=Matrix.Scale(.01,4)@world
    else:
        # Separate eye overlays were exported in metres but offset from the main head.
        world=Matrix.Translation((.49,0,0))@world
    o.parent=None;o.matrix_world=Matrix.Identity(4);o.data.transform(rotation@world)
    meshes.append(o)
minimum=min(v.co.z for o in meshes for v in o.data.vertices)
for o in meshes:
    o.data.transform(Matrix.Translation((0,0,-minimum)))
for o in list(bpy.context.scene.objects):
    if o.type!='MESH':bpy.data.objects.remove(o,do_unlink=True)

armature=bpy.data.armatures.new('WolfWalkRig');rig=bpy.data.objects.new('WolfPuppy',armature)
bpy.context.collection.objects.link(rig);bpy.context.view_layer.objects.active=rig
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
def bone(name,a,b,parent=None):
    obj=armature.edit_bones.new(name);obj.head=a;obj.tail=b
    if parent:obj.parent=armature.edit_bones[parent]
bone('Root',(0,0,0),(0,0,.3))
bone('Body',(0,.3,.6),(0,-.24,.71),'Root')
bone('Head',(0,-.37,.77),(0,-.62,.9),'Body')
bone('Tail',(0,.55,.64),(0,.91,.25),'Body')
for sign,side in [(1,'L'),(-1,'R')]:
    for kind,y in [('Front',-.24),('Rear',.39)]:
        x=sign*.105
        bone(kind+'Upper.'+side,(x,y,.64),(x,y+(.07 if kind=='Rear' else 0),.33),'Body')
        bone(kind+'Lower.'+side,(x,y+(.07 if kind=='Rear' else 0),.33),(x,y,.09),kind+'Upper.'+side)
        bone(kind+'Paw.'+side,(x,y,.09),(x,y-.1,.035),kind+'Lower.'+side)
bpy.ops.object.mode_set(mode='OBJECT')
def smooth(a,b,value):
    t=max(0.,min(1.,(value-a)/(b-a)));return t*t*(3-2*t)
for o in meshes:
    groups={bone.name:o.vertex_groups.new(name=bone.name) for bone in armature.bones}
    for vertex in o.data.vertices:
        x,y,z=vertex.co;forward=-y;side='L' if x>0 else 'R'
        weights={}
        head=smooth(.34,.49,forward)
        tail=smooth(.52,.69,y)*(1-smooth(.75,.88,z))
        kind='Front' if forward>-.06 else 'Rear'
        leg=(1-smooth(.48,.67,z))*smooth(.025,.075,abs(x))
        leg*=smooth(-.56,-.48,forward)*(1-smooth(.42,.48,forward))
        leg*=1-head;leg*=1-tail
        lower=1-smooth(.25,.4,z);paw=1-smooth(.07,.14,z)
        weights[kind+'Upper.'+side]=leg*(1-lower)
        weights[kind+'Lower.'+side]=leg*lower*(1-paw)
        weights[kind+'Paw.'+side]=leg*lower*paw
        weights['Head']=head*(1-tail);weights['Tail']=tail
        weights['Body']=max(0,1-sum(weights.values()))
        total=sum(weights.values()) or 1
        for name,weight in weights.items():
            if weight>.00001:groups[name].add([vertex.index],weight/total,'REPLACE')
    modifier=o.modifiers.new('Walking','ARMATURE');modifier.object=rig;o.parent=rig

rig.animation_data_create();scene=bpy.context.scene;scene.render.fps=30
def pose(name,angle,axis=(1,0,0)):
    b=rig.pose.bones[name];b.rotation_mode='QUATERNION';local=b.bone.matrix_local.to_3x3().inverted()@Vector(axis);b.rotation_quaternion=Quaternion(local.normalized(),angle)
def key(frame):
    for b in rig.pose.bones:b.keyframe_insert('rotation_quaternion',frame=frame,group=b.name)
idle=bpy.data.actions.new('Idle');rig.animation_data.action=idle
for f in [1,61]:key(f)
walk=bpy.data.actions.new('Walk');rig.animation_data.action=walk
for frame in range(1,34,4):
    phase=(frame-1)/32*math.pi*2
    for kind,side,offset in [('Front','L',0),('Front','R',math.pi),('Rear','L',math.pi*.5),('Rear','R',math.pi*1.5)]:
        swing=math.sin(phase+offset)
        pose(kind+'Upper.'+side,swing*.25)
        pose(kind+'Lower.'+side,max(0,-swing)*.25)
        pose(kind+'Paw.'+side,-swing*.09)
    pose('Body',math.sin(phase*2)*.012)
    pose('Head',math.sin(phase)*.018,(0,0,1))
    pose('Tail',math.sin(phase)*.07,(0,0,1));key(frame)
for action in [idle,walk]:
    action.use_fake_user=True;track=rig.animation_data.nla_tracks.new();track.name=action.name;track.strips.new(action.name,1,action);track.mute=True
rig.animation_data.action=None
for b in rig.pose.bones:b.rotation_mode='QUATERNION';b.rotation_quaternion=(1,0,0,0)
authoring=ROOT/'art/source/animals/cod-ghosts-wolf-puppy/prepared';authoring.mkdir(parents=True,exist_ok=True)
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(authoring/'WolfPuppy_Walk.blend'))
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in meshes:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(OUT/'wolf-puppy.glb'),export_format='GLB',use_selection=True,export_animations=True,export_animation_mode='ACTIONS',export_skins=True)

scene.render.engine='CYCLES';scene.cycles.samples=16;scene.cycles.device='CPU'
scene.render.resolution_x=800;scene.render.resolution_y=600;scene.render.resolution_percentage=100;scene.world.color=(.15,.15,.15)
bpy.ops.object.camera_add(location=(2.5,-2.7,1.7));camera=bpy.context.object;camera.rotation_euler=(Vector((0,0,.5))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=2.3;scene.camera=camera
for location,energy in [((2,-3,3),280),((-2,0,2),180)]:
    bpy.ops.object.light_add(type='AREA',location=location);light=bpy.context.object;light.data.energy=energy;light.data.size=3;light.rotation_euler=(Vector((0,0,.5))-light.location).to_track_quat('-Z','Y').to_euler()
for frame,name in [(1,'idle'),(9,'walk')]:
    rig.animation_data.action=walk;scene.frame_set(frame);scene.render.filepath=str(PREVIEW/(name+'.png'));bpy.ops.render.render(write_still=True)
print('WOLF PREPARED',len(meshes),'meshes',len(armature.bones),'bones')
