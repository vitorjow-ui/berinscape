# BERIN SCAPE — Uma Jornada Épica

Jogo de fantasia medieval para navegador. O trecho atual contém menu da taverna, Berin controlável, coleta de moedas na floresta, recepção dos Berinbinhas e caminhada até a conversa no trono.

## Jogar

Abra **index.html** no navegador. É necessária internet para carregar o Three.js; imagens, modelo e música ficam no projeto.

Para desenvolvimento, execute `python tools/serve.py` nesta pasta e abra http://127.0.0.1:8765. Não precisa instalar pacotes. Para conferir os arquivos e caminhos, execute `python tools/verify.py`.

Controles: clique no chão ou WASD/setas para andar; Shift dobra a velocidade; roda do mouse ajusta o zoom; Esc pausa e permite continuar, configurar ou salvar e voltar ao menu.

## Estado atual

Prioridades 1–30 aplicadas. Noite, tochas, materiais e sombras: [melhorias 21–30](docs/TOP30-IMPLEMENTATION.md). As melhorias de animação, saída da taverna, entrada física do castelo e áudio estão descritas em [melhorias 11–20 e testes](docs/TOP20-IMPLEMENTATION.md). Prioridades 1–10: carregamento por etapa, pausa, retomada automática, correção de apoio dos pés, proteção da câmera e acabamento de cenas. O menu oferece Continuar quando há uma jornada salva. Veja [implementação e testes](docs/TOP10-IMPLEMENTATION.md).

A prévia por servidor local usa os modelos binários comprimidos. A abertura direta mantém carregamento local por scripts sob demanda, mas não pôde ser validada pela ferramenta de navegador nesta revisão. O progresso é guardado neste navegador e nesta origem.

## Organização

| Pasta | Conteúdo |
| --- | --- |
| `src/` | Código executado pelo jogo |
| `src/scenes/` | Construção e controles de cada fase; atualmente `forest.js` |
| `src/audio/` | Reprodução da trilha, ambiente e efeitos |
| `styles/` | Aparência geral e tema do menu |
| `assets/characters/` | Personagens preparados para carregar no navegador |
| `assets/ui/` | Logo, imagens e animações do menu |
| `assets/audio/music/` | Gravações de música usadas no jogo |
| `art/source/` | Pacotes de produção, Blender, texturas e modelos originais |
| `art/references/` | Referências visuais e animações recebidas |
| `art/previews/` | Imagens de inspeção dos materiais |
| `docs/` | Estado do projeto, estrutura, licenças e histórico |
| `tools/` | Verificação, servidor local e preparação de recursos |
| `archive/` | Cópia do protótipo anterior à organização; não é executada |

O ponto de entrada continua sendo **index.html**. Leia [docs/PROJECT.md](docs/PROJECT.md) para entender os limites e decisões atuais e [docs/STRUCTURE.md](docs/STRUCTURE.md) antes de adicionar arquivos.

## Música

**Fate and Fortune — Scott Buckley**, disponibilizada sob [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). [Página do compositor](https://www.scottbuckley.com.au/library/fate-and-fortune/). Créditos também nas configurações e em `docs/licenses/music.txt`.

## Criação do jogo

- [História e decisões de design](docs/GAME-DESIGN.md).
- [Plano de desenvolvimento](docs/DEVELOPMENT-PLAN.md).


A floresta utiliza também **The Long Dark — Scott Buckley**, sob CC BY 4.0. Página: https://www.scottbuckley.com.au/library/the-long-dark/. Consulte docs/PHASE-01.md para as regras e controles dos diálogos.

Cenário da floresta: **a forest (3) with a road at night for game — dasy444**, sob CC BY 4.0. Créditos e alterações em docs/licenses/forest-road-night.txt.
