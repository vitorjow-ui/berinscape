# BERIN SCAPE — Revisão premium da introdução

Data: 08/11/2026. Escopo: menu da taverna → floresta → portão → recepção → salão → conversa no trono → encerramento da prévia. Nenhuma proposta depende de criar outra fase, combate ou a história de Zarek.

## Parecer

A introdução funciona como protótipo jogável e já tem identidade. Ainda não atende ao padrão premium solicitado: faltam continuidade espacial, acabamento de animação, direção de câmera, apresentação sonora consistente e estados de interface próprios de um jogo finalizado. O próximo salto de qualidade vem de polir esses fundamentos antes de adicionar conteúdo.

Ordem global por impacto sobre controle, continuidade, legibilidade e credibilidade visual/sonora. Custo não determina a posição: uma correção cara pode ser mais importante. Os primeiros 20 itens concentram as maiores diferenças percebidas; os últimos continuam relevantes, mas dependem dos anteriores.

Legenda: **V** = observado jogando nesta revisão; **C** = identificado na leitura do código/arquivos; **P** = proposta de acabamento. Não são 100 defeitos confirmados. Algumas linhas combinam observação e proposta. Para música e vozes, conferi arquivos, lógica de reprodução, controles e transições; a ferramenta de inspeção visual não permite certificar a experiência auditiva subjetiva. Recomendações sonoras precisam de uma sessão de escuta antes de aprovação final. Não medi FPS nem testei todos os navegadores.

## Ranking global — exatamente 100 melhorias

1. **Carregamento confiável e visível** [C/P]. Mostrar progresso real por etapa, erros específicos e tentar novamente. Hoje o carregamento 3D depende de vários recursos grandes e o erro final é genérico. Aceite: nenhuma espera sem explicação ou tela presa após falha.
2. **Pausa de verdade** [V/C]. Fazer Esc abrir pausa com Continuar, Configurações e Sair. Atualmente Esc retorna direto ao menu e o próximo Jogar reinicia o percurso. Aceite: retomar exatamente posição, moedas, câmera e diálogo.
3. **Caminhada por clique consistente** [V/C]. Melhorar o destino projetado na estrada e indicar limites alcançáveis, sobretudo em curvas. O percurso usa uma faixa lógica e limita o deslocamento lateral. Aceite: clicar em chão visível produz destino compreensível, sem cortes ou teleporte.
4. **Contato dos pés com o terreno** [V/P]. Ajustar apoio, inclinação e altura sobre as ondulações; a capa esconde muito do apoio atual. Aceite: passos sem aparência de deslizar, flutuar ou afundar.
5. **Câmera que evita obstáculos** [V/C]. Tratar galhos, troncos e paredes entre a câmera e Berin com reposicionamento ou transparência gradual. Aceite: personagem e caminho permanecem legíveis em todo o percurso.
6. **Coerência de direção de arte** [V/P]. Harmonizar realismo da floresta, pedra do castelo, proporções caricatas dos personagens e riqueza do salão. Aceite: materiais e luz fazem os recursos parecerem do mesmo jogo.
7. **Enquadramento dos diálogos** [V]. Reposicionar câmera e caixa de texto: no aviso do servo, o painel cobre parte importante do Berinbinha. Aceite: rosto, gesto e nome do falante ficam sempre visíveis.
8. **Fechar o fundo da recepção** [V/C]. Construir a entrada interna e uma porta visível atrás de Berin. Hoje o contraplano mostra um vazio escuro. Aceite: todos os enquadramentos mostram um salão arquitetonicamente completo.
9. **Orçamento de carregamento e memória** [C/P]. Substituir o transporte de todos os modelos em grandes textos base64 por carregamento sob demanda, com compactação adequada. Aceite: medir tempo inicial e pico de memória em equipamento alvo antes de definir limites finais.
10. **Ponto de retomada da introdução** [C/P]. Salvar o progresso ao entrar no castelo e permitir reiniciar conscientemente. Aceite: recarregar a página não obriga repetir menu e floresta; não contar moedas duas vezes.
11. **Animação própria de corrida** [V/C]. Criar corrida para Shift; hoje a caminhada apenas acelera. Aceite: passada, tronco e capa acompanham a velocidade dobrada.
12. **Substituir o GIF por animação fluida** [C/P]. Preparar vídeo ou sequência melhor do Berin levantando, respeitando o gesto aprovado. O GIF atual tem pouquíssimos quadros. Aceite: início sem saltos e reprodução consistente nas repetições.
13. **Mostrar a saída da taverna** [V/P]. Conectar a ação do menu ao primeiro plano jogável com porta, luz quente ou breve plano de saída. Aceite: o jogador entende de onde Berin veio sem texto explicativo adicional.
14. **Entrada física do castelo** [V/C]. Animar grade/portão e encenar a passagem antes do corte. Atualmente a transição é disparada ao chegar a um limite diante da entrada. Aceite: o corte corresponde ao Berin atravessando o acesso.
15. **Risada autoral do Berin** [C/P]. Adicionar uma gravação dedicada no início e na resposta do trono, sincronizada com o gesto. A sequência atual usa efeitos genéricos e fala dependente do navegador. Aceite: risada reconhecível, com início e fim naturais.
16. **Vozes estáveis para as falas** [C/P]. Usar vozes preparadas para Berin e Berinbinha, com legendas independentes. Hoje a fala depende da disponibilidade de voz portuguesa do navegador. Aceite: mesmo elenco e pronúncia em todos os equipamentos alvo.
17. **Efeitos de interface com identidade** [C/P]. Trocar tons de osciladores por sons trabalhados de metal, couro e impacto para foco, confirmação e Jogar. Aceite: resposta clara e potente sem agressividade ou repetição cansativa.
18. **Mixagem por categorias** [C/P]. Separar volumes de música, ambiente, interface e vozes, com limites de pico. Hoje efeitos e vozes têm controles parcialmente compartilhados. Aceite: diálogo inteligível e nenhum evento domina por acidente.
19. **Trilha que acompanha a cena** [C/P]. Definir trechos para taverna, caminhada, revelação do castelo e ameaça no trono, com transições musicais. Hoje o salão reutiliza a faixa do menu. Aceite: mudanças narrativas têm intenção musical sem reinícios bruscos.
20. **Floresta com ambiente gravado** [C/P]. Montar vento, folhas, galhos, fauna distante e silêncio controlado com sons naturais. O ambiente atual tem uma base de osciladores. Aceite: profundidade sonora sem mascarar passos e moedas.
21. **Separar áudio e rodapé do menu** [V]. Corrigir a disputa de espaço entre o botão de música e “prévia jogável” em 1280×720. Aceite: nenhuma sobreposição nas resoluções suportadas.
22. **Portão e caminho com continuidade visual** [V/P]. Refinar soleira, declive e emenda do terreno da floresta com a base do castelo. Aceite: sem frestas, interseções ou degraus incompatíveis com o movimento.
23. **Revelação do castelo** [V/P]. Ajustar vegetação e composição para revelar silhueta, torres e entrada gradualmente. Aceite: o castelo é reconhecido antes de a câmera já estar junto da fachada.
24. **Noite com contraste controlado** [V/P]. Escurecer a paisagem com critério e preservar personagem, caminho e moedas. Aceite: sensação sombria sem exigir brilho excessivo no monitor.
25. **Cor e materiais do terreno** [V/P]. Reduzir manchas claras repetidas e aspecto esticado da estrada. Aceite: terra, pedra e folhas são reconhecíveis perto da câmera e sob tochas.
26. **Materiais do castelo sob luz noturna** [V/P]. Harmonizar saturação, relevo e brilho da fachada; a luz quente destaca excessivamente algumas áreas. Aceite: pedra conserva leitura mineral e escala humana.
27. **Sombras de contato convincentes** [V/P]. Refinar sombra sob pés, baús, colunas e pilhas de moedas. Aceite: objetos assentam no chão sem manchas duras ou deslocadas.
28. **Fogo com volume e movimento** [V/P]. Substituir elipsoides luminosos das tochas por chamas com camadas, brasas discretas e variação. Aceite: aparência de fogo em vez de lâmpadas ovais.
29. **Luz do fogo vinculada à chama** [C/P]. Coordenar cor, intensidade e alcance com a animação, evitando pulsação mecânica. Aceite: reflexos e sombras respondem ao mesmo evento visual.
30. **Capa com movimento secundário** [V/P]. Dar inércia ao pano ao virar, parar e correr, com limites para não atravessar o corpo. Aceite: movimento acompanha Berin sem parecer uma peça rígida.
31. **Viradas e paradas do personagem** [V/P]. Criar transições de rotação e desaceleração com apoio dos pés. Aceite: Berin não gira sobre o próprio eixo como um objeto deslizando.
32. **Locomoção relativa à tela** [C/P]. Ajustar WASD à orientação percebida da câmera, preservando o avanço simples pela estrada. Aceite: esquerda e direita mantêm sentido intuitivo nas curvas.
33. **Confirmação clara do destino** [V/P]. Melhorar marcador no chão com pulso curto e cancelamento evidente ao usar teclado. Aceite: o destino permanece visível sobre diferentes superfícies.
34. **Bloqueio de destinos inválidos** [C/P]. Diferenciar chão acessível, borda e parede também no salão. Hoje o clique do salão usa um plano infinito com limites numéricos. Aceite: clicar numa parede não sugere que ela pode ser atravessada.
35. **Pontos de interesse na caminhada** [V/P]. Reorganizar os elementos existentes em composições com começo, meio e chegada. Aceite: o caminho tem progressão visual sem adicionar missões ou outra fase.
36. **Moedas menos mecânicas no percurso** [V/P]. Variar agrupamentos e respiros na distribuição, mantendo as 120 moedas e as recompensas a cada 50. Aceite: coleta conduz o olhar sem parecer duas fileiras automáticas.
37. **Moedas com relevo e identidade** [V/P]. Aplicar face, borda e símbolo de Berin em escala coerente. Aceite: moedas são reconhecíveis como riqueza do personagem em vez de discos genéricos.
38. **Coleta com atração e retorno visual** [V/P]. Fazer moedas próximas irem até Berin ou desaparecerem com um brilho curto, mantendo a regra de contagem. Aceite: toda moeda coletada tem uma resposta inequívoca.
39. **Som de moedas em sequência** [C/P]. Variar amostras e limitar sobreposição quando várias são recolhidas. Aceite: sequências rápidas não viram um apito contínuo.
40. **Recompensa de vida extra** [V/P]. Dar animação própria ao coração e uma celebração curta, proporcional à conquista. Aceite: o jogador entende que ganhou uma vida sem perder a leitura do caminho.
41. **Explicar o papel das vidas** [V/C]. Comunicar que são acumuladas na introdução e definir seu uso sem inventar perigos nesta etapa. Hoje não há perda de vida neste trecho. Aceite: o contador não sugere uma ameaça inexistente.
42. **HUD com legibilidade constante** [V/P]. Melhorar contraste de textos pequenos sobre vegetação e pedra clara. Aceite: objetivo e progresso são legíveis sem depender do fundo do cenário.
43. **Informação contextual no HUD** [V/P]. Reduzir a permanência de nome, título e instrução quando já compreendidos. Aceite: a interface guia sem disputar espaço com o ambiente.
44. **Ensino inicial dos controles** [V/P]. Mostrar uma dica curta de clique, Shift e câmera na primeira vez, dispensável e não repetitiva. Aceite: alguém novo começa sem abrir um manual.
45. **Lobos em escala e silhueta melhores** [V/P]. Refinar tamanho, pelagem e proporção usando o modelo aprovado. Aceite: parecem lobos da floresta e permanecem distintos de cães domésticos à distância.
46. **Patas dos lobos no terreno** [V/C]. Ajustar altura, inclinação e cadência ao relevo e à velocidade real. Aceite: sem patas atravessando o solo ou deslizando nas mudanças de direção.
47. **Rotinas naturais para os lobos** [V/C]. Alternar caminhar, farejar, observar e parar, substituindo o movimento oscilatório contínuo. Aceite: animais não parecem patrulhar sobre trilhos sincronizados.
48. **Lobos respeitando obstáculos** [C/P]. Validar trajetos contra troncos, pedra, passagem do jogador e fachada. Aceite: nenhum animal atravessa objetos durante o trajeto completo.
49. **Reação discreta à presença de Berin** [P]. Fazer alguns lobos olharem ou se afastarem, sem introduzir combate. Aceite: a presença poderosa do personagem afeta o ambiente de maneira sutil.
50. **Morcegos com melhor silhueta** [V/P]. Substituir asas triangulares planas por malha e movimento mais orgânicos. Aceite: não parecem ícones pretos gigantes cruzando a tela.
51. **Morcegos em profundidade segura** [V/C]. Afastar voos da lente e do rosto do personagem, com grupos e alturas variadas. Aceite: fauna enriquece o fundo sem bloquear caminho e interface.
52. **Vegetação com escala coerente** [V/P]. Revisar arbustos e troncos junto à estrada em relação ao corpo do Berin. Aceite: o caminho tem largura e vegetação plausíveis ao longo da caminhada.
53. **Vento sutil na vegetação** [C/P]. Mover copas e arbustos com forças pequenas e diferentes. Aceite: a floresta deixa de parecer congelada sem exigir animação cara em cada planta.
54. **Neblina com profundidade gradual** [V/P]. Trabalhar camadas baixas e transição para a fachada, preservando marcos visuais. Aceite: distância perceptível sem uma parede uniforme de neblina.
55. **Céu integrado à noite** [V/P]. Refinar lua, estrelas e horizonte para combinar com árvores, névoa e iluminação. Aceite: nenhuma borda de terreno denuncia o fim do cenário.
56. **Otimização da vegetação distante** [C/P]. Criar níveis de detalhe e critérios de visibilidade. Aceite: comparar visual e tempo de quadro antes/depois sem sumiços perceptíveis.
57. **Iluminação com custo controlado** [C/P]. Reduzir luzes dinâmicas simultâneas e preparar parte da iluminação estática. Aceite: manter aparência do salão e da estrada dentro do orçamento medido.
58. **Ajustes gráficos por equipamento** [C/P]. Oferecer qualidade de sombras, resolução e efeitos com prévias claras. Aceite: uma máquina modesta consegue jogar sem descaracterizar a atmosfera.
59. **Cadência estável sob carga** [C/P]. Medir tempos de quadro e ajustar atualização de câmera/animação, inclusive quando o navegador fica lento. Aceite: velocidade e transições não dependem perceptivelmente do desempenho.
60. **Pausa ao perder foco** [C/P]. Suspender movimento, diálogo e áudio quando apropriado ao sair da aba. Hoje a perda de foco apenas limpa teclas. Aceite: voltar sem perder uma cena ou encontrar o personagem deslocado.
61. **Celebração com mais variedade** [V/P]. Alternar gestos dos Berinbinhas, respeitando o modelo aprovado e o coro. Aceite: o grupo parece espontâneo, sem braços atravessando corpo e capa.
62. **Olhares e orientação dos servos** [V/C]. Fazer Berinbinhas acompanharem a chegada do mestre e o conselheiro mirar quem fala. Aceite: ninguém conversa olhando permanentemente para o lado errado.
63. **Recepção com entrada coreografada** [V/P]. Ajustar posição inicial de Berin e começo da comemoração para parecerem reação à chegada. Aceite: o coro não começa antes da presença dele fazer sentido no plano.
64. **Coro com sala e distância** [C/P]. Preparar camadas de vozes e reverberação coerente com o salão. Aceite: reconhecer um grupo no espaço sem uma repetição evidentemente artificial.
65. **Encerrar a comemoração naturalmente** [V/P]. Desacelerar gestos e terminar a frase do coro ao receber a ordem. Aceite: não cortar voz e animação na mesma borda abrupta.
66. **Arcos de câmera da recepção** [V/P]. Definir plano geral, entrada e reação em posições estáveis, com movimento motivado. Aceite: sem varrer teto, vazio ou figurantes sem intenção.
67. **Berin chegando ao trono** [V/C]. Encerrar o controle com um alinhamento e gesto deliberados diante do assento; avaliar sentar ou apoiar-se nele. Hoje a conversa dispara antes de ele ocupar o trono. Aceite: a cena tem postura de soberano coerente.
68. **Plano de poder para a resposta** [V/P]. Substituir o close muito alto sobre a cabeça por enquadramento que valorize rosto e trono. Aceite: Berin transmite ameaça sem o topo da cabeça dominar a imagem.
69. **Gestos de fala do Berinbinha** [V/P]. Adicionar pedido de permissão, inquietação e resposta obediente. Aceite: cada intenção do texto aparece também no corpo.
70. **Gestos e expressão do Berin** [V/P]. Trabalhar desprezo, risada e desafio com pausas e expressões específicas. Aceite: a fala deixa de acontecer sobre uma animação neutra.
71. **Olhos e boca nas falas** [C/P]. Preparar piscar, direção de olhar e sincronização labial compatível com o modelo. Aceite: closes não evidenciam um rosto totalmente estático.
72. **Diálogo dividido em unidades legíveis** [V/P]. Separar o longo aviso do servo em blocos que respeitem o ritmo da fala, sem mudar seu sentido. Aceite: leitura confortável sem um bloco ocupando metade do plano.
73. **Texto revisado com a voz do autor** [V/C]. Corrigir concordância e grafia, como “a ira”, “o campeão” e “recebê-lo”, preservando arrogância e humor. Aceite: português cuidado sem descaracterizar Berin.
74. **Avanço e salto de cenas separados** [C/P]. Oferecer avanço de fala e opção explícita de pular a cena já vista. Aceite: não repetir toda a conversa para testar o trecho nem pular sem querer.
75. **Legendas configuráveis** [C/P]. Permitir tamanho, opacidade do fundo e exibição do nome. Aceite: o nome completo Berinbinha (Servo de Berin) cabe nas resoluções suportadas.
76. **Continuidade de música nas falas** [C/P]. Ajustar redução e retorno do volume por frase, respeitando pausas. Aceite: trilha sustenta tensão sem competir com voz ou aumentar no momento errado.
77. **Acústica própria do salão** [C/P]. Criar passos de pedra, tecido e reverberação da arquitetura. Aceite: entrar no castelo é reconhecível também pelo som.
78. **Piso do salão menos uniforme** [V/P]. Refinar juntas, desgaste, variação de pedra e reflexos controlados. Aceite: riqueza sem aparência de plástico ou repetição excessiva.
79. **Trono com construção mais convincente** [V/P]. Trabalhar base, estrutura, estofado e ornamentos existentes, mantendo a identidade roxa e dourada. Aceite: assento plausível e digno de close.
80. **Riquezas com composição intencional** [V/P]. Quebrar simetria rígida de baús e moedas, deixando corredores livres e agrupamentos hierárquicos. Aceite: abundância organizada por alguém, em vez de objetos copiados em série.
81. **Baús com ferragens e desgaste** [V/P]. Refinar dobradiças, fechaduras, bordas e relevo dos materiais. Aceite: objetos próximos suportam câmera baixa sem parecer caixas primitivas.
82. **Vitral com desenho e luz próprios** [V/P]. Inserir símbolo ligado a Berin e luz colorida controlada no entorno do trono. Aceite: vitral funciona como assinatura do salão sem estourar a imagem.
83. **Tecido de tapetes e estandartes** [V/P]. Melhorar caimento, bordados e variação de relevo. Aceite: superfícies parecem tecido em vez de placas perfeitamente rígidas.
84. **Lustres e velas mais convincentes** [V/P]. Refinar cera, chamas, corrente de sustentação e distribuição de brilho. Aceite: os novos lustres se integram à arquitetura e não parecem adereços isolados.
85. **Logo com assinatura própria** [V/P]. Refinar desenho, espaçamento BERIN/SCAPE e acabamento metálico com leitura em miniatura. Aceite: identidade forte em tela cheia e em janela menor.
86. **Moedas do título com elegância** [V/P]. Controlar quantidade, profundidade, origem e área de queda, mantendo a ideia aprovada. Aceite: o efeito valoriza o nome sem cobrir subtítulo e botões.
87. **Hierarquia dos botões** [V/P]. Refinar proporção de Jogar, Configurações e Áudio, com estados coerentes de foco, pressão e desativado. Aceite: o próximo passo é claro para mouse e teclado.
88. **Configurações mais completas e claras** [V/P]. Mostrar porcentagens de volume, restaurar padrões e separar controles de créditos. Aceite: ajuste entendido sem tentativa e erro nem rolagem desnecessária.
89. **Estado de áudio persistente** [C/P]. Salvar silenciar/ativar e explicar o primeiro desbloqueio do navegador. Aceite: reiniciar respeita a escolha anterior sem um botão contradizer o que está configurado.
90. **Transição inicial com duração ajustada** [V/C]. Sincronizar zoom, gesto, risada e corte e permitir dispensar a repetição. Aceite: início tem impacto sem parecer uma espera obrigatória em todo teste.
91. **Entrada de capítulo mais cinematográfica** [V/P]. Apresentar título e localização num momento de respiro da caminhada inicial. Aceite: ambientação compreendida sem mais um painel permanente.
92. **Encerramento com conclusão clara** [V/C]. Mostrar “Introdução concluída”, moedas e vidas desta tentativa, com Rejogar e Menu. Aceite: o jogador entende que terminou a prévia e não que o jogo travou.
93. **Estados de saída sem modais pendentes** [C/P]. Unificar Esc, voltar ao menu e fechar a tela final; há caminhos distintos que precisam ser testados juntos. Aceite: nenhuma janela fica aberta sobre um novo estado ou impede reiniciar.
94. **Acessibilidade de movimento e luz** [C/P]. Aplicar reduzir movimento também ao zoom de entrada, moedas e câmera, e oferecer controle de flashes. Aceite: preferência respeitada em todos os efeitos do trecho.
95. **Teclado e foco completos** [V/C]. Revisar ordem de Tab, foco visível, atalhos e retorno do foco após painéis e cenas. Aceite: jogar e navegar sem mouse sem disparar ações duplicadas.
96. **Layout em janelas pequenas** [V/C/P]. Validar menu, nome longo, legendas e configurações em alturas e larguras menores. Aceite: nenhum texto escondido, botão inacessível ou informação essencial cortada.
97. **Definir suporte de entrada** [C/P]. Comunicar claramente o suporte atual de mouse/teclado; se celular fizer parte do alvo, preparar toque e controles adequados. Aceite: a tela não promete uma experiência que não oferece.
98. **Distribuição independente da CDN** [C/P]. Incluir a biblioteca 3D na distribuição e servir os recursos com estratégia clara de cache. Aceite: abrir uma versão salva não depende de baixar Three.js de terceiros naquele momento.
99. **Conferência de recursos e permissões de uso** [C/P]. Manter procedência e créditos por recurso e revisar o lobo identificado como COD Ghosts antes de uma distribuição pública. A indicação CC BY do envio não comprova toda a cadeia de direitos. Aceite: cada recurso tem origem e uso documentados.
100. **Versão reproduzível e bateria final** [C/P]. Automatizar versão, manifesto, backup e revisão do mesmo roteiro em navegadores/equipamentos alvo. Aceite: qualquer entrega pode ser restaurada e conferida do menu ao final, com resultados registrados.

## Ordem sugerida de execução

Primeiro resolver os itens 1–10 e as sobreposições do menu. Depois polir locomoção, entrada e cenas (11–16, 22–34, 61–75). Em seguida trabalhar som, ambiente e materiais. Por fim completar acessibilidade, distribuição e conferência de desempenho. A ordem por lotes pode antecipar tarefas baratas ligadas ao mesmo arquivo, sem perder o ranking de impacto acima.

Esta lista é um plano de melhoria; não declara esses 100 itens implementados. Nesta revisão foi aplicada a troca do nome, preservando a história e a primeira fase existentes.


## Implementação posterior — 09/11/2026

Prioridades 1–10 aplicadas nesta fase, com resultados e limites descritos em [TOP10-IMPLEMENTATION.md](TOP10-IMPLEMENTATION.md). O ranking original permanece preservado como referência.

## Execução das prioridades 11–20

Aplicadas em 09/11/2026. Resultados, evidências e limites em [TOP20-IMPLEMENTATION.md](TOP20-IMPLEMENTATION.md). O ranking original permanece como registro da revisão.

## Execução das prioridades 21–30

Aplicadas com foco em iluminação noturna e tochas. Veja [TOP30-IMPLEMENTATION.md](TOP30-IMPLEMENTATION.md) para resultados e limites.
