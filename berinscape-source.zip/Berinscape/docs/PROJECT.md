# Estado do projeto

## Escopo confirmado

**BERIN SCAPE — Uma Jornada Épica**: fantasia medieval para navegador, com direção visual realista. Dez fases no total: a primeira apresenta Berin como personagem jogável; o herói assume a aventura principal e enfrenta Berin como chefe final. O desfecho é o aprisionamento de Berin no próprio castelo.

Combate confirmado: clique no inimigo e uso de habilidades, no estilo RuneScape. Tom: épico e sombrio, com humor nas atitudes de Berin. História e decisões estão em [GAME-DESIGN.md](GAME-DESIGN.md); sequência de produção em [DEVELOPMENT-PLAN.md](DEVELOPMENT-PLAN.md).

A implementação atual cobre menu, floresta com moedas e fauna, recepção dos Berinbinhas, salão de riquezas e conversa no trono. Veja [PHASE-01.md](PHASE-01.md) para o alcance e as limitações desta entrega.

## O que está implementado

- Menu medieval com lettering vetorial, moedas animadas, configurações e volumes separados.
- Fundo parado e reprodução do GIF do bar ao jogar, zoom e transição visual.
- Música gravada Fate and Fortune e efeitos sintetizados de interface.
- Berin v2 3D com Idle/Walk, caminhada por clique e teclado, câmera com zoom e indicador de progresso.
- Cenário procedural com árvores, pedras, vegetação, tochas, sombras e castelo.

## Limites atuais

- O cenário ainda usa geometria e texturas procedurais: a direção realista não está concluída.
- Berin v2 contém limitações de topologia e deformação descritas no pacote original. Não é um rig final aprovado para produção.
- Não existem animações novas de Berin se levantando e rindo no menu; é usado o GIF recebido.
- Colisão consiste em limitar o personagem à faixa do caminho, não em um sistema geral de física ou navegação.
- Não há combate funcional, inventário, salvamento, contas ou multiplayer. O interior é um salão procedural provisório.
- Three.js 0.180.0 é carregado pela CDN. Os demais recursos são locais. Distribuição totalmente offline ainda requer empacotar o motor e seus carregadores.
- A música tem licença CC BY 4.0 e exige manter os créditos.

## Próximos marcos

1. Revisar a fase 1 com moedas, recepção e conversa no trono no navegador alvo.
2. Consolidar as regras de combate em um teste pequeno.
3. Validar um trecho de referência com Berin e um trecho do herói.
4. Produzir as fases conforme o plano, sem presumir conteúdo ainda não aprovado.
