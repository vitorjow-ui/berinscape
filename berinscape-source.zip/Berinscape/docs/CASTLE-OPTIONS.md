# Castelo e salão — opções para escolha

Consulta em 8 de novembro de 2026. Todos os quatro constavam como baixáveis e CC Attribution na API pública do Sketchfab. Nenhum foi baixado ou aplicado nesta etapa. A licença exige atribuição ao autor; conferir materiais/estrutura do arquivo escolhido antes de preparar a versão de jogo.

| Código | Modelo | Autor | Triângulos | Considerações |
| --- | --- | --- | --- | --- |
| C1 | [Medieval Castle](https://sketchfab.com/3d-models/medieval-castle-2964776c3847493ba908fd192e071ca3) | Uğur Yakışık | 64.014 | Candidato de peso moderado para o exterior ao final da floresta. |
| C2 | [Fantasy Castle](https://sketchfab.com/3d-models/fantasy-castle-1b3756460dde44399fd7b9bb3b78127c) | Hawtor Studio | 254.997 | Castelo de fantasia mais pesado; conferir organização, texturas e necessidade de otimização. |
| S1 | [Throne Room](https://sketchfab.com/3d-models/throne-room-c5cb8bdcb92b421bb5d6dccf25a9bdcc) | Ronergetic | 28.074 | Salão comprido, tapete vermelho, escadas, vitral e três tronos segundo o autor. Adaptar para o trono de Berin. |
| S2 | [Throne-room](https://sketchfab.com/3d-models/throne-room-c9f7595b50694e8ebefe28aae88028d9) | hariniselvaraj2021 | 647.746 | Alternativa de salão muito mais pesada; exigirá avaliação de redução e materiais para o navegador. |

O exterior e o salão são recursos separados. A integração deve preservar a recepção dos lacaios, a caminhada até o trono e os diálogos existentes; não criar nova fase ou história ao aplicar os modelos.


Escolha confirmada: C1 fornecido pelo usuário e integrado ao exterior. O salão existente foi mantido e aprimorado; S1 e S2 não foram aplicados.
