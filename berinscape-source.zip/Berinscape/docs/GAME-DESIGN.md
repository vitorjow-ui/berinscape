# BERIN SCAPE — Uma Jornada Épica

Documento de criação inicial. Registra o que o autor confirmou e separa propostas de decisões. A grafia do subtítulo foi ajustada para concordância: “Uma Jornada Épica”. O logotipo e as telas existentes ainda não foram alterados.

## Identidade confirmada

- Jogo 3D para navegador, com direção visual realista.
- Fantasia medieval, atmosfera épica e sombria, com humor nas atitudes de Berin.
- Combate no estilo RuneScape: clique no inimigo e uso de habilidades.
- Dez fases no total. A introdução faz parte dessas dez, não é uma fase extra.
- Na primeira fase, o jogador controla Berin. O herói é o protagonista jogável da aventura principal.
- Berin é o chefe final. O herói o enfrenta e o aprisiona dentro de seu próprio castelo.

## Berinbal, conhecido como Berin

Rei dos ladrões, o maior scammer que já existiu. Praticamente um semideus, possui poderes sobrenaturais e força sobre-humana. Seu objetivo é conquistar poder e controlar todas as riquezas e nações.

Mora em um castelo na Floresta Negra, cercado de riquezas, adoradores e seres que o seguem. A natureza exata dos poderes, as origens e a história dos seguidores ainda serão definidas. Os Berinbinhas já desenhados são referências disponíveis; seus papéis em cada fase permanecem em aberto.

## O herói — Zarek

Zarek, cujo nome significa “Vingador noturno” no contexto criado pelo autor, será roubado e scamiado e jurará vingança contra Berin. Durante a jornada, descobrirá que outros guerreiros também o ajudarão. Isso não define ainda se serão companheiros controláveis, NPCs ou personagens apenas narrativos.

Zarek enfrentará Berin e o aprisionará no próprio castelo ao final do jogo. Aparência, origem, habilidades, detalhes do golpe e identidades dos aliados permanecem em aberto. Seu desenvolvimento está adiado: a prioridade atual é a fase 1, jogando com Berin.

Ainda precisamos explicar como Zarek consegue derrotar e aprisionar alguém tão poderoso. Não presumir profecias, artefatos, parentesco ou uma fraqueza específica sem decisão do autor.

## Estrutura narrativa

O jogo começa mostrando o mundo pela perspectiva do antagonista. Depois o jogador acompanha o herói que irá enfrentá-lo. Isso permite apresentar o poder e a personalidade de Berin antes do confronto final.

O caminho noturno até o castelo já implementado é a base disponível para a introdução. O autor definiu a recepção pelos Berinbinhas, a ordem de Berin, a caminhada pelo salão de riquezas e o aviso sobre um exército ao norte. A conversa no trono está registrada em `src/story/intro.js`. O trecho atual termina após essa conversa; a cena seguinte e a passagem ao herói ainda serão definidas. Veja [PHASE-01.md](PHASE-01.md).

O momento exato em que o controle passa para o herói está em aberto. Começar essa parte na fase 2 é a proposta de organização inicial, não uma cena já aprovada.

## Jogabilidade: decisões e propostas

**Confirmado:** selecionar inimigos por clique e usar habilidades. A movimentação atual por clique e teclado é um protótipo existente; os controles finais devem ser consolidados com testes.

**Proposta para o primeiro combate testável:** um personagem, um inimigo, seleção de alvo, aproximação até o alcance, ataque básico, vida, uma habilidade com recarga, vitória e derrota com reinício. Validar esse conjunto antes de criar classes, árvores de talentos ou equipamentos complexos.

**A decidir:** ataque básico automático após selecionar o alvo, persistência de seleção, uso de mana/energia, cura, quantidade de habilidades, esquiva, sistema de itens, progressão e consequências da derrota. A referência RuneScape não determina automaticamente todos esses sistemas.

## Mapa das dez fases

As funções intermediárias abaixo são propostas de ritmo. Não são nomes, locais ou acontecimentos aprovados.

| Fase | Estado | Personagem e função |
| --- | --- | --- |
| 1 | Introdução confirmada; conteúdo detalhado pendente | Berin jogável. Apresentar sua personalidade e seu domínio. Aproveitar a floresta e o castelo já iniciados. |
| 2 | Proposta | Assumir o herói, apresentar sua motivação e ensinar seu combate. |
| 3 | A criar | Primeiro objetivo do herói fora da apresentação. |
| 4 | A criar | Desenvolver uma dificuldade ou oposição já apresentada. |
| 5 | A criar | Mostrar uma consequência relevante do domínio de Berin. |
| 6 | A criar | Introduzir uma mudança importante na jornada. |
| 7 | A criar | Exigir domínio das habilidades já aprendidas. |
| 8 | A criar | Preparar as condições narrativas e mecânicas para o confronto. |
| 9 | A criar | Conduzir ao confronto final, sem inventar um local nesta etapa. |
| 10 | Confronto e desfecho confirmados | Herói contra Berin, chefe final. Berin termina aprisionado em seu castelo. |

Não criar nove chefes adicionais por padrão. Quantidade de chefes, duração das fases, locais e personagens secundários ainda serão definidos.

## Ficha para desenvolver cada fase juntos

1. O que acontece na história e por que essa fase existe?
2. Quem o jogador controla, onde começa e onde termina?
3. Qual é o objetivo que aparece para o jogador?
4. Que ações, inimigos ou obstáculos fazem parte do percurso?
5. O que ensina ou exige de diferente?
6. Como o jogador vence, perde e reinicia?
7. Qual cena ou acontecimento liga à fase seguinte?
8. Quais modelos, animações, cenários, sons e diálogos precisamos produzir?

## Pontos em aberto prioritários

1. Consolidar o trecho já definido da fase 1 e aprovar a ordem provisória de Berin na recepção.
2. Revisar visualmente a fase 1 e definir a próxima cena após a conversa no trono.
3. Limites dos poderes de Berin e lógica de seu aprisionamento.
4. Regras mínimas do combate, a partir de um teste jogável.
5. Plataforma alvo inicial, orçamento de arte e duração pretendida da aventura.

## Limites do planejamento

Nenhuma data de entrega ou quantidade de conteúdo por fase foi prometida. O alvo visual deve ser demonstrado em um trecho curto antes de se estimar o jogo inteiro. Multiplayer, monetização e mundo aberto não fazem parte do escopo confirmado.
