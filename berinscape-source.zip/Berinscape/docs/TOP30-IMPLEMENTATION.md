# Melhorias 21–30 — noite e tochas

Data: 10/11/2026. Escopo: primeira fase existente, sem alterar história, GIF aprovado, personagens, lobos, coleta ou regras de vidas.

| Ranking | Implementação |
| --- | --- |
| 21 | Margens e área reservada ao rodapé; áudio permanece na coluna de ações, separado do texto inferior. Ajustes para janelas de pouca altura. |
| 22 | Aproximação de pedra amostrada sobre o terreno real, unida à soleira; pavimento procedural com juntas, variação e relevo. |
| 23 | Névoa menos opaca na aproximação e luz fria rasante nas torres, mantendo a entrada quente como marco. O percurso e sua curva original foram preservados. |
| 24 | Luz ambiente e exposição reduzidas na floresta; céu azul muito escuro, lua fria e contraste com as tochas. Ajustes do salão independentes dos da floresta. |
| 25 | Mapa original do solo preservado, com variação de terra em coordenadas do mundo, cores mais contidas e superfície áspera. Não substitui a textura original por uma imagem de resolução maior. |
| 26 | Pedra do castelo mais áspera, metais tratados separadamente; luz da fachada equilibrada com o fogo e a noite. |
| 27 | Sombras suaves de contato sob colunas, baús, moedas e servos; sombra de Berin suavizada. Uma luz quente de sombras acompanha a tocha próxima, além da sombra lunar existente. |
| 28 | 13 tochas ao longo da estrada e duas na entrada do castelo, com poste de madeira, ferragens e cesto. Chamas com turbulência, núcleo quente, halo e seis brasas por tocha. Oito fogos do salão usam o mesmo efeito. |
| 29 | Movimento da chama, halo, cor e intensidade da luz variam juntos; sementes diferentes evitam sincronização das tochas. Variação suave, sem flashes. |
| 30 | Capa com atraso na resposta à velocidade, oscilação ao parar e inclinação limitada nas viradas; aplicação aditiva preserva as animações do rig. |

## Verificações e limites

Primeiro percurso no navegador HTTP local: floresta, corrida, aproximação e portão, recepção dos Berinbinhas. Confirmadas 120 moedas e 5 vidas. Nenhum erro/aviso na consulta após a caminhada. O contraste foi inspecionado visualmente, mantendo o caminho e as moedas legíveis. Um pavimento inicialmente liso foi substituído por pedra texturizada; o excesso de luz junto ao acesso foi reduzido. A recepção recebeu preenchimento quente para preservar os personagens.

As verificações de recompensas, salvamento, carregamento e áudio continuam passando. Referências e recursos conferidos por tools/verify.py. A execução não depende de novos downloads de modelos, texturas ou efeitos: os elementos novos são gerados pelo jogo. Originais e créditos anteriores preservados.

A floresta usa no máximo quatro luzes pontuais de tocha próximas e um mapa de sombra quente; fogos distantes continuam visíveis. Isso limita o custo adicionado, mas não é uma medição de FPS em equipamento alvo. Flamas são superfícies orientadas à câmera com efeito procedural e brasas; não há simulação volumétrica de fluidos. Apoios de contato complementam as sombras reais e são aproximações leves.

Abertura direta por arquivo continua sem teste visual nesta ferramenta; a conferência ocorreu na prévia HTTP. Three.js ainda depende da CDN. Demais itens do ranking permanecem sujeitos ao acabamento futuro.

## Conferência final da versão

Na revisão final em 1280 × 720, retomada direta na recepção funcionou com 120 moedas e 5 vidas. Conferidas ordem de Berin, caminhada pelo salão, três falas no trono, encerramento e retorno ao menu. Uma nova jornada exibiu o GIF original; a mudança de música chegou ao estado forest. A segunda caminhada confirmou o pavimento texturizado e a luz reduzida na entrada, novamente com 120 moedas e 5 vidas. Esc abriu a pausa normalmente. Consulta final de erros/avisos vazia. Os 15 scripts JavaScript passaram na análise de sintaxe; referências/modelos/áudios e testes anteriores de estado/áudio aprovados. Imagens de menu, floresta, castelo e recepção em art/previews/night30.
