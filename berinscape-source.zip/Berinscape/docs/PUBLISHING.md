# Publicar o Berinscape

O jogo é estático: GitHub Pages pode servi-lo sem servidor de aplicação.

## Primeira publicação

1. Conecte sua conta GitHub e crie um repositório chamado `berinscape`.
2. Envie esta pasta de projeto, incluindo `.github/workflows/pages.yml`, para a branch `main`.
3. No repositório, abra **Settings → Pages → Build and deployment → Source → GitHub Actions**.
4. Abra **Actions → Publicar Berinscape → Run workflow** se a execução inicial tiver ocorrido antes de habilitar Pages.
5. Aguarde a execução terminar. O endereço aparece em **Settings → Pages** e no ambiente **github-pages**.

Em um repositório de projeto, o endereço normalmente será `https://SEU-USUARIO.github.io/berinscape/`.
No plano gratuito, use um repositório público. Isso também torna os arquivos enviados visíveis.
Alterações enviadas para `main` disparam uma nova publicação.

## Arquivos

Execute `python Berinscape/tools/build_site.py` na raiz para preparar `dist/`.
No envio pelo navegador, o código está em `berinscape-source.zip`: extraia esse arquivo na raiz antes de executar o comando localmente. O workflow faz essa extração automaticamente.
Os recursos estão compactados em `assets-pack.partNNN`, com hashes SHA-256 em `assets-pack.json`. Em uma cópia nova do repositório, o comando verifica e extrai os recursos automaticamente para `Berinscape/assets/` antes de gerar o site.
O pacote público contém a entrada HTML, código, estilos, recursos e créditos.
O `.gitignore` da raiz exclui backups, arquivos de produção de `art/` e protótipos de `archive/`.
Esses arquivos continuam no computador; não fazem parte do envio inicial.
Há um modelo original com mais de 100 MB em `art/`, desnecessário para jogar.

O verificador completo `python Berinscape/tools/verify.py` usa os originais de `art/` e deve ser executado no computador que os possui.
O processo de publicação valida os caminhos HTML/CSS no pacote público.

## Jogar

Os visitantes acessam o link sem instalar nada. Three.js é carregado pela internet.
Os recursos ocupam aproximadamente 315 MB; o carregamento ocorre por etapas.
O progresso é salvo no navegador e no endereço usado, sem conta ou sincronização entre aparelhos.
Os controles atuais são voltados para teclado e mouse; suporte completo a celular ainda não foi validado.

Referência: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages
