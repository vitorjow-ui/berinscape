# Berinscape — primeiro teste com Berin 3D

Abra index.html no navegador, com conexão à internet para carregar o Three.js. O modelo do Berin está incluído localmente em berin-model.js para permitir abrir o jogo sem instalar um servidor.

- Menu com imagem parada, zoom e GIF ao jogar, música e controle de volume.
- Berin_LOD0.glb substitui o esqueleto provisório na fase 3D.
- Clique no chão ou use WASD/setas para andar; Idle e Walk acompanham o movimento.
- Siga o caminho até o portão. Esc retorna ao menu.
- Floresta e castelo continuam provisórios; animações e texturas do pacote Berin v2 ainda estão em revisão.
- Não há novas animações de Berin bebendo, levantando ou rindo: o menu mantém o GIF original.

Verificação desta integração: sintaxe dos scripts e presença das animações/skin do GLB. A inspeção visual automatizada não foi concluída: o navegador de teste bloqueou o arquivo local e não alcançou o servidor local. Conferir aparência e movimento no navegador do usuário.

## Menu medieval

Identidade com tipografia serifada local em duas linhas, brasão vetorial, metal envelhecido, moldura e brasas. O fundo parado e a sequência do GIF ao jogar foram preservados. Layout adaptado para telas estreitas e baixas; animações decorativas respeitam a preferência de movimento reduzido.

Efeitos originais sintetizados de seleção, clique, início, transição e chegada ao portão. Configurações oferece volumes independentes para música/ambiente e efeitos, salvos neste navegador. O botão da música permite silenciá-la sem silenciar os efeitos. Áudio inicia após interação do usuário.

Verificados: sintaxe, referências da interface, execução dos cinco efeitos com áudio simulado e silêncio da música. Aparência e mixagem ainda precisam de conferência no navegador com áudio real.

## Título flamejante e Marcha das Sombras

BERIN usa letras vetoriais próprias com recortes, metal em relevo, rachaduras e labaredas animadas; SCAPE permanece como subtítulo. O fogo respeita a opção de movimento reduzido.

A trilha anterior foi substituída por Marcha das Sombras: composição original sintetizada em ré frígio, 54 BPM, tambores graves, notas sustentadas e timbres de sopro/coro. Cliques têm impacto grave, ataque de ruído e ressonâncias metálicas. Um compressor na saída controla picos; volumes continuam independentes. Verificados SVG, sintaxe e agendamento de 100 segundos de música e dos cinco efeitos em áudio simulado. Mixagem real não foi ouvida nesta verificação.

## Revisão do áudio e passagem para a fase

A música atual é O Caminho de Berin: tema original de 16 compassos em ré menor, 78 BPM, arpejos com timbre de alaúde, melodia e percussão contida. Substitui Marcha das Sombras. O clique usa um toque curto em lugar da pancada grave anterior.

Ao jogar: varredura de luz, enquadramento com faixas de cinema, zoom no GIF e escurecimento para revelar a floresta. O efeito é encerrado antes do controle da fase; movimento reduzido desativa a varredura. Verificados sintaxe, ciclo musical e efeitos em áudio simulado; conferência audiovisual real pendente.

## Trilha gravada do menu (atual)

As composições sintetizadas anteriores foram removidas. O menu agora reproduz o MP3 local Fate and Fortune, de Scott Buckley, com coral e orquestra épicos. Fonte: https://www.scottbuckley.com.au/library/fate-and-fortune/ — licença CC BY 4.0. Créditos visíveis nas configurações e no arquivo audio/CREDITOS.txt. Arquivo original sem edição; repetição e fades são aplicados durante a reprodução.

O volume da música controla a gravação; ao entrar na fase ela reduz gradualmente e pausa, retornando no menu. Efeitos e ambiente continuam separados. Conferidos sintaxe, arquivo baixado e lógica de reprodução/fade com áudio simulado. Não houve audição da mixagem final nesta verificação.
