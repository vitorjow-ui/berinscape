# Onde guardar e alterar cada coisa

## Código

`index.html` contém a estrutura da interface, o mapa de importação do Three.js e a ordem dos scripts. `src/game.js` controla menu, configurações, transição e o ciclo de atualização. `src/scenes/forest.js` monta a floresta, carrega Berin e controla câmera, animação e movimento. `src/audio/audio-manager.js` toca a gravação local e gera efeitos/ambiente. `styles/base.css` contém o estilo geral; `styles/menu.css`, a apresentação do menu.

Os scripts clássicos compartilham algumas variáveis globais. A fase usa uma função assíncrona para carregar Three.js. Essa escolha preserva a abertura direta do arquivo HTML. Uma migração futura para módulos com servidor e empacotamento deve ser uma tarefa própria, com teste da reprodução local e da publicação.

## Materiais

- Guarde o material original de um personagem em `art/source/characters/<nome>/<versao>/`.
- Guarde referências em `art/references/characters/<nome>/`.
- Coloque somente recursos usados pelo jogo em `assets/characters/<nome>/`, `assets/ui/` e `assets/audio/`.
- Quando surgirem modelos/texturas de cenário, use `assets/environments/<cenario>/` e `art/source/environments/<cenario>/`.
- Use nomes de arquivo em minúsculas, sem espaços ou acentos, separados por hífen para recursos novos. Os originais recebidos preservam seus nomes.
- Registre autoria, origem, licença e alterações em `docs/licenses/` antes de distribuir recursos novos.

O pacote Berin v2 permanece completo em `art/source/characters/berin/v2/`, incluindo seu visualizador e relatórios. O arquivo `assets/characters/berin/berin-model.js` é uma cópia codificada do GLB LOD0: existe para abrir o jogo diretamente como arquivo local. Não edite esse arquivo à mão. Após atualizar o GLB, execute `python tools/prepare_berin.py`.

As URLs de imagens no CSS são relativas ao arquivo CSS. Os caminhos de áudio e GIF em JavaScript são relativos ao HTML. Preserve essa diferença ao mover arquivos.

## Histórico e segurança dos arquivos

`archive/prototype-before-organization/` guarda o código anterior à separação, para consulta; não é um jogo completo independente. `docs/history/prototype-notes.md` preserva as notas anteriores. `docs/organization.json` registra os movimentos feitos e a conferência de integridade dos arquivos movidos.

Não utilize a pasta de arquivo como fonte de código atual. Não foram removidos os materiais originais nem renomeados os arquivos internos do pacote Berin v2.

## Berinbinha

Fonte preservada em art/source/characters/berinbinha/v1. O jogo usa LOD1 (20 mil triângulos) compartilhado entre os 13 lacaios. Atualize o recurso local com `python tools/prepare_berinbinha.py`. As versões de maior/menor detalhe permanecem na fonte; não há troca automática de LOD. O pacote é estático e ainda exige rig/animações para gestos articulados.

A recepção agora usa a derivação animada Berinbinha_Reception.glb, com editável em art/source/characters/berinbinha/reception-v1. O pacote estático v1 foi preservado. tools/prepare_berinbinha.py incorpora o GLB animado atual.
