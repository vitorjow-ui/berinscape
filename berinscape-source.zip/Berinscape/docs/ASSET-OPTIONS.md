# Opções para a floresta — aguardando escolha

Consulta: 8 de novembro de 2026. Nenhum destes recursos foi integrado nesta etapa.

Dados de download, licença e contagem conferidos nas páginas públicas e na API do Sketchfab. CC Attribution exige creditar o autor. Aparência final, materiais e clipes precisam ser conferidos após baixar o recurso escolhido.

| Código | Modelo | Autor | Triângulos | Animações | Observação |
| --- | --- | --- | --- | --- | --- |
| A1 | [Dead Tree](https://sketchfab.com/3d-models/dead-tree-33ccce6111604656a4b5709483670ec3) | MaX3Dd | 3.252 | 0 | Árvore inteira com texturas PBR; candidata para repetição pela floresta. |
| A2 | [Dead Tree Trunk](https://sketchfab.com/3d-models/dead-tree-trunk-d2d5d04533c7400c8547bce4e05f8257) | ngooiwong | 23.384 | 0 | Tronco esculpido e texturizado; candidato para detalhes próximos do caminho. Não substitui sozinho árvores completas. |
| L1 | [Animated Wolf](https://sketchfab.com/3d-models/animated-wolf-23a3a563d48049d5b9844ddc1b5b6e79) | igor-lir | 27.268 | 1 | Autor descreve lobo realista parado animado. Não considerar caminhada/corrida confirmadas. |
| L2 | [Wolf](https://sketchfab.com/3d-models/wolf-f53173981deb44559419fd0370d5a4c8) | AX-7YK | 3.192 | 0 | Alternativa leve com textura de 512 px; menos detalhe. Requer preparar animações e conferir rig. |

Todos os quatro estão marcados como baixáveis e CC Attribution na consulta. A biblioteca pode exigir conta para baixar.

Alternativa de licença CC0: [3d wolf — NewDLC](https://opengameart.org/content/3d-wolf). O autor informa rig, FBX e Blender, 2.923 vértices e 5.358 faces; clipes de animação não confirmados.

O conhecido [Wolf with Animations — 3DHaupt](https://sketchfab.com/3d-models/wolf-with-animations-f3769a474a714ebbbaca0d97f9b0a5a0) foi excluído da recomendação principal porque sua licença é CC BY-NC-SA, restrita a uso não comercial.
