# Melhorias 11–20 — primeira fase

Implementação: 09/11/2026. Mantidos história, personagens, modelos aprovados, floresta, lobos, 120 moedas, vida a cada 50, recepção e encerramento no trono.

| Ranking | Resultado |
| --- | --- |
| 11 | Corrida Run do rig com cadência própria, transição de passada, inclinação e movimento secundário da capa. Shift continua dobrando a velocidade. |
| 12 | O GIF foi substituído na reprodução por uma sequência 3D de nove segundos: mão na cabeça, levantar, rir e caminhar. Original preservado no projeto. |
| 13 | Taverna construída com balcão, bancos, garrafas, luz quente e portas animadas; saída conectada à floresta real. A câmera começa perto de Berin e se afasta após os primeiros metros para evitar o telhado. |
| 14 | Três peças móveis da grade sobem; Berin atravessa a soleira antes da recepção. Cena de 4,8 segundos, com opção de pular. |
| 15 | Risada gravada e editada como assinatura de Berin, usada no início e entre as duas partes da resposta no trono; movimento de corpo/cabeça acompanha o disparo. É uma gravação CC0 adaptada, não uma interpretação exclusiva encomendada. |
| 16 | Falas preparadas em português e reproduzidas de arquivos locais, com dois tratamentos vocais. Mesmos arquivos em todos os navegadores; legendas continuam independentes. Voz-base Microsoft Daniel, renderizada offline: ainda é voz sintética, não elenco de atores. |
| 17 | Efeitos gravados de madeira, metal e couro para interface; Jogar recebe impacto mais forte. Também cadeira, porta, grade, passos por superfície, moeda e recompensa. |
| 18 | Volume geral, música, ambiente/passos, interface e vozes independentes; compressor, margem de pico, redução da música durante falas e pausa com retomada do ponto do áudio. |
| 19 | Música específica para menu, floresta, revelação do castelo, salão e ameaça no trono, com transições graduais. Fate and Fortune e The Long Dark mantidas; três trechos de Juggernaut acrescentados. Todas de Scott Buckley, CC BY 4.0. |
| 20 | Gravações naturais de floresta noturna e vento em árvores, com emendas de loop e distribuição estéreo, mais galhos discretos. Removida a base de osciladores. |

## Validação

- Percurso HTTP local: menu, floresta com Shift, revelação, entrada animada, recepção, ordem de Berin, caminhada no salão e conversa no trono.
- Chegada ao castelo/trono: 120 moedas e 5 vidas; Berinbinhas e seus nomes preservados.
- Nova câmera na saída conferida visualmente sem obstrução pelo telhado; configurações legíveis em janela de 662 × 662.
- Durante a fala de Berin, Esc congelou o áudio em 0,021 s; abrir configurações e testar botão manteve o mesmo ponto. Continuar retomou a fala e seu relógio avançou. Segunda parte da fala iniciou automaticamente após a sequência intermediária.
- Reprodução real do contexto de áudio e progresso da música conferidos no navegador. Isso comprova funcionamento, não substitui escuta crítica humana do timbre e da mixagem.
- 26 amostras, 2.267.541 bytes; maior pico decodificado: 0,84. Sem amostras digitais acima do limite. Compressor não equivale a uma medição de loudness de todas as sobreposições em tempo real.
- Rig real: corrida/capa exercitadas por 240 quadros sem rotações inválidas. Castelo real: três peças de grade com elevação vertical de 5,1 m.
- Testes de áudio: categorias, volume independente, cancelamento sem disparo indevido, pausa com offset preservado e encadeamento fala → risada. Testes de estado/recompensa/carregamento anteriores mantidos.

## Arquivos e reprodução

Áudio preparado em assets/audio/premium; manifesto pequeno no menu e amostras carregadas sob demanda. Banco incorporado mantido para abertura direta. Originais, licenças e pedidos locais de voz preservados em art/source/audio/premium-intro. Preparação: tools/prepare_intro_voices.py (Windows com Microsoft Daniel instalado) e tools/prepare_premium_audio.py (NumPy e FFmpeg via imageio-ffmpeg). O jogo não precisa dessas ferramentas para tocar os arquivos prontos.

A geração online de voz foi bloqueada pela revisão automática por envolver compartilhamento não autorizado da história. A implementação final usa somente renderização local das falas, sem envio do texto a serviços externos.

## Limites

Teste visual e funcional feito na prévia HTTP local. A ferramenta bloqueia URLs de arquivos locais; nenhum contorno foi tentado. Fallback direto conferido pelos arquivos e correspondência dos bancos, sem validação de reprodução nessa modalidade. Three.js ainda exige internet. Não houve medição de FPS em equipamento alvo, certificação de todos os navegadores nem aprovação auditiva subjetiva. A animação continua limitada pelo rig existente: sem captura de movimento ou sincronização labial nova. Não foi criada próxima fase.

Conferência final: 14 scripts JavaScript com sintaxe válida, ferramentas Python compiladas e verificação integral dos 26 áudios e bancos incorporados aprovada. Percurso encerrado com a resposta do Berinbinha, tela de fim e retorno funcional ao menu; consulta de erros/avisos vazia. Na repetição da abertura foi corrigido um plano bloqueado pela porta, antecipando sua abertura e centralizando a câmera.

## Ajuste solicitado: cena original preservada

A pedido do autor, restaurada a animação original assets/ui/menu/berin-tavern.gif na abertura ao clicar Jogar. O menu mantém a imagem parada aprovada; na nova jornada, aplica zoom, reproduz novamente a cena de Berin bebendo, toca a risada e faz a transição para a floresta. A apresentação 3D substituta deixou de ser chamada. Continuar uma jornada salva permanece direto no ponto guardado. Demais melhorias de corrida, castelo, áudio e história preservadas. Verificação de arquivos e sintaxe aprovada; GIF original não foi reprocessado.

## Correção da música na passagem para a fase

A música de abertura agora é interrompida e zerada ao terminar ou pular o GIF, durante o escurecimento antes de liberar o controle. A floresta assume sua trilha. Ao voltar ao menu, as trilhas da fase são interrompidas. Promessas atrasadas de reprodução não podem reativar uma trilha de outra cena. Testes com áudio simulado exercitaram reprodução pendente, pausa imediata, volume/ganho zerados, trilha da floresta ativa e retorno ao menu, em HTTP e no caminho de arquivo local. Não constitui escuta ou reprodução real no navegador.
