# Modelos escolhidos para a primeira fase

Escolha aprovada pelo autor: A1 + A2 para as árvores e L1 para os lobos. Aplicar vários exemplares, mantendo os lobos andando pela floresta. Não avançar para uma nova fase.

## Materiais

| Código | Modelo e autor | Destino dos originais |
| --- | --- | --- |
| A1 | [Dead Tree — MaX3Dd](https://sketchfab.com/3d-models/dead-tree-33ccce6111604656a4b5709483670ec3) | art/source/environments/forest/dead-tree-max3dd/ |
| A2 | [Dead Tree Trunk — ngooiwong](https://sketchfab.com/3d-models/dead-tree-trunk-d2d5d04533c7400c8547bce4e05f8257) | art/source/environments/forest/dead-tree-trunk-ngooiwong/ |
| L1 | [Animated Wolf — igor-lir](https://sketchfab.com/3d-models/animated-wolf-23a3a563d48049d5b9844ddc1b5b6e79) | art/source/animals/wolf-igor-lir/ |

Licença informada pelos três autores: CC Attribution, com link para CC BY 4.0. Manter crédito ao autor, link do modelo, licença e registro de eventuais alterações na entrega integrada.

## Plano de integração

1. Receber os arquivos originais, preferencialmente a versão glTF/GLB com texturas. Preservar ZIPs e licenças fornecidas.
2. Conferir malhas, materiais, dimensões, orientação e caminhos das texturas.
3. Inspecionar o único clipe informado de L1; o autor descreve um lobo parado animado, portanto caminhada ainda não está confirmada. Preparar caminhada se necessário antes de substituir os animais em movimento.
4. Repetir árvores com variações de escala e rotação, usando compartilhamento de geometria/texturas e agrupamento por região. Posicionar A2 como detalhe nas laterais do caminho.
5. Distribuir vários lobos em trajetos laterais, com animações independentes, sem atacar Berin ou bloquear o caminho nesta entrega.
6. Conferir coleta das 120 moedas, vidas, transição para o castelo e recepção dos lacaios.

## Estado desta tentativa

Download ainda não obtido: o endpoint oficial exige autenticação e o botão de download da página A1 abriu a janela de login. A aba foi deixada disponível para o autor entrar em sua conta. Alternativa: o autor baixar os três ZIPs e indicar sua pasta local.

Nenhum modelo escolhido foi substituído por outro ou aplicado sem o arquivo original. O jogo continua com os recursos já implementados até a liberação dos downloads.

## Atualização posterior

O autor escolheu uma floresta completa e forneceu o GLB do cenário de dasy444. Esse cenário substitui a integração separada das árvores A1/A2 na entrega atual. Os lobos em movimento existentes foram mantidos; o arquivo L1 não foi fornecido. Ver docs/PHASE-01.md para a integração concluída do cenário completo.
