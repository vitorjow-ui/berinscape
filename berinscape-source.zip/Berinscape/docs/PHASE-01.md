## Versão atual — 09/11/2026

As prioridades 1–10 estão aplicadas. Esc agora pausa; o menu oferece continuação por checkpoint, e os recursos 3D carregam por área. Conferência completa e limites em [TOP10-IMPLEMENTATION.md](TOP10-IMPLEMENTATION.md). As seções seguintes registram a evolução da fase.

# Fase 1 — O retorno de Berin

## Sequência confirmada pelo autor

1. Berin sai da taverna e segue para o castelo pela Floresta Negra.
2. Recolhe moedas no caminho. A cada 50 moedas ganha uma vida. Moedas e vidas têm contadores.
3. A floresta tem música e animais, incluindo lobos e morcegos em movimento.
4. Ao entrar no castelo, é recebido pelos Berinbinhas gritando “Berin! Berin!”.
5. Há um corte de cena; Berin dá uma ordem aos Berinbinhas. O controle volta ao jogador.
6. Berin percorre um salão cheio de riquezas até o trono.
7. Um Berinbinha avisa sobre guerreiros em um vilarejo ao norte preparando um exército para invadir o castelo e se vingar de Berin.
8. Berin ri, despreza a ameaça e manda seus Berinbinhas se prepararem para receber o campeão.
9. O Berinbinha responde; a cena termina. A próxima cena fica para outra etapa.

## Falas

As três falas completas fornecidas pelo autor estão preservadas em `src/story/intro.js`. A fala inicial de recepção “Abram caminho! Seu rei está de volta!” é provisória: o autor pediu uma ordem, mas ainda não forneceu seu texto. Não tratar essa frase como diálogo definitivo aprovado.

## Implementação desta entrega

- 120 moedas distribuídas em pares no percurso; coleta por proximidade, brilho/giro e efeito sonoro.
- 3 vidas iniciais como escolha provisória de balanceamento; bônus em 50 e 100 moedas, sem zerar o total acumulado.
- O reinício da partida restaura moedas e vidas. Ainda não há salvamento entre sessões.
- Animais são decorativos e não causam dano; não foi pedido combate nesta fase. Logo, nesta entrega vidas podem ser ganhas, mas não perdidas.
- Lobos, morcegos, Berinbinhas e interior usam modelos procedurais provisórios. Não representam a arte final realista.
- Música da floresta: The Long Dark — Scott Buckley, CC BY 4.0. Menu/salão usam Fate and Fortune, do mesmo compositor. Créditos nas configurações e em docs/licenses/music.txt.
- Cenas bloqueiam movimento, enquadram os personagens e apresentam legendas completas. Clique em Continuar ou use Espaço/Enter para avançar. As falas não avançam sozinhas.
- Voz provisória por síntese de fala do navegador, quando há uma voz em português disponível. O controle nas configurações permite desligá-la; o volume acompanha os efeitos. Não há dublagem final, coro gravado dos Berinbinhas ou animações faciais/labiais.
- Ao terminar a conversa, ocorre um escurecimento e aparece o encerramento deste trecho. Nenhuma cena seguinte foi inventada.

## Verificação

Conferidos sintaxe dos scripts, caminhos de recursos, limiares de vidas em 49/50/100 moedas, prevenção de coleta duplicada, reinício e encadeamento recepção → salão → trono → encerramento em ambiente simulado. A revisão audiovisual e de desempenho no navegador alvo ainda é necessária.

## Revisão visual — lobos, Berinbinhas e salão

Modelagem procedural detalhada substitui os bonecos simples: lobos com tronco contínuo, focinho afilado, olhos, orelhas, pelagem texturizada, patas articuladas e cauda; Berinbinhas seguem a referência aprovada com barriga, camisa listrada, máscara, cabelos loiros, coroa/capa roxas, medalhão, dente de ouro e grilhões. A escala foi reduzida para manter os Berinbinhas menores que Berin.

O salão ganhou mármore texturizado, passadeira bordada, colunas compostas, abóbada, arcos, estandartes, janelas, braseiros, baús com ferragens, moedas instanciadas, taças, gemas e trono com relevo de coruja. As peças estáticas são agrupadas por material para reduzir chamadas de desenho; moedas de decoração permanecem instanciadas.

Tudo foi criado no código do projeto; não foram adicionados recursos externos ou licenças novas. São modelos procedurais com materiais mais detalhados, ainda sem escultura/rig final de produção nem simulação de pelos e tecido. A história, diálogos, percurso, moedas e vidas não mudaram.

Conferidos com Three.js r180 real: construção dos modelos e salão, coordenadas finitas, instâncias das moedas, animação de fauna, coleta das 120 moedas e reinício. A ferramenta de navegador bloqueou a abertura do arquivo local; inspeção audiovisual e desempenho na máquina alvo continuam pendentes.

## Berinbinha original integrado

Os 13 Berinbinhas (12 na recepção e um conselheiro) agora usam Berinbinha_LOD1.glb, fornecido pelo autor, substituindo a modelagem procedural dos NPCs. O pacote completo foi copiado sem alterações para art/source/characters/berinbinha/v1, com integridade conferida. O modelo usado pelo jogo está incorporado em assets/characters/berinbinha/berinbinha-model.js; pode ser regenerado por tools/prepare_berinbinha.py.

Cada personagem compartilha geometria, materiais e texturas do mesmo modelo. A altura com coroa foi normalizada para aproximadamente 1,40 m, preservando a escala pequena diante de Berin. O pacote não contém rig nem animações. A recepção usa somente balanço e pequeno salto do corpo inteiro, sem deformar a malha ou simular articulação inexistente. A modelagem procedural dos Berinbinhas foi retirada; lobos e salão permanecem como na revisão visual anterior.

Conferidos cabeçalho e estrutura GLB, correspondência binária do arquivo incorporado, construção dos 13 NPCs no Three.js r180 usando a geometria real do pacote, compartilhamento da geometria, escala, atualização da recepção e preservação da coleta das 120 moedas. Não houve inspeção do render final ou decodificação de texturas nesse teste de geometria.

## Recepção animada

O Berinbinha fornecido agora tem uma versão derivada com esqueleto de 9 ossos e clipes Idle/Cheer. Os 13 Berinbinhas usam SkeletonUtils.clone para manter ossos e AnimationMixers independentes, compartilhando geometria, texturas e materiais. Braços levantam e alternam movimentos durante o grito; pulos e balanço variam entre personagens. Ao começar a ordem de Berin, retornam suavemente ao repouso.

A versão original permanece em art/source/characters/berinbinha/v1. O editável da recepção fica em art/source/characters/berinbinha/reception-v1; o GLB de jogo, em assets/characters/berinbinha/Berinbinha_Reception.glb. Gerar com Blender --background --factory-startup --python tools/rig_berinbinha.py, depois python tools/prepare_berinbinha.py. Imagens diagnósticas em art/previews/berinbinha-reception.

O coro local foi sintetizado com a voz Microsoft Maria instalada no Windows, sobreposto em seis camadas com variações de tom, atraso e posição estéreo. Não é uma gravação de atores. Está em assets/audio/voices/berin-crowd.wav e incorporado em berin-crowd.js para permitir abertura como arquivo local. O coro repete apenas durante a fala dos Berinbinhas; para ao avançar, voltar ao menu ou desligar vozes. O volume usa o controle de efeitos. As outras falas mantêm a síntese do navegador.

Verificações: renders de repouso/comemoração no Blender; GLB reaberto no GLTFLoader/Three.js r180 em teste de CPU (texturas substituídas por placeholders apenas no teste); 13 NPCs com ossos independentes; geometria compartilhada; mãos sobem de cerca de 0,62 m para 1,32–1,35 m; vértices deformados finitos; retorno ao repouso. Rig específico para a recepção, ainda sujeito a refinamento em ombros/roupa, sem rig facial ou animação de dedos. Conferência audiovisual final no navegador alvo permanece necessária.

## Corrida e árvores mortas

Shift agora dobra a velocidade alvo: caminhada 1,7 m/s, corrida 3,4 m/s. A aceleração suave e a normalização diagonal foram mantidas, assim como a coleta e os limites do percurso. O movimento mantém o clipe Walk acelerado; ainda não é uma nova animação final de corrida.

Os pinheiros foram substituídos por 240 árvores mortas sem folhas, com troncos inclinados, raízes, galhos bifurcados e casca texturizada. 5.280 segmentos compartilham uma única malha instanciada em src/scenes/dead-forest.js. Nenhum modelo externo foi usado nessa troca.

Conferidos matrizes das instâncias sem valores inválidos, quantidade de segmentos e razão 2:1 entre corrida/caminhada em simulação do código de movimento real. Referências locais passaram na ferramenta de verificação.

## Cenário completo importado — dasy444

O autor forneceu a_forest_3_with_a_road_at_night_for_game.glb (29.086.420 bytes). A floresta foi aplicada à primeira fase, substituindo o terreno e as árvores procedurais anteriores. O original está preservado em art/source/environments/forest/dasy444. Os lobos existentes continuam andando; o modelo L1 do Sketchfab ainda não foi recebido, portanto não foi usado nesta entrega.

A preparação remove a área de mostruário separada ao lado da paisagem e agrupa as aproximadamente 1.480 malhas de origem em 38 malhas de jogo. Texturas 2K originais foram mantidas. Vegetação recortada por transparência usa alpha test para evitar problemas de ordenação das copas. Escala, iluminação e materiais foram ajustados para a fase noturna. Créditos em configurações e docs/licenses/forest-road-night.txt.

O percurso acompanha a estrada curva existente, com cerca de 107 m. A posição de gameplay (distância ao longo da estrada e afastamento lateral) é separada da posição 3D no cenário. Uma grade de alturas amostrada por raycast no terreno faz personagem, moedas, lobos, morcegos e tochas acompanharem os desníveis. O clique projeta o destino no terreno, e a câmera acompanha o rumo da estrada. A travessia termina no castelo reposicionado na saída da floresta, preservando salão e diálogos.

Preparação: Blender --background --factory-startup --python tools/prepare_forest_scene.py; depois python tools/embed_forest.py. A versão de jogo está em assets/environments/forest-road-night. A abertura direta do HTML continua suportada por forest-model.js.

Verificação: renders reais do cenário, grade de alturas e curva no Three.js r180; simulação da inicialização completa da fase, caminhada/corrida, coleta das 120 moedas, chegada ao castelo e trono, e reinício. Também foi conferido no navegador via servidor local: cenário/texturas carregados, Berin no chão, movimento por clique e contador avançando para 8 moedas. A prévia mostrou os lobos na lateral do caminho. O teste de navegação pelo cenário completo até o trono foi simulado, não uma travessia manual integral no navegador.

## Lobo fornecido pelo autor — COD Ghosts Wolf Puppy

Os sete lobos procedurais foram substituídos pelo arquivo cod_ghosts_wolf_puppy.glb fornecido pelo autor. Não é o modelo L1 anteriormente pesquisado. O original de 3.812.644 bytes está preservado em art/source/animals/cod-ghosts-wolf-puppy/original.glb.

O arquivo não tinha skins ou clipes, e as malhas principais estavam em escala diferente dos olhos/acessórios. A versão preparada corrige escala/orientação, remove dois pequenos cubos auxiliares e cria um rig de 16 ossos com Idle/Walk. Texturas e malhas visíveis do lobo foram mantidas. A caminhada é uma animação nova de ambientação, não uma animação original de COD nem um rig de combate final. Renders de inspeção em art/previews/wolf-puppy.

Os sete animais usam ossos/mixers independentes com geometria e texturas compartilhadas. As patas acompanham um ciclo de caminhada, e a reprodução se ajusta à velocidade estimada do trajeto. Os lobos continuam seguindo o terreno nas laterais da estrada, sem atacar ou impedir a passagem. Moedas, vidas, castelo e diálogos permanecem inalterados.

Reproduzir preparação: Blender --background --factory-startup --python tools/prepare_wolf_puppy.py; depois python tools/embed_wolf.py. Créditos transcritos dos metadados do arquivo em docs/licenses/wolf-puppy.txt e configurações.

Conferidos: render Idle/Walk no Blender, leitura dos clipes pelo GLTFLoader real, 7 lobos/42 malhas com skin, independência de ossos entre animais, vértices deformados finitos, coleta das 120 moedas, acesso ao castelo/trono e reinício em teste de CPU.

A revisão no navegador confirmou o carregamento da fase e a coleta de moedas com o novo modelo. Os trajetos laterais foram aproximados da estrada (centro a 3,1–4 m do eixo), para os lobos ficarem mais visíveis entre os arbustos.

## Interface de jogo compacta

O painel anterior foi substituído por HUD distribuído nas bordas: identificação de Berin e contadores de moedas/vidas no canto superior esquerdo; região, objetivo e progresso do percurso no topo central; botão Menu com indicação Esc no canto direito. Uma barra mostra moedas no ciclo da próxima vida (0–49 / 50), preservando o total acumulado e a concessão da vida extra a cada 50.

Controles foram retirados do painel permanente e ficam num botão de ajuda no canto inferior esquerdo, que abre/fecha por clique e expõe aria-expanded/aria-controls. A ajuda fecha ao reiniciar/voltar ao menu. Não foram acrescentados atributos de RPG inexistentes, como nível, mana ou vida em pontos. Estilo em styles/hud.css, com regras para desktop e telas estreitas. Mensagens repetidas de objetivo foram removidas do rodapé; avisos e diálogos permanecem.

Referências da interface e sintaxe passaram na verificação. Abertura/fechamento da ajuda e proporções foram conferidos no navegador, incluindo layout estreito; o tamanho de prévia foi restaurado após a inspeção.


## Castelo medieval e acabamento do salão

O exterior usa agora o Medieval Castle de Uğur Yakışık, fornecido pelo usuário. Original preservado; texturas reduzidas a 1024 px, de 115,9 MB para 36,9 MB. A soleira está alinhada ao término da estrada, com iluminação quente na entrada. Uma pequena clareira e o nivelamento do terreno evitam árvores atravessando a fachada.

O salão procedural aprovado foi mantido. Recebeu três lustres com velas, vitral circular, rodapés, incrustações douradas e luz com sombra dedicada ao trono. Recepção, Berinbinhas, moedas, vidas e diálogos continuam na mesma fase. Créditos nas configurações e em docs/licenses/medieval-castle.txt.


## Revisão de 08/11/2026 — nome dos servos

Nome exibido nos diálogos: **Berinbinha (Servo de Berin)**. Berin passa a dizer “Meu fiel Berinbinha”. O coro mantém “Berin! Berin!” e seu disparo depende do tipo de cena, não mais do nome do falante. A história e os modelos foram preservados.

Revisão premium com 100 prioridades em docs/REVIEW-PREMIUM-100.md; conferência geral em docs/CHECK-GERAL-2026-11-08.md.

## Acabamento 11–20 (09/11/2026)

Saída da taverna em 3D, corrida/capa, passagem pela grade e áudio preparado por cena. Controles independentes de volume e falas locais com pausa/retomada. Escopo narrativo preservado. Consulte [implementação e testes](TOP20-IMPLEMENTATION.md) e [créditos de áudio](licenses/premium-audio.txt).

## Noite e iluminação (10/11/2026)

Melhorias 21–30 aplicadas: floresta noturna, 13 tochas na estrada e duas no portão, fogo com brasas, luzes quentes, soleira de pedra e sombras aprimoradas. A recepção continua legível sob iluminação quente. Cena original de Berin bebendo preservada. Consulte [detalhes e validação](TOP30-IMPLEMENTATION.md).
