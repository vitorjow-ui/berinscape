# Conferência geral — 08/11/2026

## Alteração aplicada

- Recepção e conversa no trono identificam o servo como **Berinbinha (Servo de Berin)**.
- A resposta do mestre começa com “Meu fiel Berinbinha”.
- Coro “Berin! Berin!” preservado. A reprodução é identificada pela cena `crowd`, sem depender do rótulo do falante.
- Referências dos scripts alterados receberam versão na URL para evitar que uma cópia antiga esconda a mudança.
- Documentação atual ajustada; registros históricos e arquivos originais permanecem preservados.

## Jogabilidade conferida no navegador

Prévia local em 127.0.0.1:8765. Revisão inicial em 1280×720 e observação posterior em janela menor, aproximadamente 662 px de largura. Não constitui uma matriz completa de dispositivos.

| Verificação | Resultado |
| --- | --- |
| Menu, abertura das configurações e retorno | Funcionaram |
| Volume ajustado por teclado e retorno ao menu | Funcionaram |
| Jogar, animação da taverna e transição | Funcionaram; fluidez e apresentação merecem o acabamento listado no ranking |
| Caminhada e Shift | Funcionaram; caminhada acelerada ainda substitui animação própria de corrida |
| Clique na estrada e roda para câmera | Funcionaram; limites do destino e obstáculos precisam de refinamento |
| Abrir/fechar ajuda dos controles | Funcionou |
| Coleta em uma passagem completa | 120 moedas, 5 vidas e progresso 20/50 até a próxima vida |
| Passagem com trajeto lateral por clique | 89 moedas e 4 vidas; é possível deixar moedas para trás |
| Entrada no castelo e recepção | Funcionaram |
| Berinbinha (Servo de Berin) no cabeçalho da recepção | Confirmado na revisão com scripts atualizados |
| Nome e “Meu fiel Berinbinha” no trono | Confirmados no navegador |
| Diálogos, tela final e retorno ao menu | Percurso completo concluído na primeira passagem |
| Console da página | Sem mensagens de erro ou aviso registradas na consulta realizada; não é garantia de ausência em outros ambientes |

## Conferências dos arquivos e regras

- `python tools/verify.py`: passou para referências, IDs, modelos incorporados, logo, áudio e créditos.
- Os 11 arquivos de código JavaScript foram analisados sem erro de sintaxe.
- Teste da progressão: começa em 0 moedas/3 vidas; dá vida extra exatamente nas moedas 50 e 100; termina com 120/5; moeda repetida não conta; reiniciar limpa moedas, vidas e identificadores coletados.
- Conferência do roteiro: recepção e duas falas do conselheiro têm o nome novo; a resposta de Berin o chama de Berinbinha.
- O ranking contém exatamente 100 posições, numeradas de 1 a 100, sem lacunas.

## Problemas e limites relevantes

- Botão de áudio e rodapé disputam espaço no menu em 1280×720.
- Esc sai para o menu; ainda não existe pausa com retomada.
- Caixa de diálogo cobre parte do servo; close de Berin precisa de melhor composição.
- A recepção pode revelar vazio atrás do personagem e um enquadramento transitório inadequado na troca de área.
- Movimento, fauna, fogo e materiais ainda exibem sinais de protótipo.
- A distribuição usa arquivos incorporados grandes; a biblioteca Three.js depende de CDN/internet.
- O lobo veio de um envio intitulado COD Ghosts Wolf Puppy: registrar e revisar a procedência antes da distribuição pública, conforme item 99 do ranking.
- Não foi feita escuta humana certificada, medição de FPS, teste em todos os navegadores, teste sem internet nem simulação de todas as falhas de carregamento. A revisão sonora combina lógica e recursos existentes; a mixagem precisa de escuta dedicada.

## Preservação

A versão será preservada em `../backups/Berinscape_DATA_HORA/`, fora da pasta incluída no próprio arquivo. O ZIP completo contém código, recursos de execução, arte original, documentação e ferramentas. Manifesto SHA-256 por arquivo e leitura integral do ZIP verificam a cópia. O registro definitivo do backup, com nome, tamanho e hash, fica em `checkpoint.json` ao lado do ZIP.

O backup preserva os arquivos atuais; ainda não há salvamento de progresso do jogador. O ranking é um plano, não uma declaração de que as 100 melhorias foram implementadas.
