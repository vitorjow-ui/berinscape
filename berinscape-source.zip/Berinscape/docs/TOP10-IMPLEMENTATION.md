# Prioridades 1–10 — implementação e conferência

Data da revisão: 09/11/2026. Referência: `REVIEW-PREMIUM-100.md`.

## O que foi aplicado

| Prioridade | Implementação nesta versão |
| --- | --- |
| 1 — Carregamento confiável | Painel com etapa, bytes processados e progresso real; erro mantém a interface acessível; nova tentativa e retorno ao menu; limite de inatividade na transferência; validação de tamanho e formato; falhas saem do cache para permitir repetição. O mundo só é publicado depois da preparação dos materiais. |
| 2 — Pausa | Esc e botão Pausa abrem Continuar, Configurações e Salvar e voltar ao menu. Posição, destino, câmera, moedas, vidas e fala atual permanecem. A simulação e as animações param; as trilhas são pausadas, e as vozes são suspensas. Perda de foco também pausa. |
| 3 — Clique consistente | Projeção contínua por segmento em vez de escolher apenas a amostra mais próxima; rejeição explícita de destinos fora da faixa e do salão; marcador de destino preservado. A movimentação continua limitada ao caminho aprovado, sem criar exploração livre ou combate. |
| 4 — Apoio no terreno | Correção leve nos ossos existentes de coxa e canela, com apoio calculado na altura local e limites para preservar a anatomia; sombra suave de contato. Caminhada e corrida usam a velocidade real. A animação Run já existente no pacote é usada ao segurar Shift. |
| 5 — Câmera protegida | Limite contra arquitetura; altura mínima acima do terreno; transparência gradual dos lotes de vegetação que encobrem o personagem. As caixas espaciais da floresta evitam percorrer todas as folhas a cada quadro. |
| 6 — Direção visual coerente | Luz noturna mais controlada, reflexos ambientes suaves, materiais de personagens com acabamento menos plástico e uma paleta consistente de pedra, roxo, ouro, luz fria externa e luz quente interna. Os modelos e a identidade aprovados foram mantidos. |
| 7 — Diálogos legíveis | Caixa menor numa área inferior reservada, rolagem para falas longas e câmeras recompostas para recepção, servo e resposta de Berin. Os planos são posicionados antes da revelação, evitando o passeio inicial da câmera desde a área anterior. |
| 8 — Salão completo | Parede de chegada, portas recuadas de madeira, ferragens, puxadores e moldura em pedra completam o fundo atrás de Berin. O salão existente, o trono, as riquezas e os Berinbinhas permanecem. |
| 9 — Recursos por demanda | Nenhum modelo 3D abre junto com o menu. A floresta carrega Berin, cenário e lobos; castelo e servos são preparados mais perto da chegada. Retomar no salão carrega apenas Berin e os servos, sem abrir a floresta. O servidor local envia versões comprimidas dos GLBs; o caminho HTTP elimina a duplicação por base64. |
| 10 — Retomada | Salvamento automático a cada dois segundos de simulação, ao pausar, sair e trocar falas; botão Continuar no menu; restauração de posição, câmera, moedas únicas, vidas derivadas e fala. Nova jornada pede confirmação e só substitui o progresso depois de carregar com sucesso. Dados inválidos não são retomados. |

## Preservado

Menu da taverna com Berin, logo e moedas; animação de entrada; músicas e efeitos existentes; Berin controlável; os dois modos de movimento; Shift em velocidade dobrada; floresta e castelo aprovados; sete lobos, morcegos, tochas e céu noturno; 120 moedas; três vidas iniciais e mais uma a cada 50; os 13 Berinbinhas; recepção com comemoração e coro; salão, riquezas, trono, falas e encerramento deste trecho. Não foi criada outra fase nem alterado o sentido da história.

## Conferência realizada

- Percurso no navegador pela prévia HTTP local: menu → taverna → floresta → entrada → recepção → caminhada pelo salão → três falas no trono → encerramento → menu.
- Contadores confirmados no trajeto: 66 moedas/4 vidas na pausa; 120 moedas/5 vidas ao chegar ao salão.
- Pausar impediu avanço com W; o progresso do percurso permaneceu exatamente igual antes e depois da tentativa de movimento.
- Configurações puderam ser abertas e fechadas durante a pausa sem reiniciar.
- Salvar e voltar ao menu apresentou Continuar com 66 moedas; retomar preservou o mesmo percurso e não duplicou moedas.
- Recarregar e continuar funcionou na floresta, na primeira fala da recepção e na segunda fala do trono. A última retomada exibiu diretamente a resposta de Berin, com 120 moedas e 5 vidas.
- A nova confirmação de início foi exercitada antes do trajeto completo; a partida nova começou em 0 moedas/3 vidas.
- Conferência visual da recepção: porta e parede no fundo, personagens visíveis acima do painel. No trono, rosto e corpo do Berinbinha permaneceram visíveis; a resposta de Berin usa plano mais baixo e aberto.
- O encerramento retornou ao menu por Esc, sem manter o modal aberto; o botão Continuar deixa de oferecer uma jornada já concluída.
- Consulta de erros/avisos da versão atual no navegador: nenhuma mensagem na consulta final. Uma falha inicial de nomes de ossos foi detectada e corrigida antes destes testes.
- `tools/verify.py`: referências, IDs, créditos, modelos incorporados, manifesto e correspondência integral dos transportes comprimidos passaram.
- `tools/test_core.cjs`: recompensas em 50/100 moedas, duplicação, restauração, limites de estado, dados corrompidos, armazenamento indisponível, falha de rede, repetição e progresso por bytes passaram. Executado pelo ambiente JavaScript disponível; pode ser repetido com `node tools/test_core.cjs` onde Node estiver instalado.
- Os 13 arquivos JavaScript de execução passaram na análise de sintaxe.
- Geometria real da floresta conferida no Three.js: 93 posições com alturas finitas e projeção de ida/volta; maior desvio longitudinal observado: 0,036 m. Um clique projetado no ponto de 6 m retornou o mesmo destino.
- Apoio dos pés exercitado com o rig e a animação Walk reais por 120 quadros sobre uma superfície de teste; rotações permaneceram finitas.

## Carregamento: tamanhos dos arquivos, não promessa de desempenho

| Etapa | Modelos binários preparados | Transporte comprimido pela prévia local |
| --- | ---: | ---: |
| Menu | 0 MB de modelos | 0 MB de modelos |
| Começo na floresta | 41,9 MB | 37,1 MB |
| Retomada direta no salão | 22,2 MB | 20,6 MB |

O castelo, com 36,9 MB binários, é carregado depois, durante o percurso. O catálogo completo soma 89,3 MB binários. Os scripts base64 anteriores permanecem no disco exclusivamente para o caminho de abertura direta; não são mais carregados antecipadamente pelo HTML. O coro local continua pequeno e incorporado.

Na ferramenta de prévia houve limitação da cadência visual para aproximadamente um quadro por segundo. A atualização usa passos de simulação de até 50 ms e desenha uma vez por quadro, preservando deslocamento e coleta quando a cadência cai. Isso não constitui medição de FPS em computadores de jogadores ou garantia de desempenho em todos os dispositivos.

## Limites importantes da conferência

- O teste completo ocorreu em HTTP local. A política da ferramenta de navegador bloqueou URLs de arquivos locais; não foi tentado contornar esse bloqueio. O fallback de abertura direta foi mantido, e seus arquivos/binários foram conferidos, mas essa modalidade não foi validada no navegador nesta revisão.
- A biblioteca Three.js continua vindo da CDN. Distribuição totalmente offline permanece no item 98 do ranking.
- O apoio e a transparência da vegetação são correções leves para os recursos atuais, não novas animações capturadas ou uma remodelagem dos personagens.
- A revisão não certifica escuta, sincronização perfeita da síntese de voz em todos os navegadores, qualidade cinematográfica final ou compatibilidade com todos os equipamentos.
- O progresso fica no armazenamento deste navegador e desta origem. Abrir por arquivo e abrir pela prévia HTTP são origens diferentes e não compartilham necessariamente a mesma jornada. Backup de projeto e salvamento da partida são recursos distintos.

## Preparação e preservação

Depois de regenerar um modelo, atualizar seu script incorporado, executar `python tools/asset_manifest.py`, `python tools/pack_runtime.py` e `python tools/verify.py`. A cópia completa desta revisão é criada por `tools/checkpoint.py` em `../backups/`, com manifesto SHA-256 e verificação integral do ZIP. A versão anterior permanece preservada no backup de 08/11/2026.
