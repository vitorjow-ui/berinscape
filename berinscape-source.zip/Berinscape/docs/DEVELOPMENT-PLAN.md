# Plano de criação

Referência narrativa: [GAME-DESIGN.md](GAME-DESIGN.md). O plano organiza produção e validação; não autoriza inventar história pendente.

| Etapa | Entrega | Critério para avançar |
| --- | --- | --- |
| 1. Definição | Herói, motivação, resumo da introdução e regras mínimas de combate | O autor reconhece a história e aprova a experiência pretendida. |
| 2. Base técnica | Separação entre estado de menu, fase e personagens; carregamento, reinício e transições confiáveis | Abrir, jogar, sair e reiniciar sem duplicar entradas, áudio ou personagens. |
| 3. Combate de teste | Selecionar alvo, aproximar, atacar, usar uma habilidade, receber dano, vencer e perder | Combate compreensível e responsivo com um único inimigo; regras aprovadas antes de multiplicar conteúdo. |
| 4. Trecho de referência | Introdução de Berin e um trecho curto do herói, com visual, som e interação representativos | Conferência real no navegador alvo; aparência e desempenho aceitáveis. Não precisa conter duas fases completas. |
| 5. Introdução completa | Fase 1 com começo, objetivo, fim e passagem narrativa definida | Jogável do menu ao encerramento, sem depender de explicação fora do jogo. |
| 6. Produção das fases | Fases 2–9, uma por vez, seguindo as fichas de criação | Cada fase é concluível, reiniciável e se conecta à próxima antes de abrir uma nova frente de conteúdo. |
| 7. Confronto final | Fase 10, batalha com Berin e aprisionamento | O jogador entende como vencer e o desfecho respeita a história aprovada. |
| 8. Fechamento | Balanceamento, desempenho, salvamento conforme escopo e publicação | Percurso completo conferido, créditos presentes, recursos licenciados e controles documentados. |

## Como vamos trabalhar

O autor fornece contexto, intenção e referências; registramos decisões no documento de criação. Propostas continuam identificadas como propostas até serem aceitas. Para cada entrega, primeiro definimos o comportamento esperado, implementamos um trecho pequeno, conferimos no jogo e só então expandimos.

O objetivo imediato é desenvolver **a fase 1, controlando Berin**, começando pela definição de seus acontecimentos e encerramento. Zarek e sua motivação inicial já estão registrados; o trabalho detalhado com o herói e aliados fica para depois. O trecho de referência do herói indicado na tabela é uma etapa futura e não condiciona o início da fase 1. Não produzir dez cenários antes de validar a base do combate e um padrão de qualidade visual sustentável.

## Organização futura do código

Antes de multiplicar fases, reduzir o acoplamento atual entre interface e floresta: um controlador de estados, regras de personagem independentes do cenário, definição de habilidades e ciclo de vitória/derrota. Isso é trabalho planejado; ainda não está implementado. Preferir componentes pequenos conforme necessidades concretas, sem criar sistemas extensos antecipadamente.

## Riscos conhecidos

- As animações do Berin v2 ainda têm deformações; combate final exigirá revisão do rig e animações adequadas.
- A aparência realista depende de arte, iluminação e orçamento de desempenho, além da programação.
- O herói, adversários e interiores ainda precisam de design e produção de recursos.
- O protótipo atual não tem salvamento. A necessidade de retomada entre dez fases deve ser decidida antes de produzir uma aventura longa.
- O movimento atual limita o personagem a um caminho reto. Cenários mais abertos exigirão colisões e navegação apropriadas.

## Conferência por entrega

Conferir somente o que mudou: controles e câmera, avanço de fase e reinício, áudio e volume, carregamento e desempenho, além de regressões nas conexões afetadas. Testes simulados não substituem jogar e ouvir a entrega no navegador alvo.
