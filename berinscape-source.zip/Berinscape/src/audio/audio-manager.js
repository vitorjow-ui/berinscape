// Recorded foley, offline-rendered dialogue and licensed music. No runtime TTS.
class RecordedClip {
  constructor(owner,key,buffer,bus,options={}){
    this.owner=owner;this.key=key;this.buffer=buffer;this.options=options;this.offset=0;this.started=0;this.version=0;this.stopped=false;this.paused=false;
    this.gain=owner.context.createGain();this.gain.gain.value=options.gain??1;
    this.pan=owner.context.createStereoPanner();this.pan.pan.value=options.pan||0;this.gain.connect(this.pan).connect(bus);owner.handles.add(this);this.start();
  }
  start(){
    if(this.stopped)return;if(this.owner.paused&&!this.options.allowPaused){this.paused=true;return;}
    const context=this.owner.context,source=context.createBufferSource(),version=++this.version;source.buffer=this.buffer;source.loop=!!this.options.loop;source.playbackRate.value=this.options.rate||1;source.connect(this.gain);this.source=source;this.started=context.currentTime;this.paused=false;
    if(this.options.fade&&!this.offset){this.gain.gain.setValueAtTime(0,context.currentTime);this.gain.gain.linearRampToValueAtTime(this.options.gain??1,context.currentTime+this.options.fade)}
    source.onended=()=>{source.disconnect();if(version===this.version&&!this.paused&&!this.stopped){this.stopped=true;this.dispose();this.options.onended?.()}};
    source.start(0,this.offset%this.buffer.duration);this.options.onstart?.(this.key,this.buffer.duration-this.offset);
  }
  pause(){if(this.stopped||this.paused||this.options.allowPaused)return;this.offset+=(this.owner.context.currentTime-this.started)*(this.options.rate||1);if(this.options.loop)this.offset%=this.buffer.duration;this.offset=Math.min(this.offset,this.buffer.duration-.001);this.paused=true;this.version++;this.source?.stop();}
  resume(){if(this.paused&&!this.stopped)this.start()}
  stop(fade=0){if(this.stopped)return;this.stopped=true;this.version++;if(this.source){if(fade){const now=this.owner.context.currentTime;this.gain.gain.cancelScheduledValues(now);this.gain.gain.setTargetAtTime(0,now,fade/4);this.source.stop(now+fade);setTimeout(()=>this.dispose(),fade*1000+50)}else{this.source.stop();this.dispose()}}else this.dispose();}
  dispose(){this.owner.handles.delete(this);this.gain.disconnect();this.pan.disconnect();}
}
class BerinscapeMusic {
  constructor(){
    this.context=new (window.AudioContext||window.webkitAudioContext)();this.handles=new Set();this.cache=new Map();this.pendingMusic=new Set();this.queue=null;this.voiceGeneration=0;this.crowd=null;this.paused=false;this.muted=false;this.settings={master:.3,music:.75,ambience:.4,interface:.55,voices:.8,enabledVoices:true,dialogue:false};this.stage='menu';this.beds=[];this.bedGeneration=0;this.ambientMode=false;this.nextDetail=0;this.lastEffect=new Map();
    this.master=this.context.createGain();this.master.gain.value=0;
    this.limiter=this.context.createDynamicsCompressor();Object.assign(this.limiter.threshold,{value:-8});this.limiter.knee.value=10;this.limiter.ratio.value=12;this.limiter.attack.value=.003;this.limiter.release.value=.15;this.master.connect(this.limiter).connect(this.context.destination);
    this.buses=Object.fromEntries(['music','ambience','interface','voices'].map(name=>{const gain=this.context.createGain();gain.gain.value=0;gain.connect(this.master);return[name,gain]}));this.effects=this.buses.interface;
    const reverb=this.context.createConvolver(),impulse=this.context.createBuffer(2,Math.floor(this.context.sampleRate*.75),this.context.sampleRate);let seed=31;
    for(let channel=0;channel<2;channel++){const samples=impulse.getChannelData(channel);for(let i=0;i<samples.length;i++){seed=seed*16807%2147483647;samples[i]=(seed/2147483647*2-1)*Math.pow(1-i/samples.length,3)*.15}}
    reverb.buffer=impulse;this.room=this.context.createGain();this.room.gain.value=.12;this.buses.voices.connect(reverb).connect(this.room).connect(this.master);
    this.music={};this.musicNames={menu:'Fate and Fortune',forest:'The Long Dark',reveal:'Juggernaut · Chegada',hall:'Juggernaut · Salão',throne:'Juggernaut · Trono'};
    const paths={menu:'assets/audio/music/fate-and-fortune-scott-buckley.mp3',forest:'assets/audio/music/the-long-dark-scott-buckley.mp3',reveal:'assets/audio/music/juggernaut-reveal.mp3',hall:'assets/audio/music/juggernaut-hall.mp3',throne:'assets/audio/music/juggernaut-throne.mp3'};
    for(const [name,path] of Object.entries(paths)){
      const audio=new Audio(path);audio.loop=true;audio.preload='none';audio.volume=0;
      const gain=this.context.createGain();gain.gain.value=0;
      if(location.protocol!=='file:'){const source=this.context.createMediaElementSource(audio);source.connect(gain).connect(this.buses.music);audio.volume=1;}
      audio.addEventListener('error',()=>this.error('Música '+name));this.music[name]={audio,gain,mix:0};
    }
    this.fadeTimer=setInterval(()=>this.fade(),50);this.prepare(['ui-hover','ui-click','ui-begin']);
  }
  error(name){window.dispatchEvent(new CustomEvent('berin-audio-error',{detail:name}))}
  async load(key){
    if(this.cache.has(key))return this.cache.get(key);
    const promise=(async()=>{
      let data;
      if(location.protocol==='file:'){
        if(!this.bankPromise)this.bankPromise=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='assets/audio/premium/audio-bank.js';script.onload=()=>{script.remove();resolve()};script.onerror=()=>{script.remove();this.bankPromise=null;reject(new Error('Banco local de áudio indisponível'))};document.head.append(script)});
        await this.bankPromise;const encoded=window.BERIN_PREMIUM_AUDIO?.[key];if(!encoded)throw new Error('Som local ausente: '+key);data=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0)).buffer;delete window.BERIN_PREMIUM_AUDIO[key];
      }else{const response=await fetch(window.BERIN_AUDIO_MANIFEST[key].path);if(!response.ok)throw new Error('Som indisponível: '+key);data=await response.arrayBuffer();}
      return this.context.decodeAudioData(data);
    })().catch(error=>{this.cache.delete(key);this.error(key);throw error});this.cache.set(key,promise);return promise;
  }
  prepare(keys){return Promise.all(keys.map(key=>this.load(key).catch(()=>null)))}
  prepareDialogue(){return this.prepare(['crowd','reception-order','advisor-warning','berin-answer-a','berin-answer-b','advisor-reply','berin-laugh','minion-laugh','door-open','gate','chair','transition']);}
  async clip(key,group='interface',options={}){const buffer=await this.load(key).catch(()=>null);if(!buffer)return null;return new RecordedClip(this,key,buffer,this.buses[group],options)}
  effect(kind){
    const key={hover:'ui-hover',click:'ui-click',begin:'ui-begin',transition:'transition',arrival:'gate',chair:'chair','tavern-door':'door-open','gate-open':'gate',coin:'coin','extra-life':'extra-life'}[kind];if(!key)return;
    const now=this.context.currentTime,min=kind==='hover'?.12:kind==='coin'?.035:.04;if(now-(this.lastEffect.get(kind)??-10)<min)return;this.lastEffect.set(kind,now);
    const group=['chair','tavern-door','gate-open','arrival'].includes(kind)?'ambience':'interface';this.clip(key,group,{gain:kind==='begin'?1:kind==='hover'?.4:.85,allowPaused:group==='interface'});
  }
  footstep(surface,running=false){
    const now=this.context.currentTime;if(this.paused||now-(this.lastStep??-10)<.17)return;this.lastStep=now;const material=surface==='stone'?'concrete':surface==='wood'?'wood':'grass',index=(this.stepIndex=(this.stepIndex||0)+1)%2;
    this.clip('step-'+material+'-'+index,'ambience',{gain:running?.8:.55,rate:.96+Math.random()*.08,pan:index?.1:-.1});
  }
  stopVoice(){this.voiceGeneration++;this.queue=null;this.voiceHandle?.stop(.06);this.voiceHandle=null;this.stopCrowd();}
  say(keys){this.stopVoice();const generation=this.voiceGeneration;this.queue={keys,index:0,generation};this.nextVoice();}
  async nextVoice(){
    const queue=this.queue;if(!queue||queue.generation!==this.voiceGeneration)return;if(queue.index>=queue.keys.length){this.queue=null;this.voiceHandle=null;return;}
    const key=queue.keys[queue.index],buffer=await this.load(key).catch(()=>null);if(this.queue!==queue||queue.generation!==this.voiceGeneration)return;
    if(!buffer){queue.index++;this.nextVoice();return}
    this.voiceHandle=new RecordedClip(this,key,buffer,this.buses.voices,{gain:.95,onstart:(name,duration)=>this.onVoiceCue?.(name,duration),onended:()=>{if(this.queue===queue){queue.index++;this.nextVoice()}}});
  }
  async startCrowd(){this.stopVoice();const ticket=this.voiceGeneration,buffer=await this.load('crowd').catch(()=>null);if(buffer&&ticket===this.voiceGeneration)this.crowd=new RecordedClip(this,'crowd',buffer,this.buses.voices,{loop:true,gain:.85,fade:.15});}
  stopCrowd(){this.crowd?.stop(.18);this.crowd=null;}
  setPaused(paused){if(paused===this.paused)return;this.paused=paused;for(const handle of this.handles)paused?handle.pause():handle.resume();if(paused)for(const track of Object.values(this.music))track.audio.pause();}
  async ambience(active){
    if(active===this.ambientMode)return;this.ambientMode=active;const ticket=++this.bedGeneration;for(const bed of this.beds)bed.stop(.7);this.beds=[];
    if(!active)return;this.nextDetail=this.context.currentTime+14;
    for(const [key,gain,pan] of [['forest-night',.55,-.2],['forest-wind',.35,.3]]){const buffer=await this.load(key).catch(()=>null);if(buffer&&ticket===this.bedGeneration)this.beds.push(new RecordedClip(this,key,buffer,this.buses.ambience,{loop:true,gain,pan,fade:1.2}));}
    this.nextDetail=this.context.currentTime+14;
  }
  update(state){
    const previous=this.stage,previousTrack=this.trackKey();this.settings={...this.settings,...state};this.stage=state.stage||this.stage;this.setPaused(!!state.paused);
    const selected=this.trackKey();
    // The menu ends at the scene cut; only in-game scores crossfade together.
    if(previousTrack==='menu'&&selected!=='menu')this.stopTrack('menu');
    else if(previousTrack!=='menu'&&selected==='menu')for(const key of Object.keys(this.music))if(key!=='menu')this.stopTrack(key);
    const now=this.context.currentTime,s=this.settings,level=value=>Math.max(0,Math.min(1,Number(value)||0));
    this.master.gain.setTargetAtTime(level(s.master)*.9,now,.05);
    for(const name of ['music','ambience','interface','voices']){let gain=level(s[name]);if(name==='voices'&&!s.enabledVoices)gain=0;if(this.paused&&name!=='interface')gain=0;if(name==='music'&&this.muted)gain=0;this.buses[name].gain.setTargetAtTime(gain,now,.06)}
    this.room.gain.setTargetAtTime(this.paused?0:['hall','throne','gate'].includes(this.stage)?.14:.045,now,.15);
    const forest=['forest','reveal','gate'].includes(this.stage);this.ambience(forest);
    if(forest&&!this.paused&&now>this.nextDetail){this.nextDetail=now+17+Math.random()*14;this.clip('twig','ambience',{gain:.15,pan:(Math.random()-.5)*1.5,rate:.8+Math.random()*.35})}
    if(previous!==this.stage)window.dispatchEvent(new CustomEvent('berin-music-scene',{detail:{stage:this.stage,name:this.musicNames[this.trackKey()]}}));
    const indicator=document.getElementById('music-status');if(indicator){indicator.dataset.stage=this.stage;indicator.dataset.paused=String(this.paused);indicator.dataset.voice=this.voiceHandle?.key||(this.crowd?'crowd':'');indicator.dataset.audioState=this.context.state;const handle=this.voiceHandle||this.crowd;indicator.dataset.voiceTime=handle?String(handle.offset+(handle.paused?0:this.context.currentTime-handle.started)*(handle.options.rate||1)):'';indicator.dataset.musicTime=String(this.music[this.trackKey()]?.audio.currentTime||0);}
  }
  trackKey(){return {tavern:'menu',gate:'reveal'}[this.stage]||this.stage;}
  stopTrack(key){
    const track=this.music[key];if(!track)return;track.mix=0;
    track.gain.gain.cancelScheduledValues(this.context.currentTime);track.gain.gain.setValueAtTime(0,this.context.currentTime);
    track.audio.pause();track.audio.currentTime=0;if(location.protocol==='file:')track.audio.volume=0;
  }
  fade(){
    const selected=this.trackKey(),s=this.settings,duck=s.dialogue?.28:1;
    for(const [key,track] of Object.entries(this.music)){
      const target=key===selected&&!this.paused&&!this.muted&&s.master>0&&s.music>0?duck:0;track.mix+=(target-track.mix)*.1;if(Math.abs(track.mix-target)<.001)track.mix=target;
      if(location.protocol==='file:')track.audio.volume=Math.min(1,track.mix*s.master*s.music*.65);else track.gain.gain.setTargetAtTime(track.mix,this.context.currentTime,.04);
      if(target>0&&track.audio.paused&&!this.pendingMusic.has(key)){this.pendingMusic.add(key);track.audio.play().then(()=>{if(this.trackKey()!==key||this.paused||this.muted)track.audio.pause()}).catch(()=>{if(this.trackKey()===key&&!this.paused&&!this.muted)this.error('Música '+key)}).finally(()=>this.pendingMusic.delete(key))}
      if(track.mix===0&&!track.audio.paused)track.audio.pause();
    }
  }
}
