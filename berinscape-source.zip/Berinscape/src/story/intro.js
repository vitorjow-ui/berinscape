// The throne dialogue preserves the author's supplied wording.
const BerinIntro = {
  reception: [
    {speaker:'Berinbinha (Servo de Berin)',text:'Berin! Berin! Berin! Berin!',shot:'crowd'},
    {speaker:'Berin',audio:'reception-order',text:'Abram caminho! Seu rei está de volta!',shot:'berin',provisional:true}
  ],
  throne: [
    {speaker:'Berinbinha (Servo de Berin)',shot:'advisor',audio:'advisor-warning',text:'Mestre Berin, soberano! Permissão para falar. Nós, estamos preocupados mestre... Escutamos rumores de um vilarejo ao norte onde guerreiros estão preparando um exército para invadir o castelo e se vingar do senhor mestre... Acho prudente que investiguemos isso! Se for um perigo real, precisamos estar preparados!'},
    {speaker:'Berin',shot:'king',audio:'berin-answer',text:'Meu fiel Berinbinha, você não entende a força que temos... Todos temem o nome Berin! Aquele que se rebelar, sofrerá a irá !! hahaha Eu não me importo! Que venham o campeão deles!! Estarei esperando!! Sugiro que vocês estejam prontos para recebe-lo!'},
    {speaker:'Berinbinha (Servo de Berin)',shot:'advisor',audio:'advisor-reply',text:'Sim mestre, qualquer tolo que tente chegar até aqui... Tem que estar preparado para morrer! hahaha'}
  ]
};
