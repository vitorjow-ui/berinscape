// Binary streaming over HTTP; lazy, chunked fallback preserves direct file opening.
class GameAssetLoader {
  constructor(manifest){this.manifest=manifest;this.cache=new Map();this.progress=new Map();this.active=[];this.listener=()=>{};}
  watch(names,listener){this.active=names;this.listener=listener;this.notify();}
  notify(label){const total=this.active.reduce((n,k)=>n+this.manifest[k].bytes,0);const loaded=this.active.reduce((n,k)=>n+Math.min(this.manifest[k].bytes,this.progress.get(k)||0),0);this.listener({loaded,total,percent:total?Math.floor(loaded/total*100):0,label});}
  load(name,loader){if(this.cache.has(name))return this.cache.get(name);const promise=this.read(name).then(buffer=>loader.parseAsync(buffer,'')).catch(error=>{this.cache.delete(name);this.progress.delete(name);throw new Error(this.manifest[name].label+': '+error.message)});this.cache.set(name,promise);return promise;}
  async read(name){
    const asset=this.manifest[name];this.notify(asset.label);
    if(location.protocol==='file:'){
      await new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=asset.fallback;script.onload=()=>{script.remove();resolve()};script.onerror=()=>{script.remove();reject(new Error('Não foi possível abrir o arquivo local.'))};document.head.append(script)});
      let encoded=window[asset.global];delete window[asset.global];
      if(typeof encoded!=='string')throw new Error('Arquivo local incompleto.');
      const padding=encoded.endsWith('==')?2:encoded.endsWith('=')?1:0;
      const bytes=new Uint8Array(encoded.length/4*3-padding);let offset=0;
      for(let i=0;i<encoded.length;i+=262144){const decoded=atob(encoded.slice(i,i+262144));for(let j=0;j<decoded.length;j++)bytes[offset++]=decoded.charCodeAt(j);this.progress.set(name,offset);this.notify(asset.label);await new Promise(resolve=>setTimeout(resolve,0));}
      encoded=null;return bytes.buffer;
    }
    const controller=new AbortController();let timeout;
    const renew=()=>{clearTimeout(timeout);timeout=setTimeout(()=>controller.abort(),30000)};renew();
    try{
      const response=await fetch(asset.path,{signal:controller.signal});if(!response.ok)throw new Error('Arquivo indisponível ('+response.status+').');
      const size=Number(response.headers.get('x-asset-bytes')||response.headers.get('content-length'))||asset.bytes;
      if(size!==asset.bytes)throw new Error('O tamanho do arquivo não corresponde à versão do jogo.');
      const data=new Uint8Array(size);let offset=0;
      if(response.body){const reader=response.body.getReader();while(true){const {done,value}=await reader.read();if(done)break;renew();if(offset+value.length>size)throw new Error('Arquivo maior que o esperado.');data.set(value,offset);offset+=value.length;this.progress.set(name,offset);this.notify(asset.label)}}
      else{const bytes=new Uint8Array(await response.arrayBuffer());data.set(bytes);offset=bytes.length;}
      if(offset!==asset.bytes||String.fromCharCode(...data.subarray(0,4))!=='glTF')throw new Error('Modelo incompleto. Tente novamente.');
      this.progress.set(name,offset);this.notify(asset.label);return data.buffer;
    }catch(error){if(error.name==='AbortError')throw new Error('A transferência parou por 30 segundos. Confira a conexão e tente novamente.');throw error}finally{clearTimeout(timeout)}
  }
}
window.BerinAssets=new GameAssetLoader(window.BERIN_ASSET_MANIFEST);
