// Progression is independent from rendering, so coins cannot be counted twice.
class JourneyProgress {
  constructor() { this.reset(); }
  reset() { this.coins=0;this.lives=3;this.collected=new Set(); }
  restore(ids){this.reset();for(const id of ids)this.collect(id);}
  collect(id) {
    if(this.collected.has(id))return {added:false,extraLives:0};
    this.collected.add(id);
    const previous=Math.floor(this.coins/50);
    this.coins++;
    const extraLives=Math.floor(this.coins/50)-previous;
    this.lives+=extraLives;
    return {added:true,extraLives};
  }
}

class IntroSave {
  constructor(storage){this.storage=storage;this.key='berinscape-intro-v2';this.available=true;}
  validate(save){
    if(!save||save.version!==2||!Array.isArray(save.coins)||save.coins.length>120)return null;
    if(new Set(save.coins).size!==save.coins.length||save.coins.some(id=>!Number.isInteger(id)||id<0||id>=120))return null;
    const w=save.world,s=save.story;
    if(!w||!['forest','hall'].includes(w.area)||!Number.isFinite(w.x)||Math.abs(w.x)>2.3||!Number.isFinite(w.z)||w.z<0||w.z>(w.area==='hall'?30.2:107.2)||!Number.isFinite(w.yaw)||!Number.isFinite(w.zoom)||w.zoom<5.5||w.zoom>13)return null;
    if(w.destination&&(!Number.isFinite(w.destination.x)||Math.abs(w.destination.x)>2.3||!Number.isFinite(w.destination.z)||w.destination.z<0||w.destination.z>(w.area==='hall'?30.2:107.2)))return null;
    if(!s||!['forest','hall','dialogue'].includes(s.state))return null;
    if(s.state==='forest'&&w.area!=='forest'||s.state==='hall'&&w.area!=='hall')return null;
    if(s.state==='dialogue'&&(w.area!=='hall'||!['reception','throne'].includes(s.kind)||!Number.isInteger(s.line)||s.line<0||s.line>=(s.kind==='reception'?2:3)))return null;
    return save;
  }
  read(){try{const value=this.storage.getItem(this.key);if(!value)return null;const save=this.validate(JSON.parse(value));if(!save)this.clear();return save}catch{this.available=false;return null}}
  write(save){if(!this.validate(save))return false;try{this.storage.setItem(this.key,JSON.stringify(save));this.available=true;return true}catch{this.available=false;return false}}
  clear(){try{this.storage.removeItem(this.key)}catch{this.available=false}}
}
