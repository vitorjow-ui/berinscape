// Keep a tap as a destination until the finger moves deliberately.
(() => {
  const input = window.berinTouch = { dragging: false, running: false, x: 0, z: 0 };
  const stick = document.createElement('div');
  stick.id = 'travel-stick';
  stick.setAttribute('aria-hidden', 'true');
  stick.append(document.createElement('i'));
  document.body.append(stick);
  let contact = null;
  function release() {
    stick.style.display = 'none';
    contact = null;
    input.dragging = false;
    input.x = input.z = 0;
  }
  canvas.addEventListener('pointerdown', event => {
    if (event.pointerType !== 'touch' || contact || !canTravel()) return;
    contact = { id: event.pointerId, x: event.clientX, y: event.clientY };
    stick.style.left = event.clientX + 'px';
    stick.style.top = event.clientY + 'px';
    canvas.setPointerCapture(event.pointerId);
  });
  canvas.addEventListener('pointermove', event => {
    if (contact?.id !== event.pointerId) return;
    if (!canTravel()) return release();
    const dx = event.clientX - contact.x;
    const dy = contact.y - event.clientY;
    const distance = Math.hypot(dx, dy);
    if (distance > 10) input.dragging = true;
    if (input.dragging) {
      stick.style.display = 'grid';
      const factor = Math.min(1, 22 / (distance || 1));
      stick.firstElementChild.style.transform = 'translate(' + dx * factor + 'px,' + -dy * factor + 'px)';
    }
    // The follow camera looks along positive route Z, so screen right is negative route X.
    input.x = distance > 6 ? -dx / distance : 0;
    input.z = distance > 6 ? dy / distance : 0;
  });
  canvas.addEventListener('pointerup', event => {
    if (contact?.id !== event.pointerId) return;
    if (canTravel() && !input.dragging) window.berinWorld.click(event.clientX, event.clientY);
    release();
  });
  for (const type of ['pointercancel', 'lostpointercapture']) {
    canvas.addEventListener(type, event => { if (contact?.id === event.pointerId) release(); });
  }
  addEventListener('blur', release);
  document.addEventListener('visibilitychange', release);
  new MutationObserver(() => { if (!canTravel()) release(); }).observe(document.body, { attributes: true, attributeFilter: ['class'] });
  $('run-mode').onclick = () => {
    if (!canTravel()) return;
    input.running = !input.running;
    $('run-mode').setAttribute('aria-pressed', String(input.running));
  };
  $('zoom-in').onclick = () => { if (canTravel()) window.berinWorld.changeZoom(-1); };
  $('zoom-out').onclick = () => { if (canTravel()) window.berinWorld.changeZoom(1); };
})();
