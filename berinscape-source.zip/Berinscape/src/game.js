const $=id=>document.getElementById(id),canvas=$('world');
let playing=false,paused=false,arrived=false,busy=false,starting=false,last=0,soundtrack;
let preferences;try{preferences=window.localStorage}catch{preferences={getItem:()=>null,setItem:()=>{throw new Error('Armazenamento indisponível')},removeItem:()=>{}}}
const preferenceRead=key=>{try{return preferences.getItem(key)}catch{return null}},preferenceWrite=(key,value)=>{try{preferences.setItem(key,value)}catch{}};
const keys=new Set(),journey=new JourneyProgress(),saveStore=new IntroSave(preferences);
let cinemaScene=null,cinemaSurface=null,skipRequested=false;
let introState='forest',sceneLines=[],lineIndex=0,sceneKind=null,rewardTime=0,transitionTime=0,autosaveTime=0,noticeTime=0,saveToast=0,pendingMode='new',saved=saveStore.read();
window.berinPaused=false;
const effectsVolume=$('effects-volume');effectsVolume.value=preferenceRead('berinscape-effects')??55;
$('volume').value=preferenceRead('berinscape-volume')??30;
$('voices').checked=preferenceRead('berinscape-voices')!=='off';
function sound(){
 if(!soundtrack){soundtrack=new BerinscapeMusic();soundtrack.muted=preferenceRead('berinscape-music-muted')==='yes';soundtrack.onVoiceCue=(key,duration)=>{if(key.includes('laugh'))window.berinWorld?.laugh(duration)};}
 if(soundtrack.context.state==='suspended'&&!document.hidden)soundtrack.context.resume().catch(()=>{});
 const area=window.berinWorld?.area||'forest',atThrone=sceneKind==='throne'&&['dialogue','outro','complete'].includes(introState);
 const stage=cinemaScene||(playing?(area==='hall'?(atThrone?'throne':'hall'):(window.berinWorld.snapshot().z>82?'reveal':'forest')):'menu');
 soundtrack.update({master:+$('volume').value/100,music:+$('music-volume').value/100,ambience:+$('ambience-volume').value/100,interface:+effectsVolume.value/100,voices:+$('voice-volume').value/100,enabledVoices:$('voices').checked,dialogue:introState==='dialogue',paused:paused||document.hidden,stage});
 $('music-toggle').textContent=soundtrack.muted?'♫ ATIVAR MÚSICA':'♫ SILENCIAR MÚSICA';$('music-toggle').setAttribute('aria-label',soundtrack.muted?'Ativar música':'Silenciar música');
}
function uiEffect(kind){sound();soundtrack.effect(kind)}
window.berinFootstep=running=>{if((playing&&!paused)||cinemaSurface)soundtrack?.footstep(cinemaSurface||(window.berinWorld?.area==='hall'?'stone':'grass'),running)};
function updateCounters(){$('coin-count').textContent=journey.coins;$('life-count').textContent=journey.lives;$('coin-goal').textContent='Próxima vida · '+journey.coins%50+' / 50';$('coin-progress').style.width=journey.coins%50*2+'%'}
function refreshContinue(){saved=saveStore.read();$('continue-game').classList.toggle('hidden',!saved);$('play').textContent=saved?'NOVA JORNADA':'JOGAR';$('save-summary').textContent=saved?(saved.world.area==='hall'?'Salão das Riquezas':'Floresta Negra')+' · '+saved.coins.length+' moedas · progresso salvo':'';}
function persist(show=false){
 if(!playing||!window.berinWorld||!['forest','hall','dialogue'].includes(introState))return;
 const state={version:2,at:Date.now(),world:window.berinWorld.snapshot(),coins:[...journey.collected],story:{state:introState,kind:sceneKind,line:lineIndex}};
 const ok=saveStore.write(state);if(ok)saved=state;
 if(show||!ok){$('save-status').textContent=ok?'◆ PROGRESSO SALVO':'Não foi possível salvar neste navegador';$('save-status').classList.add('visible');saveToast=ok?2.5:5;}return ok;
}
window.berinCollectCoin=id=>{const result=journey.collect(id);if(!result.added)return;updateCounters();uiEffect(result.extraLives?'extra-life':'coin');if(result.extraLives){$('reward').textContent='+1 VIDA · 50 MOEDAS';$('reward').classList.add('visible');rewardTime=3;$('life-count').closest('.lives')?.animate?.([{filter:'brightness(1)'},{filter:'brightness(2)'},{filter:'brightness(1)'}],{duration:700})}};
window.berinNotice=text=>{$('message').textContent=text;noticeTime=1.2;};
function speak(line){
 soundtrack?.stopVoice();if(!$('voices').checked||paused)return;
 if(line.shot==='crowd'){soundtrack.startCrowd();return}
 const clips=line.audio==='berin-answer'?['berin-answer-a','berin-laugh','berin-answer-b']:line.audio==='advisor-reply'?['advisor-reply','minion-laugh']:[line.audio];
 soundtrack.say(clips);
}
function showLine(){const line=sceneLines[lineIndex];$('speaker').textContent=line.speaker;$('speech-text').textContent=line.text;$('speech-hint').textContent=(lineIndex+1)+' / '+sceneLines.length+' · Espaço / Enter';$('speech-text').scrollTop=0;window.berinWorld.setShot(line.shot);keys.clear();speak(line);persist();}
function beginDialogue(kind,index=0){sceneKind=kind;sceneLines=BerinIntro[kind];lineIndex=index;introState='dialogue';document.body.classList.add('story-cut');$('dialogue').classList.remove('hidden');$('next-dialogue').focus({preventScroll:true});showLine();sound();}
function advanceDialogue(){if(introState!=='dialogue'||paused||busy)return;soundtrack?.stopVoice();if(++lineIndex<sceneLines.length){showLine();return}$('dialogue').classList.add('hidden');document.body.classList.remove('story-cut');keys.clear();window.berinWorld.setShot(null);if(sceneKind==='reception'){introState='hall';sceneKind=null;lineIndex=0;persist();canvas.focus()}else{introState='outro';transitionTime=0;$('fade').style.opacity=1;saveStore.clear();saved=null}sound();}
$('next-dialogue').onclick=advanceDialogue;
function resetPresentation(){cinemaScene=null;cinemaSurface=null;skipRequested=false;$('skip-cinematic').classList.add('hidden');$('help-panel').classList.add('hidden');$('help-toggle').setAttribute('aria-expanded','false');soundtrack?.stopVoice();rewardTime=0;transitionTime=0;autosaveTime=0;noticeTime=0;saveToast=0;$('save-status').classList.remove('visible');$('reward').classList.remove('visible');$('chapter-title').classList.remove('visible');$('dialogue').classList.add('hidden');document.body.classList.remove('story-cut');$('message').textContent='';}
function loadProgress(info){if(!busy)return;$('load-stage').textContent=info.label||'Preparando a cena…';$('load-progress').value=info.percent||0;$('load-size').textContent=info.total?((info.loaded||0)/1000000).toFixed(1)+' / '+(info.total/1000000).toFixed(1)+' MB · '+(info.percent||0)+'% dos arquivos':'Preparando o ambiente';}
function openLoading(title){busy=true;$('load-title').textContent=title;$('load-stage').textContent='Preparando os arquivos…';$('load-progress').value=0;$('load-size').textContent='';$('load-error').classList.add('hidden');$('load-recovery').classList.add('hidden');if(!$('loading').open)$('loading').showModal();}
function closeLoading(){busy=false;if($('loading').open)$('loading').close();}
function failedLoading(error){busy=false;console.error(error);$('load-stage').textContent=saveStore.read()?'Seu progresso permanece guardado.':'Não foi possível preparar a cena.';$('load-error').textContent=error.message||'Não foi possível abrir a cena. Confira sua conexão e tente novamente.';$('load-error').classList.remove('hidden');$('load-recovery').classList.remove('hidden');$('load-retry').focus();}
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function playOriginalTavern(){
 const animation=$('menu-animation');
 await new Promise((resolve,reject)=>{
  const finish=error=>{clearTimeout(timer);animation.onload=animation.onerror=null;error?reject(error):resolve()};
  const timer=setTimeout(()=>finish(new Error('Não foi possível abrir a cena da taverna. Tente novamente.')),15000);
  animation.onload=()=>finish();animation.onerror=()=>finish(new Error('Não foi possível abrir a cena da taverna. Tente novamente.'));
  animation.src='assets/ui/menu/berin-tavern.gif?play='+Date.now();
 });
 document.body.classList.add('entering','story-cut');$('menu').classList.add('starting');
 skipRequested=false;$('skip-cinematic').classList.remove('hidden');$('skip-cinematic').textContent='PULAR APRESENTAÇÃO';cinemaScene='tavern';sound();soundtrack.effect('transition');$('fade').style.opacity=0;
 await new Promise(resolve=>{let previous=performance.now(),elapsed=0,laughed=false;function frame(now){if(!document.hidden)elapsed+=Math.min((now-previous)/1000,1.25);previous=now;if(!skipRequested&&!laughed&&elapsed>=.3){laughed=true;soundtrack.say(['berin-laugh'])}if(skipRequested||elapsed>=3.6){soundtrack.stopVoice();$('fade').style.opacity=1;cinemaScene='forest';sound();resolve()}else requestAnimationFrame(frame)}requestAnimationFrame(frame)});
 $('skip-cinematic').classList.add('hidden');
}
async function start(mode){
 if(busy||starting)return;pendingMode=mode;const checkpoint=mode==='continue'?saveStore.read():null;if(mode==='continue'&&!checkpoint){refreshContinue();return;}
 uiEffect(checkpoint?'click':'begin');starting=true;openLoading(checkpoint?'Retomando sua jornada':'Preparando sua jornada');
 try{
  const area=checkpoint?.world.area||'forest';
  if(!window.berinWorld)await window.buildBerinWorld(area,loadProgress);
  else await window.berinWorld.prepare(area,loadProgress);
  if(checkpoint?.world.area==='forest'&&checkpoint.world.z>35)await window.berinWorld.prepare('forest',loadProgress,true);
  loadProgress({label:'Preparando vozes e efeitos…',percent:100});await soundtrack.prepareDialogue();closeLoading();
  if(!checkpoint){
   await playOriginalTavern();
  }
  $('fade').style.opacity=1;await wait(checkpoint?180:650);
  resetPresentation();journey.restore(checkpoint?.coins||[]);window.berinWorld.reset([...journey.collected]);window.berinWorld.setArea(area);
  if(checkpoint)window.berinWorld.restore(checkpoint.world);
  else{saveStore.clear();window.berinWorld.spawnFromTavern();}
  introState=area;sceneKind=null;lineIndex=0;arrived=false;paused=false;window.berinPaused=false;playing=true;keys.clear();
  $('menu').classList.add('hidden');$('menu').classList.remove('starting');$('menu-animation').removeAttribute('src');document.body.classList.remove('entering','paused');$('hud').style.display='block';
  updateCounters();if(checkpoint?.story.state==='dialogue')beginDialogue(checkpoint.story.kind,checkpoint.story.line);
  window.berinWorld.update(.016,false,keys);$('fade').style.opacity=0;sound();persist(true);
 }catch(error){failedLoading(error)}finally{starting=false;}
}
async function enterCastle(){
 pendingMode='entrance';cinemaScene='gate';openLoading('Além dos portões');
 try{
  await window.berinWorld.prepare('forest',loadProgress,true);await window.berinWorld.prepare('hall',loadProgress);await soundtrack.prepareDialogue();closeLoading();starting=true;skipRequested=false;cinemaSurface='stone';document.body.classList.add('story-cut');$('skip-cinematic').classList.remove('hidden');$('skip-cinematic').textContent='PULAR ENTRADA';$('fade').style.opacity=0;sound();
  await window.berinWorld.playGateEntry(cue=>{if(cue==='skip'){skipRequested=true;$('fade').style.opacity=1;return}if(cue==='gate-open')soundtrack.effect('gate-open');if(cue==='inside-castle')$('fade').style.opacity=1},()=>skipRequested);
  $('fade').style.opacity=1;await wait(300);window.berinWorld.setArea('hall');cinemaScene=null;cinemaSurface=null;starting=false;$('skip-cinematic').classList.add('hidden');beginDialogue('reception');window.berinWorld.update(.016,false,keys);$('fade').style.opacity=0;persist(true);
 }catch(error){starting=false;$('skip-cinematic').classList.add('hidden');failedLoading(error)}
}
function pauseGame(){if(!playing||paused||busy||starting||!['forest','hall','dialogue'].includes(introState))return;persist();paused=true;window.berinPaused=true;keys.clear();document.body.classList.add('paused');$('pause-summary').textContent=(window.berinWorld.area==='hall'?'Salão das Riquezas':'Floresta Negra')+' · '+journey.coins+' moedas · '+journey.lives+' vidas';$('pause-menu').showModal();sound();$('resume-game').focus();}
function resumeGame(){if(!paused)return;if($('options').open)$('options').close();if($('pause-menu').open)$('pause-menu').close();paused=false;window.berinPaused=false;keys.clear();document.body.classList.remove('paused');sound();if(introState==='dialogue'){if($('voices').checked&&!soundtrack.voiceHandle&&!soundtrack.crowd&&!soundtrack.queue)speak(sceneLines[lineIndex]);$('next-dialogue').focus()}else canvas.focus();}
function menu(){
 if(playing)persist();for(const id of ['pause-menu','options','ending','loading','new-game-confirm'])if($(id).open)$(id).close();
 resetPresentation();playing=false;paused=false;window.berinPaused=false;arrived=false;busy=false;keys.clear();document.body.classList.remove('entering','paused');$('fade').style.opacity=0;$('menu').classList.remove('hidden','starting');$('menu-animation').removeAttribute('src');$('hud').style.display='none';refreshContinue();if(soundtrack)sound();$('continue-game').classList.contains('hidden')?$('play').focus():$('continue-game').focus();
}
function tick(dt){
 if(!playing||paused||busy||starting)return;
 if(rewardTime>0&&(rewardTime-=dt)<=0)$('reward').classList.remove('visible');
 if(noticeTime>0&&(noticeTime-=dt)<=0)$('message').textContent='';
 if(saveToast>0&&(saveToast-=dt)<=0)$('save-status').classList.remove('visible');
 if((autosaveTime+=dt)>=2){autosaveTime=0;persist();}
 if(introState==='forest'&&window.berinWorld.atGate()){persist();introState='entrance';keys.clear();$('fade').style.opacity=1;enterCastle();}
 else if(introState==='hall'&&window.berinWorld.atThrone())beginDialogue('throne');
 else if(introState==='outro'){transitionTime+=dt;if(transitionTime>.9){$('chapter-title').textContent='O REI DOS LADRÕES';$('chapter-title').classList.add('visible')}if(transitionTime>3.5){introState='complete';arrived=true;$('chapter-title').classList.remove('visible');$('ending').showModal();}}
}
$('play').onclick=()=>{if(busy||starting)return;if(saveStore.read())$('new-game-confirm').showModal();else start('new')};
$('continue-game').onclick=()=>start('continue');$('new-confirm').onclick=()=>{$('new-game-confirm').close();start('new')};$('new-cancel').onclick=()=>$('new-game-confirm').close();
$('load-retry').onclick=()=>pendingMode==='entrance'?enterCastle():start(pendingMode);
$('load-cancel').onclick=()=>{starting=false;menu()};$('loading').addEventListener('cancel',e=>{e.preventDefault();if(!busy){starting=false;menu()}});
$('back').onclick=pauseGame;$('resume-game').onclick=resumeGame;$('save-quit').onclick=()=>{if(persist(true)===false){$('pause-summary').textContent='Não foi possível guardar o progresso neste navegador. Sua partida continua disponível aqui; use Continuar.';return}menu()};
$('pause-menu').addEventListener('cancel',e=>{e.preventDefault();resumeGame()});
$('settings').onclick=()=>{$('options').showModal();sound()};$('pause-settings').onclick=()=>{$('pause-menu').close();$('options').showModal()};
function closeOptions(){if($('options').open)$('options').close();if(paused&&!$('pause-menu').open)$('pause-menu').showModal();}
$('close').onclick=closeOptions;$('options').addEventListener('cancel',e=>{e.preventDefault();closeOptions()});
$('return').onclick=menu;$('ending').addEventListener('cancel',e=>{e.preventDefault();menu()});
$('help-toggle').onclick=()=>{const open=$('help-toggle').getAttribute('aria-expanded')!=='true';$('help-toggle').setAttribute('aria-expanded',String(open));$('help-panel').classList.toggle('hidden',!open)};
const mixControls=[['volume','berinscape-volume',30],['music-volume','berinscape-music-volume',75],['ambience-volume','berinscape-ambience-volume',40],['effects-volume','berinscape-effects',55],['voice-volume','berinscape-voice-volume',80]];
for(const [id,key,defaultValue] of mixControls){$(id).value=preferenceRead(key)??defaultValue;const output=document.getElementById(id+'-value');if(output)output.textContent=$(id).value+'%';$(id).oninput=()=>{preferenceWrite(key,$(id).value);if(output)output.textContent=$(id).value+'%';sound()};}
$('voices').onchange=()=>{preferenceWrite('berinscape-voices',$('voices').checked?'on':'off');sound();if(!$('voices').checked)soundtrack.stopVoice();else if(introState==='dialogue'&&!paused)speak(sceneLines[lineIndex])};
$('music-toggle').onclick=()=>{sound();soundtrack.muted=!soundtrack.muted;preferenceWrite('berinscape-music-muted',soundtrack.muted?'yes':'no');sound()};
$('preview-interface').onclick=()=>uiEffect('begin');$('skip-cinematic').onclick=()=>{skipRequested=true;soundtrack?.stopVoice();$('fade').style.opacity=1};
window.addEventListener('berin-audio-error',e=>{$('music-status').textContent='Não foi possível abrir um dos sons. Verifique os arquivos do jogo.'});
window.addEventListener('berin-music-scene',e=>{$('music-status').textContent=e.detail.name+' — Scott Buckley'});
for(let i=0;i<22;i++){const ember=document.createElement('i');ember.style.setProperty('--x',(10+i*4.2)+'%');ember.style.setProperty('--delay',(-i*1.73)+'s');document.querySelector('.embers').append(ember)}
for(let i=0;i<18;i++){
 const fall=document.createElement('i');fall.className='coin-fall';
 fall.style.setProperty('--coin-x',(8+(i*23%85))+'%');
 fall.style.setProperty('--coin-delay',(-i*.47)+'s');
 fall.style.setProperty('--coin-duration',(2.1+(i%5)*.27)+'s');
 fall.style.setProperty('--coin-drift',((i%2?1:-1)*(12+i%4*8))+'px');
 const coin=document.createElement('b');coin.className='gold-coin';coin.textContent='B';fall.append(coin);
 document.querySelector('.coin-rain').append(fall);
}

let lastHover=0;for(const button of document.querySelectorAll('button')){button.addEventListener('pointerenter',()=>{if(soundtrack&&performance.now()-lastHover>100){lastHover=performance.now();uiEffect('hover')}});button.addEventListener('click',()=>{if(!busy&&!['play','continue-game','new-confirm','preview-interface'].includes(button.id))uiEffect('click')});}
addEventListener('pointerdown',()=>sound(),{once:true});addEventListener('keydown',()=>sound(),{once:true});
addEventListener('keydown',e=>{
 if(e.key==='Escape'&&playing&&!$('options').open&&!$('pause-menu').open&&!$('ending').open&&!busy){e.preventDefault();pauseGame();return}
 if(paused||busy||starting||!playing||$('ending').open)return;
 if(introState==='dialogue'&&[' ','Enter'].includes(e.key)){e.preventDefault();if(!e.repeat)advanceDialogue();return}
 if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key))e.preventDefault();keys.add(e.key.toLowerCase());
});
addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));addEventListener('blur',()=>{keys.clear();pauseGame()});document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseGame();if(soundtrack)sound()});addEventListener('pagehide',()=>persist());
canvas.addEventListener('pointerdown',e=>{if(playing&&!paused&&!busy&&!arrived&&['forest','hall'].includes(introState))window.berinWorld?.click(e.clientX,e.clientY)});
canvas.tabIndex=-1;
function frame(now){let remaining=Math.min(Math.max((now-last)/1000,0),1.25);last=now;if(window.berinWorld&&playing&&!paused&&!busy&&!starting){while(remaining>.00001){const step=Math.min(.05,remaining);remaining-=step;window.berinWorld.update(step,!arrived&&['forest','hall'].includes(introState),keys,paused||busy||starting,remaining<=.00001);tick(step);if(remaining<=.00001&&soundtrack)sound();if(paused||busy||starting)break;}}requestAnimationFrame(frame)}requestAnimationFrame(frame);refreshContinue();updateCounters();
