// Procedural fauna and henchmen are temporary models for the playable introduction.
function createForestLife(THREE, scene, cloneRig, navigation, wolfGLTF) {
  const visuals=createVisualModels(THREE),castle=createCastleHall(THREE,visuals);
  const outside=new THREE.Group();
  const material=(color,metalness=0)=>new THREE.MeshStandardMaterial({color,metalness,roughness:metalness?.35:.85});
  const gold=material(0xc89a42,.8),purple=material(0x39204d),skin=material(0xbba083),dark=material(0x15151b),stone=material(0x343343);
  const sphere=new THREE.SphereGeometry(1,12,10),cube=new THREE.BoxGeometry(1,1,1);
  function mesh(parent,geometry,mat,x,y,z,sx=1,sy=1,sz=1){const m=new THREE.Mesh(geometry,mat);m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=m.receiveShadow=true;parent.add(m);return m}
  const at=(distance,lateral=0)=>navigation?navigation.point(distance,lateral):new THREE.Vector3(lateral,0,distance);
  const coins=[],coinGeo=new THREE.CylinderGeometry(.22,.22,.07,16);
  for(let i=0;i<120;i++){const z=5+Math.floor(i/2)*1.65,x=i%2?.65:-.65;const m=mesh(outside,coinGeo,gold,x,.85,z);m.rotation.x=Math.PI/2;const p=at(z,x);m.position.copy(p);m.position.y+=.85;coins.push({mesh:m,id:i,x,z,ground:p.y,taken:false})}
  const animals=[];
  if(!wolfGLTF?.scene)throw new Error('Modelo do lobo não carregado');
  const wolfBounds=new THREE.Box3().setFromObject(wolfGLTF.scene),wolfHeight=wolfBounds.max.y-wolfBounds.min.y;
  if(!Number.isFinite(wolfHeight)||wolfHeight<=0)throw new Error('Escala do lobo inválida');
  for(let i=0;i<7;i++){
    const root=new THREE.Group(),model=cloneRig(wolfGLTF.scene),scale=1/wolfHeight;
    model.scale.multiplyScalar(scale);model.position.y-=wolfBounds.min.y*scale;
    model.traverse(o=>{if(!o.isMesh)return;o.castShadow=o.receiveShadow=true;for(const m of Array.isArray(o.material)?o.material:[o.material])if(m.transparent){m.transparent=false;m.alphaTest=.35;m.depthWrite=true;m.side=THREE.DoubleSide}});
    root.name='ForestWolf_'+(i+1);root.add(model);outside.add(root);
    const mixer=new THREE.AnimationMixer(model),clip=wolfGLTF.animations.find(c=>c.name==='Walk');
    if(!clip)throw new Error('Caminhada do lobo ausente');
    const walk=mixer.clipAction(clip);walk.play();walk.time=i*.13;
    animals.push({root,model,mixer,walk,x:(i%2?1:-1)*(3.1+(i%3)*.45),z:12+i*13,phase:i*2});
  }
  const bats=[];const wingShape=new THREE.Shape();wingShape.moveTo(0,0);wingShape.lineTo(.7,.2);wingShape.lineTo(.5,-.15);wingShape.lineTo(.32,-.05);wingShape.lineTo(.18,-.25);wingShape.lineTo(0,-.1);const wingGeo=new THREE.ShapeGeometry(wingShape),wingMat=new THREE.MeshStandardMaterial({color:0x191824,side:THREE.DoubleSide});
  for(let i=0;i<18;i++){const root=new THREE.Group();outside.add(root);mesh(root,sphere,dark,0,0,0,.1,.15,.08);const wings=[];for(const sign of [-1,1]){const w=new THREE.Mesh(wingGeo,wingMat);w.scale.x=sign;root.add(w);wings.push(w)}bats.push({root,wings,phase:i*1.7,z:8+i*5.5})}
  return {outside,reset(ids=[]){const taken=new Set(ids);coins.forEach(c=>{c.taken=taken.has(c.id);c.mesh.visible=!c.taken});for(const a of animals){a.mixer.stopAllAction();a.walk.reset().play();a.previousTime=null;}},update(t,position,collecting){

        for(const c of coins){if(c.taken)continue;c.mesh.rotation.z=t*2;c.mesh.position.y=c.ground+.85+Math.sin(t*3+c.id)*.12;if(collecting&&Math.hypot(position.x-c.x,position.z-c.z)<.95){c.taken=true;c.mesh.visible=false;window.berinCollectCoin(c.id)}}
        for(const a of animals){
          const phase=t*.35+a.phase,p=at(a.z+Math.cos(phase)*3,a.x+Math.sin(phase)*.6),next=at(a.z+Math.cos(phase+.01)*3,a.x+Math.sin(phase+.01)*.6);
          a.root.position.copy(p);a.root.position.y+=.015;
          a.root.rotation.y=Math.atan2(next.x-p.x,next.z-p.z);
          a.walk.timeScale=THREE.MathUtils.clamp(p.distanceTo(next)*35/.8,.3,1.6);
          a.mixer.update(Math.min(.05,Math.max(0,t-(a.previousTime??t))));a.previousTime=t;
        }
        for(const b of bats){b.root.position.copy(at(b.z+Math.cos(t*.7+b.phase)*2,Math.sin(t*.7+b.phase)*6));b.root.position.y+=3.5+Math.sin(t+b.phase);b.wings.forEach((w,i)=>w.rotation.y=Math.sin(t*15+b.phase)*(i?-.8:.8))}

  }};
}

function createHallLife(THREE, scene, minionGLTF, cloneRig){
  const castle=createCastleHall(THREE,createVisualModels(THREE)),hall=castle.hall;
  scene.add(hall);hall.visible=false;

  const minions=[];
  if(!minionGLTF?.scene)throw new Error('Modelo Berinbinha não carregado');
  const minionBounds=new THREE.Box3().setFromObject(minionGLTF.scene);
  const minionHeight=minionBounds.max.y-minionBounds.min.y;
  if(!Number.isFinite(minionHeight)||minionHeight<=0)throw new Error('Escala de Berinbinha inválida');
  // Keep the approved model intact. Skeleton clones share geometry/textures but animate independently.
  function minion(x,z,advisor=false){
    const root=new THREE.Group(),model=cloneRig(minionGLTF.scene);
    const scale=1.4/minionHeight;model.scale.multiplyScalar(scale);
    model.position.y-=minionBounds.min.y*scale;
    model.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true}});
    root.add(model);const shade=createSoftContact(THREE,1.1,.8,.32);shade.position.y=.025;root.add(shade);root.position.set(x,0,z);root.rotation.y=x<0?Math.PI/2:-Math.PI/2;
    const mixer=new THREE.AnimationMixer(model);
    const actions=Object.fromEntries(minionGLTF.animations.map(c=>[c.name,mixer.clipAction(c)]));
    if(!actions.Cheer||!actions.Idle)throw new Error('Animações da recepção ausentes');
    actions.Idle.play();
    hall.add(root);minions.push({root,model,mixer,actions,cheering:false,advisor,baseY:0,offset:minions.length*.11,rate:.93+(minions.length%4)*.05});return root;
  }
  for(let z=3;z<27;z+=4)for(const x of [-3.2,3.2])minion(x,z);
  const advisor=minion(2,30,true);
  return {hall,advisor,reset(){for(const m of minions){m.mixer.stopAllAction();m.actions.Idle.reset().play();m.cheering=false;m.previousTime=null;m.root.position.y=0;m.model.rotation.z=0;}},update(t,cheering){
for(const m of minions){
        if(m.cheering!==cheering){
          m.cheering=cheering;
          if(cheering){m.actions.Idle.fadeOut(.22);m.actions.Cheer.reset().setEffectiveTimeScale(m.rate).fadeIn(.22).play();m.actions.Cheer.time=m.offset;}
          else{m.actions.Cheer.fadeOut(.32);m.actions.Idle.reset().fadeIn(.32).play();}
        }
        const dt=Math.min(.05,Math.max(0,t-(m.previousTime??t)));m.previousTime=t;m.mixer.update(dt);
        m.root.position.y=m.baseY+(cheering?Math.max(0,Math.sin(t*4+m.root.position.z))*.055:0);
        m.model.rotation.z=cheering?Math.sin(t*3+m.root.position.z)*.025:Math.sin(t*1.3+m.root.position.z)*.008;
      }

      castle.flames.forEach((fire,i)=>{castle.torches[i].intensity=27*fire.update(t)});
  }};
}
