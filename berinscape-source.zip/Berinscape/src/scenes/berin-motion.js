// Secondary motion is additive: restore the authored pose before the next mixer tick.
function createBerinMotion(T,model){
  const names=['Chest','Spine','Head','Cape0L','Cape0C','Cape0R','Cape1L','Cape1C','Cape1R'];
  const bones=Object.fromEntries(names.map(name=>[name,model.getObjectByName(name)]));
  const saved=new Map(),q=new T.Quaternion();let time=0,sway=0,velocity=0,laugh=0,lastBeat=-1,clothSpeed=0,previousSpeed=0,settle=0;
  function add(bone,x,y,z){if(!bone)return;if(!saved.has(bone))saved.set(bone,bone.quaternion.clone());q.setFromEuler(new T.Euler(x,y,z));bone.quaternion.multiply(q)}
  return {
    before(){for(const [bone,rotation] of saved)bone.quaternion.copy(rotation);saved.clear()},
    reset(){this.before();time=0;sway=velocity=laugh=0;lastBeat=-1;clothSpeed=previousSpeed=settle=0},
    laugh(duration){laugh=duration},
    update(dt,speed,turn,action){
      time+=dt;laugh=Math.max(0,laugh-dt);const running=action?.getClip().name==='Run',amount=T.MathUtils.clamp(speed/3.4,0,1);
      clothSpeed=T.MathUtils.damp(clothSpeed,amount,5,dt);settle=Math.min(.13,settle+Math.abs(speed-previousSpeed)*.035)*Math.exp(-3*dt);previousSpeed=speed;
      velocity+=(T.MathUtils.clamp(turn,-1,1)*.18-sway)*35*dt;velocity*=Math.exp(-8*dt);sway=T.MathUtils.clamp(sway+velocity*dt,-.24,.24);
      add(bones.Chest,amount*.075+(laugh?Math.sin(time*13)*.025:0),0,-sway*.1);
      if(laugh)add(bones.Head,-.1+Math.sin(time*9)*.035,0,Math.sin(time*8)*.02);
      for(const name of names.filter(n=>n.startsWith('Cape'))){const side=name.endsWith('L')?-1:name.endsWith('R')?1:0;add(bones[name],-clothSpeed*.1+Math.sin(time*(running?10:6)+side*.6)*(clothSpeed*.035+settle),0,sway*(name.startsWith('Cape1')?1:.65));}
      if(speed>.25&&action){const duration=action.getClip().duration,beat=Math.floor(action.time/duration*2),id=action.getClip().name+':'+beat;if(id!==lastBeat){lastBeat=id;window.berinFootstep?.(running)}}else lastBeat=-1;
    }
  };
}

function createTavernStage(T){
  const v=createVisualModels(T),root=new T.Group(),{m,piece:p,ellipsoid:e}=v;
  root.name='TavernPrologue';const box=(material,x,y,z,w,h,d,parent=root)=>p(parent,v.box,material,x,y,z,w,h,d);
  v.textures.wood.repeat.set(3,3);v.textures.stone.repeat.set(3,2);
  box(m.wood,0,-.16,-4.5,11,.3,11);box(m.stone,0,2.4,-9.5,11,4.8,.4);
  for(const side of [-1,1]){box(m.stone,side*5.3,2.4,-4.5,.4,4.8,10);for(let z=-8;z<0;z+=2.7)box(m.wood,side*5.05,2.3,z,.25,4.6,.25);}
  for(const x of [-3.6,3.6])box(m.stone,x,2.3,0,3.8,4.6,.4);
  box(m.wood,0,4,0,3.5,1.2,.45);box(m.wood,0,4.8,-4.5,11,.22,11);
  for(let z=-8;z<1;z+=2.5)box(m.wood,0,4.55,z,10.7,.3,.3);
  // The first pose echoes the approved image: Berin seated, leaning on the bar.
  box(m.wood,0,.58,-3.65,4.8,1.15,.9);box(m.wood,0,1.2,-3.65,5.15,.14,1.15);
  for(const x of [-2.35,2.35])box(m.gold,x,.7,-3.14,.035,.85,.03);
  for(const x of [-1.5,0,1.5]){box(m.wood,x,.65,-5,1,.13,.85);for(const sign of [-1,1])box(m.wood,x+sign*.33,.3,-5,.12,.6,.65);}
  const bottle=new T.MeshStandardMaterial({color:0x1f3827,roughness:.28,metalness:.05});
  const bottleShape=new T.LatheGeometry([[0,0],[.1,0],[.115,.035],[.115,.28],[.095,.33],[.037,.39],[.037,.5],[.047,.51]].map(([x,y])=>new T.Vector2(x,y)),18);
  for(let i=0;i<6;i++){const x=(i<3?-1:1)*(1.55+(i%3)*.3),z=-3.7+(i%2)*.15;p(root,bottleShape,bottle,x,1.28,z);p(root,new T.CylinderGeometry(.045,.045,.055,12),m.iron,x,1.81,z);}
  p(root,new T.CylinderGeometry(.15,.13,.26,16),m.iron,.5,1.43,-3.8);
  p(root,new T.TorusGeometry(.09,.025,8,16),m.iron,.68,1.43,-3.8).rotation.y=Math.PI/2;
  for(let i=0;i<18;i++)p(root,new T.CylinderGeometry(.055,.055,.013,10),m.gold,-.65+Math.sin(i*3)*.22,1.29+(i%4)*.012,-3.7+Math.cos(i*2)*.18);
  // Shelf bottles, masonry hearth and practical candles shape the warm interior.
  for(const y of [1.4,2.6]){box(m.wood,0,y,-9.12,6,.13,.55);for(let i=0;i<10;i++)p(root,new T.CylinderGeometry(.09,.1,.4,10),i%3?bottle:m.iron,-2.5+i*.55,y+.26,-9.1);}
  for(const x of [-4.5,4.5])for(const z of [-7,-1.4]){
    box(m.iron,x,2,z,.15,.6,.15);p(root,new T.CylinderGeometry(.11,.1,.28,8),m.ivory,x,2.4,z);
    e(root,new T.MeshBasicMaterial({color:0xffd09a}),x,2.6,z,.05,.12,.05);
    const light=new T.PointLight(0xffa755,18,8,2);light.position.set(x,2.6,z);root.add(light);
  }
  root.add(new T.HemisphereLight(0xc5a17a,0x30231d,.8));
  const key=new T.SpotLight(0xffc38b,100,18,.8,.8,1.5);key.position.set(2,4,-2);key.target.position.set(0,1,-4.8);key.castShadow=true;key.shadow.mapSize.set(1024,1024);root.add(key,key.target);
  const outside=new T.PointLight(0x7195c6,24,12,2);outside.position.set(0,3,4);root.add(outside);
  const doors=[];
  for(const sign of [-1,1]){const hinge=new T.Group();hinge.position.set(sign*1.5,0,.08);root.add(hinge);box(m.wood,-sign*.75,1.65,0,1.5,3.3,.18,hinge);for(const y of [.5,1.5,2.6])box(m.iron,-sign*.75,y,-.12,1.5,.12,.08,hinge);doors.push({hinge,sign});}

  v.bake(root);
  return {root,open(amount){for(const door of doors)door.hinge.rotation.y=door.sign*amount*1.5},dispose(){const geometries=new Set(),materials=new Set(),textures=new Set();root.traverse(o=>{if(o.geometry)geometries.add(o.geometry);for(const material of o.material?(Array.isArray(o.material)?o.material:[o.material]):[]){materials.add(material);for(const value of Object.values(material))if(value?.isTexture)textures.add(value)}});for(const g of geometries)g.dispose();for(const mat of materials)mat.dispose();for(const tex of textures)tex.dispose();root.removeFromParent()}};
}
