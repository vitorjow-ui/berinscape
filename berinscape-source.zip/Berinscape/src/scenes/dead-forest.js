// Leafless trees built from tapered branch segments in one instanced draw.
function createDeadForest(T,random,count=240) {
  const canvas=document.createElement('canvas');canvas.width=canvas.height=256;
  const c=canvas.getContext('2d');c.fillStyle='#65605a';c.fillRect(0,0,256,256);
  for(let i=0;i<700;i++){
    const x=random()*256,y=random()*256;
    c.strokeStyle=i%3?'#272b2980':'#c4b5a244';c.lineWidth=.4+random()*2;
    c.beginPath();c.moveTo(x,y);c.bezierCurveTo(x+6,y+8,x-7,y+20,x+random()*8,y+35+random()*60);c.stroke();
  }
  const map=new T.CanvasTexture(canvas);map.colorSpace=T.SRGBColorSpace;map.wrapS=map.wrapT=T.RepeatWrapping;
  const bark=new T.MeshStandardMaterial({color:0x9a9388,map,bumpMap:map,bumpScale:.055,roughness:1});
  const segments=[];
  const add=(a,b,r)=>segments.push({a,b,r});
  for(let i=0;i<count;i++){
    const x=(random()<.5?-1:1)*(5+random()*36),z=random()*146-18,h=5.5+random()*6;
    const lean=(random()-.5)*1.4,twist=(random()-.5)*.8;
    const point=y=>new T.Vector3(x+lean*y*y,y*h,z+twist*y);
    for(let j=0;j<4;j++)add(point(j/4),point((j+1)/4),(.38-j*.075)*(h/8));
    for(let j=0;j<3;j++){
      const angle=j/3*Math.PI*2+random();
      add(new T.Vector3(x+Math.cos(angle)*.9,.06,z+Math.sin(angle)*.9),point(.12),.16);
    }
    for(let j=0;j<5;j++){
      const level=.35+j*.11,angle=j*2.4+random(),reach=(1.1+random()*1.4)*(1-level*.4),start=point(level);
      const elbow=start.clone().add(new T.Vector3(Math.cos(angle)*reach,h*.10,Math.sin(angle)*reach));
      const tip=elbow.clone().add(new T.Vector3(Math.cos(angle+.3)*reach*.4,h*(.13+random()*.07),Math.sin(angle+.3)*reach*.4));
      add(start,elbow,.14*(1-level*.6));add(elbow,tip,.06);
      add(elbow,elbow.clone().add(new T.Vector3(Math.cos(angle-1)*.8,h*.12,Math.sin(angle-1)*.8)),.045);
    }
  }
  const mesh=new T.InstancedMesh(new T.CylinderGeometry(.52,1,1,7),bark,segments.length);
  const up=new T.Vector3(0,1,0),direction=new T.Vector3(),dummy=new T.Object3D();
  segments.forEach(({a,b,r},i)=>{
    direction.subVectors(b,a);dummy.position.copy(a).add(b).multiplyScalar(.5);
    dummy.quaternion.setFromUnitVectors(up,direction.clone().normalize());dummy.scale.set(r,direction.length(),r);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);
  });
  mesh.name='DeadForest';mesh.castShadow=mesh.receiveShadow=true;
  return mesh;
}
