// Original runtime meshes and surfaces. No downloaded models or textures.
function createVisualModels(T) {
  let seed=817;const random=()=>((seed=seed*16807%2147483647)-1)/2147483646;
  function surface(kind){
    const canvas=document.createElement('canvas');canvas.width=canvas.height=512;const c=canvas.getContext('2d');
    c.fillStyle={fur:'#777d79',skin:'#b37f67',velvet:'#452452',stone:'#55535b',marble:'#383c45',wood:'#493124',rug:'#3d163e',stripe:'#c9c4b2',gold:'#b49965'}[kind];c.fillRect(0,0,512,512);
    if(kind==='stripe')for(let y=0;y<512;y+=128){c.fillStyle='#25252c';c.fillRect(0,y,512,62)}
    for(let i=0;i<18000;i++){
      const x=random()*512,y=random()*512,v=random();c.strokeStyle=c.fillStyle=`rgba(${v>.5?'230,216,189':'8,7,15'},${random()*(kind==='skin'?.11:.17)})`;
      if(kind==='fur'){c.lineWidth=.65;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+3,y+6,x+(random()-.5)*8,y+9+random()*15);c.stroke()}
      else if(kind==='wood'){c.fillRect(x,y,.5,8+random()*45)}
      else c.fillRect(x,y,kind==='skin'?.8:1+random()*2,kind==='velvet'?5:1+random()*2);
    }
    if(kind==='marble'){for(let i=0;i<28;i++){let x=random()*512;c.strokeStyle=i%2?'#a39b7d35':'#080d1838';c.lineWidth=.4+random()*2;c.beginPath();c.moveTo(x,0);for(let y=0;y<530;y+=20){x+=(random()-.5)*40;c.lineTo(x,y)}c.stroke()}c.strokeStyle='#090c14';c.lineWidth=4;c.strokeRect(0,0,512,512)}
    if(kind==='rug'){c.strokeStyle='#c49a52';c.lineWidth=5;c.strokeRect(20,0,472,512);c.lineWidth=1;for(let y=0;y<512;y+=32){c.beginPath();c.moveTo(34,y);c.lineTo(45,y+12);c.lineTo(34,y+24);c.moveTo(478,y);c.lineTo(467,y+12);c.lineTo(478,y+24);c.stroke()}}
    const texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;texture.wrapS=texture.wrapT=T.RepeatWrapping;return texture;
  }
  const textures=Object.fromEntries(['fur','skin','velvet','stone','marble','wood','rug','stripe','gold'].map(k=>[k,surface(k)]));
  const mat=(color,kind,metalness=0,roughness=.8)=>new T.MeshStandardMaterial({color,map:textures[kind],bumpMap:textures[kind],bumpScale:kind==='fur'?.035:kind==='skin'?.008:.02,metalness,roughness});
  const m={fur:mat(0xc0c7c5,'fur'),furDark:mat(0x626967,'fur'),furLight:mat(0xe4dfc8,'fur'),skin:mat(0xffd7bd,'skin',0,.65),cloth:mat(0xcab4d4,'velvet'),shirt:mat(0xffffff,'stripe'),stone:mat(0xaaa5b0,'stone'),marble:mat(0xc4cedd,'marble',.15,.3),wood:mat(0xb5a58b,'wood'),rug:mat(0xffffff,'rug'),gold:mat(0xffd38a,'gold',.78,.3),iron:mat(0x555761,'stone',.7,.45),black:new T.MeshStandardMaterial({color:0x17151b,roughness:.65}),ivory:mat(0xffffd8,'skin'),hair:mat(0xd5b267,'fur'),eye:new T.MeshStandardMaterial({color:0xc69c45,roughness:.2}),gem:new T.MeshStandardMaterial({color:0xa6c8ea,metalness:.5,roughness:.08})};
  const sphere=new T.SphereGeometry(1,16,12),box=new T.BoxGeometry(1,1,1);
  function piece(parent,g,material,x,y,z,sx=1,sy=1,sz=1){const mesh=new T.Mesh(g,material);mesh.position.set(x,y,z);mesh.scale.set(sx,sy,sz);mesh.castShadow=mesh.receiveShadow=true;parent.add(mesh);return mesh}
  const ellipsoid=(p,material,x,y,z,sx,sy,sz)=>piece(p,sphere,material,x,y,z,sx,sy,sz);
  function profile(points){ // Smooth oval rings form the trunk and tapered muzzle.
    const ring=new T.CatmullRomCurve3(points.map(p=>new T.Vector3(p[0],p[1],p[2])));
    const centers=new T.CatmullRomCurve3(points.map(p=>new T.Vector3(p[3],p[4],p[2])));
    const pos=[],uv=[],indices=[],sides=24,rows=40;
    for(let j=0;j<=rows;j++){const v=j/rows,r=ring.getPoint(v),center=centers.getPoint(v);for(let i=0;i<=sides;i++){const a=i/sides*Math.PI*2;pos.push(center.x+Math.max(.005,r.x)*Math.cos(a),center.y+Math.max(.005,r.y)*Math.sin(a),r.z);uv.push(i/sides,v)}}
    for(let j=0;j<rows;j++)for(let i=0;i<sides;i++){const a=j*(sides+1)+i,b=a+sides+1;indices.push(a,a+1,b,b,a+1,b+1)}
    const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();return g;
  }
  function curve(parent,points,radius,material,segments=14){return piece(parent,new T.TubeGeometry(new T.CatmullRomCurve3(points.map(p=>new T.Vector3(...p))),segments,radius,7,false),material,0,0,0)}
  function bake(root){ // Merge direct static pieces by material; animated child groups stay separate.
    root.updateMatrixWorld(true);const batches=new Map();
    for(const child of [...root.children])if(child.isMesh&&!child.isInstancedMesh){child.updateMatrix();const g=(child.geometry.index?child.geometry.toNonIndexed():child.geometry.clone());g.applyMatrix4(child.matrix);const list=batches.get(child.material)||[];list.push(g);batches.set(child.material,list);root.remove(child)}
    for(const [material,geometries] of batches){const g=new T.BufferGeometry();for(const key of ['position','normal','uv']){const arrays=geometries.map(x=>x.getAttribute(key));if(arrays.some(a=>!a))continue;const data=new Float32Array(arrays.reduce((n,a)=>n+a.array.length,0));let offset=0;for(const a of arrays){data.set(a.array,offset);offset+=a.array.length}g.setAttribute(key,new T.BufferAttribute(data,arrays[0].itemSize))}piece(root,g,material,0,0,0);geometries.forEach(g=>g.dispose())}
  }
  function wolf(){
    const root=new T.Group();piece(root,profile([[.005,.005,-.9,0,.8],[.23,.3,-.65,0,.82],[.27,.31,-.1,0,.86],[.33,.43,.38,0,.88],[.24,.3,.65,0,1.03],[.005,.005,.8,0,1.12]]),m.fur,0,0,0);
    ellipsoid(root,m.furLight,0,1.02,.49,.27,.46,.31);ellipsoid(root,m.fur,0,1.27,.64,.25,.35,.23);
    const head=new T.Group();head.position.set(0,1.4,.69);root.add(head);ellipsoid(head,m.fur,0,0,0,.26,.25,.29);
    piece(head,profile([[.17,.14,.1,0,-.04],[.14,.1,.31,0,-.08],[.08,.07,.54,0,-.12],[.005,.005,.57,0,-.12]]),m.furLight,0,0,0);
    ellipsoid(head,m.black,0,-.11,.53,.095,.065,.065);ellipsoid(head,m.black,0,-.17,.32,.11,.012,.18);
    for(const sign of [-1,1]){const ear=piece(head,new T.ConeGeometry(.14,.39,5),m.furDark,sign*.17,.3,-.015);ear.rotation.z=-sign*.18;piece(head,new T.ConeGeometry(.075,.25,3),m.skin,sign*.17,.3,.045);
      ellipsoid(head,m.black,sign*.185,.04,.187,.064,.042,.034);ellipsoid(head,m.eye,sign*.191,.045,.211,.027,.026,.013);ellipsoid(head,m.black,sign*.191,.045,.223,.009,.022,.005);
      const brow=ellipsoid(head,m.furDark,sign*.18,.105,.17,.12,.04,.11);brow.rotation.z=-sign*.22;}
    for(let i=0;i<18;i++){const a=i/18*Math.PI*2;const tuft=piece(root,new T.ConeGeometry(.075,.29,4),i%3?m.fur:m.furLight,Math.cos(a)*.25,1.01+Math.sin(a)*.27,.42);tuft.rotation.x=-1.7}
    const legs=[];for(const x of [-.2,.2])for(const z of [-.56,.43]){const hip=new T.Group();hip.position.set(x,.79,z);root.add(hip);const back=z<0;ellipsoid(hip,m.fur,0,-.15,0,.14,back?.3:.25,.16);const knee=new T.Group();knee.position.set(0,-.36,back?.1:-.02);hip.add(knee);ellipsoid(knee,m.furLight,0,-.17,0,.075,.24,.075);ellipsoid(knee,m.furDark,0,-.37,.08,.1,.075,.17);for(let j=0;j<3;j++)ellipsoid(knee,m.black,(j-1)*.04,-.38,.21,.012,.018,.035);bake(knee);bake(hip);legs.push({hip,knee,phase:(x*z>0?0:Math.PI),back});}
    const tail=new T.Group();tail.position.set(0,.9,-.69);root.add(tail);curve(tail,[[0,0,0],[0,-.05,-.3],[0,-.3,-.62],[0,-.5,-.7]],.11,m.furDark);
    bake(head);bake(root);root.scale.setScalar(.8);return {root,legs,head,tail};
  }
  return {m,textures,piece,ellipsoid,curve,bake,wolf,sphere,box};
}
