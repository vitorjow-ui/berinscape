function createCastleHall(T,v) {
  const hall=new T.Group(),torches=[],{m,piece:p,ellipsoid:e,curve,bake}=v;
  const box=(material,x,y,z,w,h,d)=>p(hall,v.box,material,x,y,z,w,h,d);
  v.textures.marble.repeat.set(9,22);v.textures.rug.repeat.set(1,10);
  box(m.marble,0,-.2,18,19,.4,46);box(m.rug,0,.025,16,3.5,.025,39);
  for(const x of [-1.84,1.84])box(m.gold,x,.04,16,.035,.015,39);
  // Recessed masonry walls, plinths and decorative dado panels.
  for(const x of [-9,9]){box(m.stone,x,5.5,18,.6,11,46);box(m.iron,x*.97,.5,18,.25,1,46);box(m.gold,x*.965,1.05,18,.04,.04,46);}
  box(m.stone,0,5.5,40,18,11,.6);
  // Complete the arrival wall and its heavy recessed doors, visible in reverse shots.
  box(m.stone,-6,5.3,-4.7,6,10.6,.65);box(m.stone,6,5.3,-4.7,6,10.6,.65);
  box(m.stone,0,8.4,-4.7,6,4.4,.65);
  box(m.wood,0,3,-4.45,5.8,6,.32);
  for(const x of [-3.15,3.15])box(m.marble,x,3.2,-4.12,.32,6.4,.5);
  box(m.marble,0,6.35,-4.12,6.6,.4,.5);
  for(const x of [-2.2,-1.1,0,1.1,2.2])box(m.iron,x,3,-4.24,.09,5.9,.12);
  for(const y of [1,3.2,5.2])box(m.iron,0,y,-4.2,5.8,.16,.14);
  for(const x of [-.35,.35])p(hall,new T.TorusGeometry(.16,.035,8,20),m.gold,x,2.9,-4.06);
  const arch=(x,z,alongX=false)=>{
    const points=[];for(let i=0;i<=24;i++){const t=i/24;points.push(alongX?[x+Math.sin(t*Math.PI)*.7,7+Math.sin(t*Math.PI)*3,z-4+8*t]:[-7+14*t,7+3.3*Math.sin(t*Math.PI),z])}curve(hall,points,.14,m.stone,32);
  };
  for(let z=0;z<=35;z+=7){
    arch(0,z);
    for(const x of [-7.6,7.6]){
      p(hall,new T.CylinderGeometry(.38,.5,7.8,16),m.stone,x,3.9,z);
      p(hall,new T.CylinderGeometry(.7,.75,.22,12),m.iron,x,.2,z);
      for(const y of [.4,7.6])p(hall,new T.CylinderGeometry(.65,.65,.2,12),m.gold,x,y,z);
      for(let i=0;i<5;i++){const a=i/5*Math.PI*2;p(hall,new T.CylinderGeometry(.085,.085,7,7),m.stone,x+Math.cos(a)*.32,4,z+Math.sin(a)*.32)}
      curve(hall,[[x,7.6,z],[x*.6,9.2,z+2],[0,10.3,z+3.5]],.075,m.gold);
      // Banners have a scalloped fabric surface and embroidered insignia.
      const banner=new T.PlaneGeometry(1.3,3.1,10,20),pos=banner.attributes.position;
      for(let i=0;i<pos.count;i++)pos.setZ(i,Math.sin(pos.getX(i)*16)*.05);banner.computeVertexNormals();
      const fabric=m.cloth.clone();fabric.side=T.DoubleSide;
      const b=p(hall,banner,fabric,x*.965,5.3,z-.38);b.rotation.y=x>0?-Math.PI/2:Math.PI/2;
      p(hall,new T.CylinderGeometry(.04,.04,1.6,8),m.gold,x*.965,6.9,z-.38).rotation.z=Math.PI/2;
      const canvas=document.createElement('canvas');canvas.width=128;canvas.height=256;const c=canvas.getContext('2d');c.fillStyle='#452452';c.fillRect(0,0,128,256);c.strokeStyle='#c5a46a';c.lineWidth=3;c.strokeRect(6,6,116,244);c.font='bold 86px Georgia';c.textAlign='center';c.fillStyle='#d1ac65';c.fillText('B',64,154);c.font='34px Georgia';c.fillText('♛',64,65);
      const texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;b.material=new T.MeshStandardMaterial({map:texture,roughness:1,side:T.DoubleSide});
    }
  }
  // Vault panels close the ceiling; light can still enter from the side windows.
  for(let strip=0;strip<10;strip++){const t=(strip+.5)/10,x=-8+16*t,y=7.3+3*Math.sin(Math.PI*t);const panel=box(m.stone,x,y,18,1.75,.2,46);panel.rotation.z=-Math.cos(Math.PI*t)*.5;}
  const glass=new T.MeshStandardMaterial({color:0x476b8c,emissive:0x2b4868,emissiveIntensity:.8,roughness:.3});
  for(let z=3.5;z<38;z+=7)for(const sign of [-1,1]){
    const x=sign*8.64;box(glass,x,5,z,.035,4,2.2);
    for(const offset of [-.75,0,.75])box(m.iron,x-sign*.035,5,z+offset,.07,4,.07);
    for(const y of [3,4.5,6,7])box(m.stone,x-sign*.04,y,z,.12,.09,2.3);
    const shape=new T.Shape();shape.moveTo(-1.1,0);shape.lineTo(-1.1,2);shape.quadraticCurveTo(-.8,3.2,0,3.7);shape.quadraticCurveTo(.8,3.2,1.1,2);shape.lineTo(1.1,0);shape.closePath();
    const windowMesh=p(hall,new T.ShapeGeometry(shape),glass,x,4,z);windowMesh.rotation.y=sign>0?-Math.PI/2:Math.PI/2;
  }
  const flames=[];
  for(const z of [3,14,25,36])for(const sign of [-1,1]){
    const x=sign*6.8;p(hall,new T.CylinderGeometry(.08,.13,1.8,10),m.iron,x,1.3,z);
    p(hall,new T.CylinderGeometry(.4,.15,.3,12),m.gold,x,2.28,z);
    for(let i=0;i<4;i++){const a=i/4*Math.PI*2;p(hall,new T.CylinderGeometry(.025,.04,.45,6),m.gold,x+Math.cos(a)*.25,2.5,z+Math.sin(a)*.25)}
    const light=new T.PointLight(0xffbd78,27,15,2);light.position.set(x,2.8,z);hall.add(light);torches.push(light);
    const fire=createTorchFire(T,z+sign);fire.root.position.set(x,2.45,z);hall.add(fire.root);flames.push(fire);
  }
  hall.add(new T.HemisphereLight(0xc3c9e7,0x4a3030,1.5));
  const rim=new T.PointLight(0x9aabff,55,24,2);rim.position.set(0,7,36);hall.add(rim);
  const arrivalFill=new T.PointLight(0xffcc91,35,12,2);arrivalFill.position.set(0,4,2);hall.add(arrivalFill);
  // Detailed chests and small coins replace the oversized gold blobs.
  const coinGeometry=new T.CylinderGeometry(.075,.075,.018,10),treasure=new T.InstancedMesh(coinGeometry,m.gold,1600),dummy=new T.Object3D();
  let seed=93;const rand=()=>((seed=seed*16807%2147483647)-1)/2147483646;
  for(let i=0;i<1600;i++){const cluster=i%12,z=3+Math.floor(cluster/2)*5.7,sign=cluster%2?1:-1,r=rand()*1.3,a=rand()*Math.PI*2;dummy.position.set(sign*5+Math.cos(a)*r,.06+(1-r/1.4)*rand()*.28,z+Math.sin(a)*r);dummy.rotation.set(rand()*.3,rand()*6,rand()*.3);dummy.updateMatrix();treasure.setMatrixAt(i,dummy.matrix)}treasure.receiveShadow=true;hall.add(treasure);
  for(let z=4;z<34;z+=8)for(const x of [-5.3,5.3]){
    box(m.wood,x,.42,z,1.4,.72,.85);
    const lid=p(hall,new T.CylinderGeometry(.47,.47,1.4,16,1,false,0,Math.PI),m.wood,x,.78,z);lid.rotation.z=Math.PI/2;
    for(const offset of [-.48,.48]){box(m.gold,x+offset,.45,z,.08,.75,.88);const band=p(hall,new T.TorusGeometry(.475,.03,6,16,Math.PI),m.gold,x+offset,.78,z);band.rotation.y=Math.PI/2;}
    box(m.iron,x,.57,z-.45,.14,.2,.05);
    for(let i=0;i<4;i++)p(hall,new T.OctahedronGeometry(.11),i%2?m.gem:m.gold,x+(i-1.5)*.25,.92,z);
    for(let i=0;i<2;i++){const xx=x+(i?1:-1)*.95;p(hall,new T.CylinderGeometry(.06,.12,.35,10),m.gold,xx,.2,z+.3);p(hall,new T.SphereGeometry(.18,12,8,0,Math.PI*2,0,Math.PI/2),m.gold,xx,.48,z+.3);}
  }
  // Shallow dais and an upholstered throne, with owl reliefs and gold filigree.
  for(let i=0;i<3;i++){box(m.marble,0,.12+i*.16,35.3,7-i*.6,.24,5-i*.45);box(m.gold,0,.245+i*.16,32.8+i*.23,7-i*.6,.025,.04)}
  box(m.iron,0,1.1,35.3,2.3,1.1,1.9);box(m.cloth,0,1.72,35.1,1.95,.25,1.55);box(m.gold,0,3,36.1,2.35,3,.25);box(m.cloth,0,3,35.93,2.06,2.7,.16);
  for(let row=0;row<5;row++)for(let col=0;col<4;col++)e(hall,m.gold,-.72+col*.48,1.95+row*.48,35.81,.035,.035,.035);
  for(const x of [-1.18,1.18]){box(m.gold,x,2.1,35.3,.22,.2,1.9);p(hall,new T.CylinderGeometry(.09,.14,1.5,12),m.gold,x,1.2,34.6);e(hall,m.gold,x,2.15,34.4,.21,.17,.24);p(hall,new T.ConeGeometry(.2,.75,6),m.gold,x,4.87,36.1);}
  e(hall,m.gold,0,4.64,35.9,.36,.3,.12);for(const sign of [-1,1]){e(hall,m.black,sign*.14,4.68,35.78,.115,.115,.035);e(hall,m.gold,sign*.14,4.68,35.73,.06,.06,.025);const wing=e(hall,m.gold,sign*.48,4.65,35.94,.4,.12,.07);wing.rotation.z=sign*.35;curve(hall,[[sign*.95,1.8,35.8],[sign*.88,3.2,35.8],[sign*.5,4.3,35.8]],.035,m.gold);}
  // Suspended iron chandeliers, with warm candlelight above the processional aisle.
  const candle=new T.MeshStandardMaterial({color:0xe7d5ad,roughness:.85});
  const glow=new T.MeshBasicMaterial({color:0xffdc9c});
  for(const z of [9,23,34]){
    p(hall,new T.CylinderGeometry(.035,.035,2.4,8),m.iron,0,8.5,z);
    const ring=p(hall,new T.TorusGeometry(1.65,.065,8,48),m.iron,0,7.25,z);ring.rotation.x=Math.PI/2;
    for(let i=0;i<10;i++){
      const a=i*Math.PI/5,x=Math.cos(a)*1.65,zz=z+Math.sin(a)*1.65;
      curve(hall,[[0,8.8,z],[x*.55,7.65,z+(zz-z)*.55],[x,7.25,zz]],.025,m.iron);
      p(hall,new T.CylinderGeometry(.16,.1,.07,10),m.gold,x,7.28,zz);
      p(hall,new T.CylinderGeometry(.055,.065,.3,8),candle,x,7.46,zz);
      e(hall,glow,x,7.67,zz,.045,.1,.045);
    }
    const light=new T.PointLight(0xffcb8f,38,17,2);light.position.set(0,6.9,z);hall.add(light);
  }
  // A rose window crowns the existing throne, framed in weathered stone and brass.
  const rose=new T.MeshStandardMaterial({color:0x416680,emissive:0x294c72,emissiveIntensity:1.2,roughness:.4});
  p(hall,new T.CircleGeometry(2,48),rose,0,7.7,39.65).rotation.y=Math.PI;
  for(const radius of [1.82,2,2.18])p(hall,new T.TorusGeometry(radius,.075,8,48),radius===2?m.gold:m.stone,0,7.7,39.57);
  for(let i=0;i<12;i++){
    const a=i*Math.PI/6;
    curve(hall,[[0,7.7,39.5],[Math.cos(a)*.7,7.7+Math.sin(a)*.7,39.5],[Math.cos(a)*1.95,7.7+Math.sin(a)*1.95,39.5]],.035,m.gold);
  }
  p(hall,new T.TorusGeometry(.68,.055,8,32),m.gold,0,7.7,39.48);
  // Low plinths and repeated floor inlays give the room a human scale.
  for(const x of [-8.55,8.55])box(m.marble,x,.25,18,.35,.5,44);
  for(let z=0;z<32;z+=2.8)for(const x of [-2.5,2.5]){
    const inlay=box(m.gold,x,.012,z,.22,.012,.22);inlay.rotation.y=Math.PI/4;
  }
  const throneLight=new T.SpotLight(0xffdda4,125,22,.5,.65,1.5);
  throneLight.position.set(-2,9,30);throneLight.target.position.set(0,2,35.3);
  throneLight.castShadow=true;throneLight.shadow.mapSize.set(1024,1024);throneLight.shadow.bias=-.0004;
  hall.add(throneLight,throneLight.target);
  bake(hall);
  for(let z=0;z<=35;z+=7)for(const x of [-7.6,7.6]){const shade=createSoftContact(T,2,1.8,.3);shade.position.set(x,.035,z);hall.add(shade);}
  for(let z=4;z<34;z+=8)for(const x of [-5.3,5.3]){const shade=createSoftContact(T,2.2,1.5,.36);shade.position.set(x,.04,z);hall.add(shade);}
  for(let z=3;z<35;z+=5.7)for(const x of [-5,5]){const shade=createSoftContact(T,3,2.2,.2);shade.position.set(x,.035,z);hall.add(shade);}
  return {hall,torches,flames};
}
