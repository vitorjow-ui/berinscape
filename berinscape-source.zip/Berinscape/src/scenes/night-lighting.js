// Shared fire: rising turbulent flame, hot core, halo and drifting embers.
function createTorchFire(T,seed=0){
 const root=new T.Group();root.name='LivingTorchFire';
 const uniforms={time:{value:0},seed:{value:seed},strength:{value:1}};
 const material=new T.ShaderMaterial({uniforms,transparent:true,depthWrite:false,side:T.DoubleSide,
  vertexShader:`varying vec2 vUv;void main(){vUv=uv;vec4 center=modelViewMatrix*vec4(0.,0.,0.,1.);float sx=length(modelMatrix[0].xyz),sy=length(modelMatrix[1].xyz);center.xy+=position.xy*vec2(sx,sy);gl_Position=projectionMatrix*center;}`,
  fragmentShader:`varying vec2 vUv;uniform float time,seed,strength;
   float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
   float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+1.),f.x),f.y);}
   void main(){float y=vUv.y;vec2 p=vec2(vUv.x*5.+seed,y*5.-time*3.1);float n=noise(p)*.65+noise(p*2.2)*.25+noise(p*4.1)*.1;
    float bend=sin(y*7.-time*3.+seed)*.055*y+(n-.5)*.12*y;float x=abs(vUv.x-.5+bend);float width=(.32*(1.-pow(y,.72))+.025)*( .8+strength*.2);
    float edge=width-x+(n-.5)*.11*y;float a=smoothstep(-.025,.055,edge)*smoothstep(0.,.08,y)*(1.-smoothstep(.78,1.,y));
    float core=(1.-smoothstep(.02,.17,x))*pow(1.-y,1.8);vec3 color=mix(vec3(1.,.065,.006),vec3(1.,.57,.06),1.-y);color=mix(color,vec3(1.,.94,.58),core);
    gl_FragColor=vec4(color*1.7,a*.94);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
   }`});
 const flame=new T.Mesh(new T.PlaneGeometry(.72,1.05),material);flame.position.y=.38;flame.frustumCulled=false;root.add(flame);
 if(!createTorchFire.halo){const c=document.createElement('canvas');c.width=c.height=64;const ctx=c.getContext('2d'),g=ctx.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,'rgba(255,150,40,.4)');g.addColorStop(.3,'rgba(255,70,10,.12)');g.addColorStop(1,'rgba(255,30,0,0)');ctx.fillStyle=g;ctx.fillRect(0,0,64,64);createTorchFire.halo=new T.CanvasTexture(c);createTorchFire.halo.colorSpace=T.SRGBColorSpace;}
 const halo=new T.Sprite(new T.SpriteMaterial({map:createTorchFire.halo,transparent:true,depthWrite:false,blending:T.AdditiveBlending,opacity:.46}));halo.position.y=.32;halo.scale.set(1.5,1.8,1);root.add(halo);
 const positions=new Float32Array(18),geo=new T.BufferGeometry();geo.setAttribute('position',new T.BufferAttribute(positions,3));
 const sparks=new T.Points(geo,new T.PointsMaterial({color:0xffa452,size:.025,transparent:true,opacity:.65,depthWrite:false,blending:T.AdditiveBlending}));root.add(sparks);
 return {root,update(t){const f=1+Math.sin(t*7.3+seed)*.065+Math.sin(t*12.7+seed*2)*.045+Math.sin(t*3.1+seed)*.08;uniforms.time.value=t;uniforms.strength.value=f;halo.material.opacity=.43*f;for(let i=0;i<6;i++){const life=(t*(.32+i*.017)+i*.167+seed*.13)%1;positions[i*3]=Math.sin(t*1.7+i*5+seed)*life*.22;positions[i*3+1]=.25+life*1.6;positions[i*3+2]=Math.cos(i*4+t)*life*.14;}geo.attributes.position.needsUpdate=true;return f;}};
}

function createMedievalTorch(T,seed=0){
 const root=new T.Group();root.name='RoadTorch';
 const wood=new T.MeshStandardMaterial({color:0x241910,roughness:.98}),iron=new T.MeshStandardMaterial({color:0x25242a,metalness:.7,roughness:.65});
 const post=new T.Mesh(new T.CylinderGeometry(.065,.12,1.95,9),wood);post.position.y=.975;post.castShadow=post.receiveShadow=true;root.add(post);
 for(const y of [.22,1.5,1.82]){const ring=new T.Mesh(new T.CylinderGeometry(.095,.095,.09,10),iron);ring.position.y=y;root.add(ring);}
 const basket=new T.Mesh(new T.CylinderGeometry(.23,.12,.28,10,1,true),iron);basket.position.y=1.98;basket.castShadow=true;root.add(basket);
 for(let i=0;i<5;i++){const a=i/5*Math.PI*2,prong=new T.Mesh(new T.BoxGeometry(.035,.35,.035),iron);prong.position.set(Math.cos(a)*.19,2.11,Math.sin(a)*.19);root.add(prong);}
 const fire=createTorchFire(T,seed);fire.root.position.y=2.06;root.add(fire.root);
 const light=new T.PointLight(0xff9d47,38,15,2);light.position.y=2.35;root.add(light);
 return {root,fire,light,seed};
}

function createNightTorches(T,scene){
 const torches=[],position=new T.Vector3();
 // One warm shadow map, four nearby point lights; distant fires remain visible.
 const shadow=new T.SpotLight(0xffae68,30,13,1.25,.8,2);shadow.castShadow=true;shadow.shadow.mapSize.set(1024,1024);shadow.shadow.bias=-.0003;shadow.shadow.normalBias=.035;shadow.shadow.camera.near=.25;shadow.shadow.camera.far=13;shadow.visible=false;scene.add(shadow,shadow.target);
 return {torches,add(parent,at,seed){const torch=createMedievalTorch(T,seed);torch.root.position.copy(at);parent.add(torch.root);torches.push(torch);return torch;},update(t,focus,active){
  const nearest=active?torches.map(torch=>{torch.light.getWorldPosition(position);return {torch,d:position.distanceToSquared(focus)}}).sort((a,b)=>a.d-b.d).slice(0,4):[];
  const lit=new Set(nearest.map(entry=>entry.torch));for(const torch of torches){const power=torch.fire.update(t);torch.light.visible=active&&lit.has(torch);torch.light.intensity=38*power;torch.light.color.setHSL(.073+(power-1)*.018,1,.65);}
  shadow.visible=active&&nearest.length>0;if(shadow.visible){const torch=nearest[0].torch;torch.light.getWorldPosition(shadow.position);shadow.target.position.copy(focus);shadow.target.position.y+=.25;shadow.intensity=22*torch.light.intensity/38;}
 }};
}

function createSoftContact(T,width=1,depth=1,opacity=.3){
 if(!createSoftContact.texture){const c=document.createElement('canvas');c.width=c.height=64;const ctx=c.getContext('2d'),g=ctx.createRadialGradient(32,32,3,32,32,32);g.addColorStop(0,'#000b');g.addColorStop(.4,'#0006');g.addColorStop(1,'#0000');ctx.fillStyle=g;ctx.fillRect(0,0,64,64);createSoftContact.texture=new T.CanvasTexture(c);}
 const mesh=new T.Mesh(new T.PlaneGeometry(width,depth),new T.MeshBasicMaterial({map:createSoftContact.texture,transparent:true,opacity,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1}));mesh.rotation.x=-Math.PI/2;mesh.position.y=.045;return mesh;
}
