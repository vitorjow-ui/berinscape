// Maps logical journey distance onto the actual curved road in dasy444's forest.
function createImportedForest(T,gltf) {
  const sourcePoints=[[.50,4.78],[.40,4.2],[-.2,3.45],[-1.2,2.8],[-1.85,2],[-2,1.1],[-1.78,.25],[-1.1,-.4],[0,-.95],[.9,-1.65],[1.65,-2.4],[2.02,-3.2],[1.9,-3.9]];
  const curve=new T.CatmullRomCurve3(sourcePoints.map(([x,z])=>new T.Vector3(x,0,z)),false,'centripetal');
  const scale=107/curve.getLength(),root=new T.Group();root.name='ImportedForestRoad';root.add(gltf.scene);
  root.scale.setScalar(scale);root.rotation.y=Math.PI;root.position.set(sourcePoints[0][0]*scale,0,sourcePoints[0][1]*scale);
  let ground;
  gltf.scene.traverse(o=>{if(!o.isMesh)return;
    o.castShadow=true;o.receiveShadow=true;
    if(o.name==='ForestGround')ground=o;
    const materials=Array.isArray(o.material)?o.material:[o.material];
    for(const m of materials){
      if(m.transparent){m.transparent=false;m.alphaTest=.4;m.depthWrite=true;m.side=T.DoubleSide;}
      m.roughness=Math.max(.82,m.roughness);m.metalness=0;
      if(m.map)m.map.anisotropy=4;
    }
  });
  if(!ground)throw new Error('Terreno da floresta não encontrado');
  // Keep the supplied road map; add subdued world-scale soil variation.
  const soilMaterials=(Array.isArray(ground.material)?ground.material:[ground.material]).map(source=>{
    const material=source.clone();material.color.multiplyScalar(.82);material.roughness=.98;
    material.onBeforeCompile=shader=>{
      shader.vertexShader='varying vec2 vSoilWorld;\n'+shader.vertexShader;
      shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvSoilWorld=(modelMatrix*vec4(transformed,1.0)).xz;');
      shader.fragmentShader='varying vec2 vSoilWorld;\nfloat soilHash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}\nfloat soilNoise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(soilHash(i),soilHash(i+vec2(1.,0.)),f.x),mix(soilHash(i+vec2(0.,1.)),soilHash(i+1.),f.x),f.y);}\n'+shader.fragmentShader;
      shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>','#include <color_fragment>\nfloat soil=soilNoise(vSoilWorld*1.8)*.7+soilNoise(vSoilWorld*14.)*.3;diffuseColor.rgb*=mix(vec3(.7,.74,.8),vec3(.98,.92,.81),soil);');
    };material.customProgramCacheKey=()=>'berin-night-soil-1';return material;
  });ground.material=Array.isArray(ground.material)?soilMaterials:soilMaterials[0];
  ground.castShadow=false;root.updateMatrixWorld(true);
  const ray=new T.Raycaster(),down=new T.Vector3(0,-1,0);
  function height(x,z){ray.set(new T.Vector3(x,1000,z),down);const hit=ray.intersectObject(ground,false)[0];if(!hit)throw new Error('Ponto fora do terreno da floresta');return hit.point.y;}
  // Grade a compact arrival court under the castle's flat entrance apron.
  const gate=curve.getPointAt(1);root.localToWorld(gate);gate.y=height(gate.x,gate.z);
  const positions=ground.geometry.attributes.position,vertex=new T.Vector3();
  for(let i=0;i<positions.count;i++){
    vertex.fromBufferAttribute(positions,i);ground.localToWorld(vertex);
    const distance=Math.hypot(vertex.x-gate.x,vertex.z-gate.z);
    const blend=1-T.MathUtils.smoothstep(distance,6,12);
    if(blend<=0)continue;
    vertex.y=T.MathUtils.lerp(vertex.y,gate.y-.06,blend);
    ground.worldToLocal(vertex);positions.setXYZ(i,vertex.x,vertex.y,vertex.z);
  }
  positions.needsUpdate=true;ground.geometry.computeVertexNormals();ground.geometry.computeBoundingSphere();
  // Cache cross-sections so moving actors do not raycast the dense terrain each frame.
  const sections=[];
  for(let i=0;i<=428;i++){
    const u=i/428,p=curve.getPointAt(u);root.localToWorld(p);
    const tangent=curve.getTangentAt(u).transformDirection(root.matrixWorld);tangent.y=0;tangent.normalize();
    const right=new T.Vector3(tangent.z,0,-tangent.x),heights=[];
    for(let lane=-9;lane<=9;lane++){const q=p.clone().addScaledVector(right,lane);try{heights.push(height(q.x,q.z))}catch{heights.push(null)}}
    if(heights[9]===null)throw new Error('Estrada fora do terreno em '+(i/4));
    sections.push({p,right,tangent,heights});
  }
  function point(distance,lateral=0){
    const index=T.MathUtils.clamp(distance,0,107)*4,low=Math.floor(index),high=Math.min(428,low+1),fraction=index-low;
    const a=sections[low],b=sections[high],right=a.right.clone().lerp(b.right,fraction).normalize();
    const p=a.p.clone().lerp(b.p,fraction).addScaledVector(right,lateral);
    const lane=T.MathUtils.clamp(lateral+9,0,18),left=Math.floor(lane),other=Math.min(18,left+1),f=lane-left;
    const y=s=>{const center=s.heights[9];return T.MathUtils.lerp(s.heights[left]??center,s.heights[other]??center,f)};
    p.y=T.MathUtils.lerp(y(a),y(b),fraction);
    p.y=T.MathUtils.lerp(p.y,gate.y,T.MathUtils.smoothstep(distance,98,103));return p;
  }
  function project(p){let best=Infinity,result;
    for(let i=0;i<sections.length-1;i++){
      const a=sections[i],b=sections[i+1],dx=b.p.x-a.p.x,dz=b.p.z-a.p.z;
      const t=T.MathUtils.clamp(((p.x-a.p.x)*dx+(p.z-a.p.z)*dz)/(dx*dx+dz*dz),0,1);
      const x=a.p.x+dx*t,z=a.p.z+dz*t,d=(x-p.x)**2+(z-p.z)**2;
      if(d<best){best=d;const right=a.right.clone().lerp(b.right,t).normalize();result={z:(i+t)/4,x:(p.x-x)*right.x+(p.z-z)*right.z};}
    }
    return result;
  }
  function hit(x,y,camera){ray.setFromCamera(new T.Vector2(x/innerWidth*2-1,-y/innerHeight*2+1),camera);const found=ray.intersectObject(ground,false)[0];return found?project(found.point):null;}
  return {root,ground,point,project,hit,scale,tangent(distance){return sections[Math.round(T.MathUtils.clamp(distance,0,107)*4)].tangent.clone()}};
}
