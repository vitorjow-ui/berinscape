function createFootGrounding(T,model,sample){
  model.updateMatrixWorld(true);
  const base=new T.Box3().setFromObject(model).min.y;
  const bone=name=>model.getObjectByName(name)||model.getObjectByName(name.replaceAll('.',''));
  const legs=['L','R'].map(side=>({foot:bone('Foot.'+side),shin:bone('Shin.'+side),thigh:bone('Thigh.'+side)}));
  for(const leg of legs){if(!leg.foot||!leg.shin||!leg.thigh)throw new Error('Rig de apoio dos pés incompleto');leg.clearance=T.MathUtils.clamp(leg.foot.getWorldPosition(new T.Vector3()).y-base,.06,.25);}
  const saved=new Map(),p=new T.Vector3(),end=new T.Vector3(),target=new T.Vector3(),a=new T.Vector3(),b=new T.Vector3(),delta=new T.Quaternion(),parent=new T.Quaternion();
  return {
    beforeAnimation(){for(const [bone,q] of saved)bone.quaternion.copy(q);saved.clear();},
    apply(){
      model.updateMatrixWorld(true);
      for(const leg of legs){
        leg.foot.getWorldPosition(end);const floor=sample(end.x,end.z);
        const lift=Math.max(0,end.y-model.position.y-leg.clearance-.045);
        target.copy(end);target.y=end.y+T.MathUtils.clamp(floor+leg.clearance+lift-end.y,-.14,.18);
        for(const bone of [leg.shin,leg.thigh])saved.set(bone,bone.quaternion.clone());
        for(let iteration=0;iteration<3;iteration++)for(const bone of [leg.shin,leg.thigh]){
          bone.getWorldPosition(p);leg.foot.getWorldPosition(end);
          a.copy(end).sub(p).normalize();b.copy(target).sub(p).normalize();delta.setFromUnitVectors(a,b);
          bone.parent.getWorldQuaternion(parent);delta.premultiply(parent.clone().invert()).multiply(parent);bone.quaternion.premultiply(delta);model.updateMatrixWorld(true);
        }
      }
    }
  };
}

function createCameraGuard(T){
  const solids=[],leaves=[],ray=new T.Raycaster(),direction=new T.Vector3(),boxHit=new T.Vector3();let timer=0;
  const collect=(root,target)=>root.traverse(o=>{if(o.isMesh&&!o.isInstancedMesh&&o.visible){o.updateWorldMatrix(true,false);const box=new T.Box3().setFromObject(o);target.push({mesh:o,box})}});
  return {
    addSolid(root){if(root.name!=='ForestGround')collect(root,solids)},
    addFoliage(root){const start=leaves.length;collect(root,leaves);for(const item of leaves.slice(start)){const list=Array.isArray(item.mesh.material)?item.mesh.material:[item.mesh.material];item.materials=list.map(m=>{const clone=m.clone();clone.transparent=true;return clone});item.mesh.material=Array.isArray(item.mesh.material)?item.materials:item.materials[0];item.opacity=1;item.target=1;}},
    update(dt,position,focus,visibleArea){
      direction.copy(position).sub(focus);const length=direction.length();if(length<.01)return;
      ray.set(focus,direction.normalize());ray.far=length;ray.near=.35;
      let allowed=length;
      for(const item of solids){if(!visibleArea(item.mesh)||!ray.ray.intersectsBox(item.box))continue;const hit=ray.intersectObject(item.mesh,false)[0];if(hit)allowed=Math.min(allowed,Math.max(1.5,hit.distance-.4));}
      if(allowed<length)position.copy(focus).addScaledVector(direction,allowed);
      timer-=dt;
      // Forest meshes are already spatial batches. Use their cached bounds rather
      // than traversing every leaf triangle on every camera update.
      if(timer<=0){timer=.1;for(const item of leaves){item.target=1;if(!visibleArea(item.mesh))continue;const hit=ray.ray.intersectBox(item.box,boxHit);if(item.box.containsPoint(focus)||(hit&&hit.distanceTo(focus)<allowed))item.target=.16;}}
      for(const item of leaves){item.opacity=T.MathUtils.damp(item.opacity,item.target,10,dt);for(const m of item.materials){m.opacity=item.opacity;m.depthWrite=item.opacity>.97;}}
    }
  };
}
