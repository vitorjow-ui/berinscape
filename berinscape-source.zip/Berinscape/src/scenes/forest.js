// Load only the area needed by this attempt. The menu does not create a renderer.
window.buildBerinWorld=async function(initialArea='forest',onProgress=()=>{}){
let renderer,cleanup=()=>{};
try{
onProgress({label:'Preparando o motor 3D…',percent:0});
const T=await import('three');
const {GLTFLoader}=await import('three/addons/loaders/GLTFLoader.js');
const {clone:cloneRig}=await import('three/addons/utils/SkeletonUtils.js');
const loader=new GLTFLoader(),assets=window.BerinAssets;
const scene=new T.Scene();scene.background=new T.Color(0x090f18);scene.fog=new T.FogExp2(0x18242d,.019);
renderer=new T.WebGLRenderer({canvas:document.getElementById('world'),antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=.96;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
const environmentFaces=['#667080','#555b68','#b5bec8','#302a24','#717882','#5c6573'].map(color=>{const c=document.createElement('canvas');c.width=c.height=32;const g=c.getContext('2d');g.fillStyle=color;g.fillRect(0,0,32,32);return c});
const environment=new T.CubeTexture(environmentFaces);environment.colorSpace=T.SRGBColorSpace;environment.needsUpdate=true;const pmrem=new T.PMREMGenerator(renderer);scene.environment=pmrem.fromCubemap(environment).texture;scene.environmentIntensity=.12;environment.dispose();pmrem.dispose();
const camera=new T.PerspectiveCamera(48,innerWidth/innerHeight,.15,260);
const hemisphere=new T.HemisphereLight(0x7996bf,0x10131b,.22);scene.add(hemisphere);
const torchRig=createNightTorches(T,scene);
const moon=new T.DirectionalLight(0x8daee0,.68);moon.castShadow=true;moon.shadow.mapSize.set(2048,2048);Object.assign(moon.shadow.camera,{left:-18,right:18,top:22,bottom:-22,near:1,far:90});moon.shadow.bias=-.0004;moon.shadow.normalBias=.04;scene.add(moon,moon.target);
const fill=new T.DirectionalLight(0x8fa9d2,.16);scene.add(fill,fill.target);
const forestRoot=new T.Group();scene.add(forestRoot);
let tavernStage=null;
let navigation=null,forestLife=null,hallLife=null,castleRoot=null,forestPending=null,hallPending=null,castlePending=null;
let area=initialArea,shot=null,snapCamera=true,destination=null,speed=0,elapsed=0,zoom=9,invalidUntil=0;
const travel=new T.Vector3(),follow=new T.Vector3(),cameraGoal=new T.Vector3(),look=new T.Vector3(),focus=new T.Vector3();
const guard=createCameraGuard(T),ray=new T.Raycaster(),pointer=new T.Vector2(),plane=new T.Plane(new T.Vector3(0,1,0),0);
const marker=new T.Mesh(new T.RingGeometry(.26,.37,32),new T.MeshBasicMaterial({color:0xe5c98a,transparent:true,opacity:.8,depthWrite:false}));marker.rotation.x=-Math.PI/2;marker.visible=false;scene.add(marker);

function gradeMaterials(root){root.traverse(o=>{if(!o.isMesh)return;o.castShadow=o.receiveShadow=true;for(const m of Array.isArray(o.material)?o.material:[o.material]){if(m.map)m.map.anisotropy=4;if(/skin|body|cloth|cape/i.test(m.name))m.roughness=Math.max(.72,m.roughness||0);}})}
async function ensureCastle(){
 if(castleRoot)return;if(castlePending)return castlePending;
 castlePending=assets.load('castle',loader).then(gltf=>{castleRoot=createImportedCastle(T,gltf,navigation);forestRoot.add(castleRoot);guard.addSolid(castleRoot);for(const x of [-3.2,3.2])torchRig.add(castleRoot,new T.Vector3(x,.2,-.8),40+x)}).catch(error=>{castlePending=null;throw error});return castlePending;
}
async function ensureForest(){
 if(navigation)return;if(forestPending)return forestPending;
 forestPending=(async()=>{
  assets.watch(['berin','forest','wolf'],onProgress);
  const forest=await assets.load('forest',loader),wolf=await assets.load('wolf',loader);
  onProgress({label:'Preparando terreno e caminhos…',percent:100});await new Promise(requestAnimationFrame);
  navigation=createImportedForest(T,forest);forestRoot.add(navigation.root);guard.addSolid(navigation.ground);
  for(const child of navigation.root.children)child.traverse(o=>{if(o.isMesh&&o!==navigation.ground)guard.addFoliage(o)});
  forestLife=createForestLife(T,scene,cloneRig,navigation,wolf);forestRoot.add(forestLife.outside);tavernStage=createTavernStage(T);tavernStage.root.position.y=navigation.point(0).y;tavernStage.open(1);forestRoot.add(tavernStage.root);guard.addSolid(tavernStage.root);
  for(const [index,distance] of [5,13,21,29,37,45,53,61,69,77,85,93,101].entries()){
   const side=index%2?1:-1;torchRig.add(forestRoot,navigation.point(distance,side*2.95),index*1.73);
  }
  const disc=new T.Mesh(new T.SphereGeometry(2.3,24,24),new T.MeshBasicMaterial({color:0xb9cbdc,fog:false}));disc.position.set(32,48,135);forestRoot.add(disc);
  let skySeed=19;const random=()=>((skySeed=skySeed*16807%2147483647)-1)/2147483646,stars=new Float32Array(600);
  for(let i=0;i<200;i++){stars[i*3]=(random()-.5)*300;stars[i*3+1]=45+random()*70;stars[i*3+2]=random()*190-30;}
  const sky=new T.BufferGeometry();sky.setAttribute('position',new T.BufferAttribute(stars,3));forestRoot.add(new T.Points(sky,new T.PointsMaterial({color:0x9db6d0,size:.13,transparent:true,opacity:.6,fog:false})));
 })().catch(error=>{forestPending=null;throw error});return forestPending;
}
async function ensureHall(){
 if(hallLife)return;if(hallPending)return hallPending;
 hallPending=assets.load('minion',loader).then(gltf=>{gradeMaterials(gltf.scene);hallLife=createHallLife(T,scene,gltf,cloneRig);guard.addSolid(hallLife.hall)}).catch(error=>{hallPending=null;throw error});return hallPending;
}
assets.watch(initialArea==='hall'?['berin','minion']:['berin','forest','wolf'],onProgress);
const heroPromise=assets.load('berin',loader);
const results=await Promise.allSettled([heroPromise,initialArea==='hall'?ensureHall():ensureForest()]);
for(const result of results)if(result.status==='rejected')throw result.reason;
const hero=results[0].value,model=hero.scene;gradeMaterials(model);scene.add(model);
const mixer=new T.AnimationMixer(model),actions=Object.fromEntries(hero.animations.map(c=>[c.name,mixer.clipAction(c)]));let active;
function play(name){if(active===actions[name])return;const stride=active&&['Walk','Run'].includes(active.getClip().name)&&['Walk','Run'].includes(name)?active.time/active.getClip().duration:0;active?.fadeOut(.2);active=actions[name];if(active){active.reset();active.time=stride*active.getClip().duration;active.fadeIn(.2).play()}}
const place=()=>area==='forest'?navigation.point(travel.z,travel.x):travel.clone();
const motion=createBerinMotion(T,model);
const grounding=createFootGrounding(T,model,(x,z)=>{if(area==='hall')return 0;const p=navigation.project(new T.Vector3(x,0,z));return navigation.point(p.z,p.x).y});
// A soft contact shadow anchors the hero even in diffuse moonlight.
const shadowCanvas=document.createElement('canvas');shadowCanvas.width=shadowCanvas.height=64;const ctx=shadowCanvas.getContext('2d'),gradient=ctx.createRadialGradient(32,32,1,32,32,32);gradient.addColorStop(0,'#0009');gradient.addColorStop(1,'#0000');ctx.fillStyle=gradient;ctx.fillRect(0,0,64,64);
const contact=new T.Mesh(new T.PlaneGeometry(1.5,1.1),new T.MeshBasicMaterial({map:new T.CanvasTexture(shadowCanvas),transparent:true,opacity:.36,depthWrite:false}));contact.rotation.x=-Math.PI/2;scene.add(contact);
function setArea(next){
 area=next;forestRoot.visible=area==='forest';if(hallLife)hallLife.hall.visible=area==='hall';
 moon.intensity=area==='hall'?.8:.68;fill.intensity=area==='hall'?.5:.16;hemisphere.intensity=area==='hall'?.85:.22;renderer.toneMappingExposure=area==='hall'?1.05:.96;scene.environmentIntensity=area==='hall'?.3:.12;scene.background.set(area==='hall'?0x10121b:0x040812);scene.fog.color.set(area==='hall'?0x18242d:0x0b1424);scene.fog.density=area==='hall'?.006:.012;
 travel.set(0,0,0);destination=null;speed=0;shot=null;marker.visible=false;snapCamera=true;model.position.copy(place());model.rotation.set(0,area==='forest'?Math.atan2(navigation.tangent(0).x,navigation.tangent(0).z):0,0);follow.copy(model.position);
}
async function prepare(next,onLoad=onProgress,nearGate=false){assets.watch(next==='hall'?['minion']:['forest','wolf'],onLoad);await(next==='hall'?ensureHall():ensureForest());if(nearGate&&next==='forest'){assets.watch(['castle'],onLoad);await ensureCastle();}}
function reset(ids=[]){motion.reset();tavernStage?.open(1);castleRoot?.userData.setGateOpen?.(0);forestLife?.reset(ids);hallLife?.reset();elapsed=0;grounding.beforeAnimation();mixer.stopAllAction();active=null;play('Idle');}
function restore(w){setArea(w.area);travel.set(w.x,0,w.z);model.position.copy(place());model.rotation.set(0,w.yaw,0);zoom=w.zoom;follow.copy(model.position);snapCamera=true;destination=w.destination?new T.Vector3(w.destination.x,0,w.destination.z):null;}
function setShot(next){shot=next;destination=null;speed=0;marker.visible=false;snapCamera=true;}
function click(x,y){
 let goal;
 if(area==='forest')goal=navigation.hit(x,y,camera);
 else{pointer.set(x/innerWidth*2-1,-y/innerHeight*2+1);ray.setFromCamera(pointer,camera);const hit=new T.Vector3();if(ray.ray.intersectPlane(plane,hit))goal={x:hit.x,z:hit.z};}
 const max=area==='hall'?30.2:107.2;
 if(!goal||Math.abs(goal.x)>2.3||goal.z<0||goal.z>max){invalidUntil=elapsed+1.1;window.berinNotice?.('Escolha um ponto '+(area==='hall'?'no corredor do salão.':'na estrada.'));return false;}
 destination=new T.Vector3(goal.x,0,goal.z);marker.material.color.set(0xe5c98a);marker.position.copy(area==='forest'?navigation.point(goal.z,goal.x):destination);marker.position.y+=.045;marker.visible=true;return true;
}
let prefetchStarted=false,hallPrefetch=false,profileAt=0,wallAt=performance.now();
function update(dt,enabled,keys,frozen=false,draw=true){
 if(frozen)return;
 const profileStart=performance.now(),rawFrame=profileStart-wallAt;wallAt=profileStart;
 elapsed+=dt;if(tavernStage&&area==='forest')tavernStage.root.visible=travel.z>=2.5&&travel.z<22;
 if(area==='forest'&&travel.z>35&&!prefetchStarted){prefetchStarted=true;assets.watch([],()=>{});ensureCastle().catch(()=>{prefetchStarted=false})}
 if(area==='forest'&&travel.z>80&&!hallPrefetch){hallPrefetch=true;ensureHall().catch(()=>{hallPrefetch=false})}
 let turning=0;let dx=0,dz=0;const keyboard=enabled&&['w','s','a','d','arrowup','arrowdown','arrowleft','arrowright'].some(k=>keys.has(k));
 if(enabled){dx=Number(keys.has('d')||keys.has('arrowright'))-Number(keys.has('a')||keys.has('arrowleft'));dz=Number(keys.has('w')||keys.has('arrowup'))-Number(keys.has('s')||keys.has('arrowdown'));if(keyboard){destination=null;marker.visible=false}else if(destination){dx=destination.x-travel.x;dz=destination.z-travel.z;if(Math.hypot(dx,dz)<.06){destination=null;marker.visible=false;dx=dz=0}}}
 const length=Math.hypot(dx,dz),desired=enabled&&length>.001?1.7*(keys.has('shift')?2:1):0;speed=T.MathUtils.damp(speed,desired,10,dt);
 if(enabled&&length>.001){
  const step=Math.min(speed*dt,keyboard?Infinity:length),old=model.position.clone();travel.x=T.MathUtils.clamp(travel.x+dx/length*step,-2.3,2.3);travel.z=T.MathUtils.clamp(travel.z+dz/length*step,0,area==='hall'?30.2:107.2);model.position.copy(place());
  const actual=model.position.clone().sub(old),angle=Math.atan2(actual.x,actual.z),difference=Math.atan2(Math.sin(angle-model.rotation.y),Math.cos(angle-model.rotation.y));
  if(actual.lengthSq()>.000001){turning=difference;model.rotation.y+=difference*(1-Math.exp(-dt*12));play(speed>2.2&&actions.Run?'Run':'Walk');if(active)active.timeScale=speed/(active===actions.Run?3.4:1.7)}else play('Idle');
 }else play('Idle');
 const profileIK=performance.now();motion.before();grounding.beforeAnimation();mixer.update(dt);motion.update(dt,speed,turning,active);grounding.apply();const profileAfterIK=performance.now();
 contact.position.copy(model.position);contact.position.y+=.018;contact.rotation.z=-model.rotation.y;
 follow.lerp(model.position,1-Math.exp(-dt*7));
 const forward=area==='forest'?navigation.tangent(travel.z):new T.Vector3(0,0,1),right=new T.Vector3(forward.z,0,-forward.x);
 const portrait=innerWidth/innerHeight<1.15;
 const cameraDistance=area==='forest'?Math.min(zoom,Math.max(2.2,travel.z-.65)):zoom;
 cameraGoal.copy(follow).addScaledVector(forward,-cameraDistance).addScaledVector(right,cameraDistance*.22);cameraGoal.y+=cameraDistance*.46+1.6;
 look.copy(follow).addScaledVector(forward,2.2);look.y+=1.15;
 if(shot){
  const extra=portrait?1.6:0;
  if(shot==='crowd'){cameraGoal.set(5+extra,3.5,11+extra);look.set(0,.3,3)}
  else if(shot==='advisor'){cameraGoal.set(-1.5-extra,2.45,26.5-extra);look.set(1.1,.6,30)}
  else{cameraGoal.set(model.position.x+2.5+extra,2.05,model.position.z+3.7+extra);look.set(model.position.x,.8,model.position.z);}
 }
 if(snapCamera){camera.position.copy(cameraGoal);snapCamera=false}else camera.position.lerp(cameraGoal,1-Math.exp(-dt*(shot?3:5)));
 focus.copy(model.position);focus.y+=1.2;
 if(area==='forest'){const p=navigation.project(camera.position);camera.position.y=Math.max(camera.position.y,navigation.point(p.z,p.x).y+1.1);}
 const visible=o=>{for(let node=o;node;node=node.parent)if(!node.visible)return false;return true};guard.update(dt,camera.position,focus,visible);camera.lookAt(look);
 moon.position.set(follow.x-18,follow.y+32,follow.z+22);moon.target.position.copy(follow);fill.position.set(follow.x+6,follow.y+7,follow.z-7);fill.target.position.copy(follow);
 torchRig.update(elapsed,model.position,area==='forest');
 marker.material.opacity=.55+Math.sin(elapsed*5)*.2;
 if(area==='forest')forestLife.update(elapsed,travel,enabled);else hallLife.update(elapsed,shot==='crowd');
 document.getElementById('journey-progress').style.width=(travel.z/(area==='hall'?30:107)*100)+'%';document.getElementById('location').textContent=area==='hall'?'SALÃO DAS RIQUEZAS':'FLORESTA NEGRA';document.getElementById('objective').textContent=area==='hall'?'Caminhe pelo salão até o trono.':travel.z>92?'Entre no castelo.':'Siga as tochas e recolha as moedas.';
 const profileRender=performance.now();if(draw)renderer.render(scene,camera);
 if(draw&&location.search.includes('review=')&&performance.now()-profileAt>5000){profileAt=performance.now();console.log('FRAME-CHECK',JSON.stringify({rawFrame:Math.round(rawFrame),dt,enabled,keys:[...keys],z:travel.z,total:Math.round(performance.now()-profileStart),ground:Math.round(profileAfterIK-profileIK),scene:Math.round(profileRender-profileAfterIK),draws:renderer.info.render.calls,triangles:renderer.info.render.triangles}));}
}

async function cinematic(duration,frame,onCue=()=>{},shouldSkip=()=>false){
 let lastTime=performance.now(),time=0;const events=new Set();
 return new Promise((resolve,reject)=>{function next(now){try{let dt=Math.min((now-lastTime)/1000,1.25);lastTime=now;if(document.hidden)dt=0;const skipped=shouldSkip();time=skipped?duration:Math.min(duration,time+dt);if(skipped&&!events.has('_skip')){events.add('_skip');onCue('skip')}const cue=(at,name)=>{if(!skipped&&time>=at&&!events.has(name)){events.add(name);onCue(name)}};frame(time,dt,cue);renderer.render(scene,camera);if(time<duration)requestAnimationFrame(next);else resolve()}catch(error){reject(error)}}requestAnimationFrame(next)});
}
async function playPrologue(onCue,shouldSkip){
 const tavern=tavernStage,base=navigation.point(0).y;tavern.root.visible=true;forestRoot.visible=true;if(hallLife)hallLife.hall.visible=false;scene.background.set(0x090f18);scene.fog.density=.015;moon.intensity=.7;fill.intensity=.2;contact.visible=false;
 motion.before();grounding.beforeAnimation();mixer.stopAllAction();active=null;play('Idle');mixer.update(.001);
 const rest=new Map();model.traverse(o=>{if(o.isBone)rest.set(o,o.quaternion.clone())});
 const bone=name=>model.getObjectByName(name),pose=(name,x,y=0,z=0)=>{const b=bone(name);if(b)b.quaternion.multiply(new T.Quaternion().setFromEuler(new T.Euler(x,y,z)))};
 const hand=bone('HandR'),arm=bone('UpperArmR'),elbow=bone('ForearmR'),head=bone('Head');
 const handPos=new T.Vector3(),jointPos=new T.Vector3(),target=new T.Vector3(),deltaQ=new T.Quaternion(),parentQ=new T.Quaternion();
 function reach(amount){if(!hand||!arm||!elbow||!head)return;model.updateMatrixWorld(true);head.getWorldPosition(target);target.add(new T.Vector3(.18,.05,.1));hand.getWorldPosition(handPos);target.lerp(handPos,1-amount);for(let i=0;i<5;i++)for(const joint of [elbow,arm]){joint.getWorldPosition(jointPos);hand.getWorldPosition(handPos);const a=handPos.clone().sub(jointPos).normalize(),b=target.clone().sub(jointPos).normalize();deltaQ.setFromUnitVectors(a,b);joint.parent.getWorldQuaternion(parentQ);deltaQ.premultiply(parentQ.clone().invert()).multiply(parentQ);joint.quaternion.premultiply(deltaQ);model.updateMatrixWorld(true)}}
 try{await cinematic(9,(t,dt,cue)=>{
  for(const [b,q] of rest)b.quaternion.copy(q);cue(.25,'chair');cue(2.15,'laugh');cue(3.8,'tavern-door');cue(8.4,'leave-tavern');
  const standing=T.MathUtils.smoothstep(t,.9,2.65),seated=1-standing;
  if(t<4.8){play('Idle');mixer.update(dt);model.position.set(0,base-.28*seated,-4.8);model.rotation.set(0,0,0);pose('ThighL',-1.15*seated);pose('ThighR',-1.15*seated);pose('ShinL',1.3*seated);pose('ShinR',1.3*seated);pose('Chest',.22*seated+(t>2.15?Math.sin(t*11)*.045:0));pose('Head',.18*seated-.14*standing+Math.sin(t*9)*.045*standing);reach(seated);camera.position.set(1.9-t*.12,base+2.1,-1.8-t*.12);look.set(0,base+1.15,-4.8);}
  else{play('Walk');active.timeScale=1;motion.before();mixer.update(dt);model.position.set(0,base,-2.6+(t-4.8)*1.7);if(model.position.z>1)model.position.y=navigation.point(model.position.z).y;model.rotation.set(0,0,0);camera.position.set(.35,base+2.35,4.3+Math.max(0,model.position.z-1));look.copy(model.position);look.y+=.85;if(Math.floor((t-4.8)*3)>Math.floor((t-dt-4.8)*3))onCue('wood-step');}
  tavern.open(T.MathUtils.smoothstep(t,3.8,4.8));camera.lookAt(look);
 },onCue,shouldSkip)}finally{for(const [b,q] of rest)b.quaternion.copy(q);tavern.open(1);contact.visible=true;setArea('forest');mixer.stopAllAction();active=null;play('Idle');}
}
async function playGateEntry(onCue,shouldSkip){
 const end=navigation.point(107),forward=navigation.tangent(107),right=new T.Vector3(forward.z,0,-forward.x);marker.visible=false;motion.reset();
 await cinematic(4.8,(t,dt,cue)=>{
  cue(0,'gate-open');cue(4.1,'inside-castle');castleRoot.userData.setGateOpen(T.MathUtils.smoothstep(t,0,2));
  const walked=T.MathUtils.clamp(t-1.9,0,2.2)*1.7;model.position.copy(end).addScaledVector(forward,walked);model.rotation.y=Math.atan2(forward.x,forward.z);
  play(t>1.9?'Walk':'Idle');if(active)active.timeScale=1;motion.before();grounding.beforeAnimation();mixer.update(dt);motion.update(dt,t>1.9?1.7:0,0,active);grounding.apply();contact.position.copy(model.position);contact.position.y+=.015;
  camera.position.copy(end).addScaledVector(forward,-5.8+walked*.45).addScaledVector(right,4);camera.position.y+=3.2;look.copy(model.position);look.y+=1.1;camera.lookAt(look);torchRig.update(elapsed+t,model.position,true);
 },onCue,shouldSkip);
}
function resize(){renderer.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();snapCamera=true;}
const wheel=e=>{if(!playing||window.berinPaused)return;e.preventDefault();zoom=T.MathUtils.clamp(zoom+e.deltaY*.007,5.5,13)};addEventListener('resize',resize);canvas.addEventListener('wheel',wheel,{passive:false});cleanup=()=>{removeEventListener('resize',resize);canvas.removeEventListener('wheel',wheel)};
resize();setArea(initialArea);reset();
const world={spawnFromTavern(){travel.set(0,0,3.7);model.position.copy(place());follow.copy(model.position);snapCamera=true;},playPrologue,playGateEntry,laugh:duration=>motion.laugh(duration),prepare,setArea,reset,restore,click,update,setShot,get area(){return area},atGate:()=>area==='forest'&&travel.z>=107,atThrone:()=>area==='hall'&&travel.z>=30,snapshot:()=>({area,x:travel.x,z:travel.z,yaw:model.rotation.y,zoom,destination:destination?{x:destination.x,z:destination.z}:null}),warmHall:ensureHall};
onProgress({label:'Preparando luz e sombras…',percent:100});world.update(.016,false,new Set(),false,false);await renderer.compileAsync(scene,camera);renderer.render(scene,camera);window.berinWorld=world;return world;
}catch(error){cleanup();renderer?.dispose();window.BerinAssets.cache.clear();throw error;}
};
