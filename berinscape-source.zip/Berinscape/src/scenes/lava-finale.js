// A separate film set shares the loaded meshes and renderer with the playable hall.
function createLavaFinale(T, renderer, castleAsset, hero, cloneRig) {
  const scene = new T.Scene();
  scene.background = new T.Color(0x150f1e);
  scene.fog = new T.FogExp2(0x301724, .0024);
  const camera = new T.PerspectiveCamera(45, 1, .08, 850);
  const owned = [];
  const own = resource => { owned.push(resource); return resource; };
  const box = own(new T.BoxGeometry());
  const stone = own(new T.MeshStandardMaterial({color:0x393043, roughness:.93}));
  const parapet = own(new T.MeshStandardMaterial({color:0x584c54, roughness:.82}));
  function block(x,y,z,w,h,d,material=stone) {
    const mesh = new T.Mesh(box,material);
    mesh.scale.set(w,h,d); mesh.position.set(x,y,z); scene.add(mesh);
    return mesh;
  }
  const fortress = castleAsset.scene.clone(true);
  fortress.position.set(0,0,0); fortress.rotation.set(0,0,0); fortress.scale.setScalar(1);
  fortress.traverse(o=>{if(o.name==='Ground_CastleGround_0'||o.name==='GroundWater_CastleGround_0')o.visible=false;});
  fortress.updateMatrixWorld(true);
  const bounds = new T.Box3();
  fortress.traverseVisible(o=>{
    if(!o.isMesh)return;
    o.geometry.computeBoundingBox();
    bounds.union(o.geometry.boundingBox.clone().applyMatrix4(o.matrixWorld));
  });
  const size=bounds.getSize(new T.Vector3()), center=bounds.getCenter(new T.Vector3());
  const scale=40/Math.max(size.x,size.z);
  fortress.scale.setScalar(scale);
  fortress.position.set(-center.x*scale,-bounds.min.y*scale,-center.z*scale);
  scene.add(fortress);
  const front=size.z*scale/2;
  const deck=Math.min(6,size.y*scale*.45);
  block(0,-1,0,48,2,48);
  block(0,deck/2,front,10,deck,4);
  block(0,deck+.32,front+1.8,10,.64,.45,parapet);
  for(let x=-4.5;x<=4.5;x+=1.5)block(x,deck+.83,front+1.8,.66,.42,.48,parapet);
  block(0,-.18,28,4,.7,12,parapet);
  const actor=cloneRig(hero.scene);
  actor.position.set(0,deck,front+.85);actor.rotation.set(0,.08,0);scene.add(actor);
  const mixer=new T.AnimationMixer(actor);
  const idle=hero.animations.find(clip=>clip.name==='Idle');
  const walkClip=hero.animations.find(clip=>clip.name==='Walk');
  const walking=walkClip?mixer.clipAction(walkClip).play():null;
  const standing=idle?mixer.clipAction(idle).play():null;
  const drops=new Float32Array(64*2*3);
  for(let i=0;i<64;i++){
    const x=Math.sin(i*32.19)*6,y=(i*.731)%4,z=Math.cos(i*71.1)*5;
    drops.set([x,y,z,x-.035,y+.16,z],i*6);
  }
  const rainGeometry=own(new T.BufferGeometry());
  rainGeometry.setAttribute('position',new T.BufferAttribute(drops,3));
  const rain=new T.LineSegments(rainGeometry,own(new T.LineBasicMaterial({color:0xa0abc5,transparent:true,opacity:.28,depthWrite:false})));
  scene.add(rain);

  // Carve a deterministic maze, with elevated walking stones and molten seams.
  const n=17, pitch=6, half=8, visited=new Set(), passages=new Set();
  let seed=83;
  function visit(x,z){
    const id=z*n+x; visited.add(id);
    const dirs=[[1,0],[0,1],[-1,0],[0,-1]];
    for(let i=3;i>0;i--){seed=seed*16807%2147483647;const j=seed%(i+1);[dirs[i],dirs[j]]=[dirs[j],dirs[i]];}
    for(const [dx,dz] of dirs){
      const a=x+dx,b=z+dz,k=b*n+a;
      if(a<0||a>=n||b<0||b>=n||visited.has(k))continue;
      passages.add(Math.min(id,k)+','+Math.max(id,k));visit(a,b);
    }
  }
  visit(0,0);
  const slabs=[],walls=[];
  for(let z=0;z<n;z++)for(let x=0;x<n;x++){
    const X=(x-half)*pitch,Z=(z-half)*pitch,id=z*n+x;
    if(Math.abs(X)<24&&Math.abs(Z)<24)continue;
    slabs.push([X,-.4,Z,5.25,.8,5.25]);
    for(const [dx,dz] of [[1,0],[0,1],[-1,0],[0,-1]]){
      const nx=x+dx,nz=z+dz,k=nz*n+nx,out=nx<0||nz<0||nx>=n||nz>=n;
      if(!out&&(dx<0||dz<0))continue;
      const wx=X+dx*3,wz=Z+dz*3;
      if((Math.abs(wx)<24&&Math.abs(wz)<24)||(Math.abs(wx)<2&&wz>=19&&wz<=34))continue;
      if(!out&&passages.has(Math.min(id,k)+','+Math.max(id,k)))continue;
      walls.push([wx,1,wz,dx?.9:6.3,2.3,dz?.9:6.3]);
    }
  }
  const transform=new T.Object3D();
  function instances(parts,mat){
    const mesh=new T.InstancedMesh(box,mat,parts.length);
    parts.forEach(([x,y,z,w,h,d],i)=>{transform.position.set(x,y,z);transform.scale.set(w,h,d);transform.updateMatrix();mesh.setMatrixAt(i,transform.matrix);});
    scene.add(mesh);owned.push(mesh);
  }
  instances(slabs,parapet);instances(walls,stone);
  const lava=own(new T.ShaderMaterial({
    uniforms:{time:{value:0}},
    vertexShader:'varying vec2 uv0;void main(){uv0=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader:`varying vec2 uv0;uniform float time;void main(){
      vec2 p=uv0*80.;float veins=sin(p.x*2.+sin(p.y*2.+time*.3))+sin(p.y*3.-time*.42+sin(p.x));
      float crust=smoothstep(-1.5,1.7,veins);gl_FragColor=vec4(mix(vec3(.42,.028,.003),vec3(1.,.48,.045),crust),1.);
      #include <colorspace_fragment>
    }`
  }));
  const pool=new T.Mesh(own(new T.PlaneGeometry(120,120)),lava);
  pool.rotation.x=-Math.PI/2;pool.position.y=-.65;scene.add(pool);
  scene.add(new T.HemisphereLight(0xc5c0f4,0xcb4b20,1.55));
  const rim=new T.DirectionalLight(0xffb06b,2.5);rim.position.set(-12,18,24);scene.add(rim);
  const arms=['L','R'].map(side=>actor.getObjectByName('UpperArm.'+side));
  const rests=arms.map(bone=>bone?.quaternion.clone());
  const eye=new T.Vector3(),aim=new T.Vector3();
  return {
    draw(t,dt){
      arms.forEach((bone,i)=>{if(bone)bone.quaternion.copy(rests[i]);});
      const arrived=T.MathUtils.smoothstep(t,0,2);
      actor.position.z=front-.55+1.4*arrived;
      if(walking)walking.setEffectiveWeight(1-T.MathUtils.smoothstep(t,1.35,2));
      if(standing)standing.setEffectiveWeight(walking?1-walking.getEffectiveWeight():1);
      rain.position.set(0,deck-(t*2.8%1.8),front);
      rain.visible=t<7;
      mixer.update(dt);
      const opening=T.MathUtils.smoothstep(t,9,10.8);
      arms.forEach((bone,i)=>{if(bone){rests[i].copy(bone.quaternion);bone.rotateZ((i?-1:1)*.65*opening);}});
      lava.uniforms.time.value=t;
      const aspect=renderer.domElement.clientWidth/Math.max(1,renderer.domElement.clientHeight);
      camera.aspect=aspect;camera.updateProjectionMatrix();
      const k=T.MathUtils.smootherstep(t,4,14.2);
      const wide=Math.max(1,1/aspect);
      eye.set(2.3+31*k,deck+2+91*k*wide,front+4.8+57*k*wide);
      aim.set(0,(deck+1.25)*(1-k), (front+.85)*(1-k));
      camera.position.copy(eye);camera.lookAt(aim);renderer.render(scene,camera);
    },
    dispose(){mixer.stopAllAction();owned.forEach(item=>item.dispose());}
  };
}
