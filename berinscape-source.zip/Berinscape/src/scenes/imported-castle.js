// The original gate faces +Z. Turn it toward the road and align its threshold.
function createImportedCastle(T,gltf,navigation){
  const root=new T.Group();root.name='BerinCastleExterior';
  const end=navigation.point(107),direction=navigation.tangent(107);
  root.position.copy(end);root.rotation.y=Math.atan2(direction.x,direction.z);
  const model=gltf.scene,scale=.8;
  model.scale.setScalar(scale);model.rotation.y=Math.PI;
  model.position.set(-.0138*scale,.015,21.95*scale+1.2);
  model.traverse(o=>{if(!o.isMesh)return;o.castShadow=true;o.receiveShadow=true;
    // Replace the showcase terrain slab at the front with the existing forest terrain.
    if(o.name==='Ground_CastleGround_0'||o.name==='GroundWater_CastleGround_0')o.visible=false;
    for(const m of Array.isArray(o.material)?o.material:[o.material]){
      if(m.map)m.map.anisotropy=4;
      if(m.roughness!==undefined)m.roughness=Math.max(/metal/i.test(m.name)?.6:.88,m.roughness);
    }
  });root.add(model);root.updateMatrixWorld(true);
  const gates=[];model.traverse(o=>{if(o.isMesh&&/^FrontDoor_0[123]_MetalDoor/.test(o.name))gates.push(o)});
  const movingGates=[];
  for(const gate of gates){const lift=new T.Group();root.add(lift);lift.attach(gate);movingGates.push(lift);}
  root.userData.setGateOpen=amount=>{for(const gate of movingGates)gate.position.y=amount*5.1};
  root.userData.gateCount=movingGates.length;
  const paving=document.createElement('canvas');paving.width=paving.height=256;const paint=paving.getContext('2d');paint.fillStyle='#28292d';paint.fillRect(0,0,256,256);
  let seed=59;const random=()=>((seed=seed*16807%2147483647)-1)/2147483646;
  for(let row=0;row<8;row++)for(let col=-1;col<4;col++){const shade=70+Math.floor(random()*25);paint.fillStyle=`rgb(${shade},${shade+2},${shade+6})`;paint.fillRect(col*86+(row%2)*43+2,row*32+2,82,28);}
  for(let i=0;i<12000;i++){paint.fillStyle=i%2?'#ffffff0b':'#00000018';paint.fillRect(random()*256,random()*256,1,1);}
  const pavingMap=new T.CanvasTexture(paving);pavingMap.colorSpace=T.SRGBColorSpace;pavingMap.wrapS=pavingMap.wrapT=T.RepeatWrapping;pavingMap.repeat.set(2,2);pavingMap.anisotropy=4;
  const threshold=new T.Mesh(new T.BoxGeometry(6.4,.28,6.5),new T.MeshStandardMaterial({color:0xb9bdc5,map:pavingMap,bumpMap:pavingMap,bumpScale:.035,roughness:.98}));
  threshold.position.set(0,-.14,2.2);threshold.castShadow=threshold.receiveShadow=true;root.add(threshold);
  // Sample the actual road to blend a short approach into the stone threshold.
  const rampGeometry=new T.PlaneGeometry(6.4,3.2,12,8),rampPositions=rampGeometry.attributes.position;
  for(let i=0;i<rampPositions.count;i++){
    const x=rampPositions.getX(i),z=-rampPositions.getY(i)-2.4,world=root.localToWorld(new T.Vector3(x,0,z)),p=navigation.project(world);
    const road=navigation.point(p.z,p.x).y-end.y;
    rampPositions.setXYZ(i,x,T.MathUtils.lerp(road+.025,-.008,T.MathUtils.smoothstep(z,-4,-.8)),z);
  }
  rampGeometry.computeVertexNormals();rampGeometry.computeBoundingSphere();
  const ramp=new T.Mesh(rampGeometry,threshold.material);ramp.name='CastleRoadBlend';ramp.receiveShadow=true;root.add(ramp);
  // Cold grazing light reveals towers; the entrance itself is lit by real torches.
  for(const x of [-9,9]){const rim=new T.SpotLight(0x6d8bb6,80,42,.68,1,2);rim.position.set(x,8,-10);rim.target.position.set(x*.8,11,10);root.add(rim,rim.target);}
  return root;
}
